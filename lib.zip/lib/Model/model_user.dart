class AppUser {
  final String uid;
  final String name;
  final String email;
  final List<String> roles;
  final Map<String, dynamic>? extraData;

  AppUser({
    required this.uid,
    required this.name,
    required this.email,
    required this.roles,
    this.extraData,
  });

  factory AppUser.fromMap(Map<String, dynamic> data, String uid) {
    return AppUser(
      uid: uid,
      name: data['name'],
      email: data['email'],
      roles: List<String>.from(data['roles'] ?? []),
      extraData: Map<String, dynamic>.from(data['extraData'] ?? {}),
    );
  }
}
