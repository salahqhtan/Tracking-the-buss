import 'package:darbk_new/Data.dart';
// import 'package:darbk_new/ScreenUsers/screen/screenParent/subjective.dart';
// import 'package:darbk_new/admin/screen/homeScreenAddmin.dart';
import 'package:darbk_new/screen/auth/SplashScreen.dart';

// import 'package:darbk_new/admin/screen/HomeScreen.dart';

// import 'package:darbk_new/auth/login.dart';
import 'package:flutter/material.dart';

import 'package:firebase_core/firebase_core.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await DataUser.init();
  await Firebase.initializeApp();
  runApp(Darbk());
}

class Darbk extends StatelessWidget {
  const Darbk({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      locale: Locale('ar', 'SA'),
      title: 'Darbak',
      theme: ThemeData(useMaterial3: true),
      initialRoute: SplashScreen.routeScreen,
      routes: {
        SplashScreen.routeScreen: (_) => SplashScreen(),
        // '/homeAdmin': (context) => const HomeAdmin(),
        // LoginScreen.routeScreen: (context) => loginScreen(),
        // AllScreen.routeScreen: (context) => AllScreen(),
        // Subjective.routeScreen: (context) => Subjective(),
      },
    );
  }
}
