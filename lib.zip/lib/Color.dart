import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class ScreenColorS {

  static const  Color card = Color.fromARGB(184, 191, 239, 245);
  static const  Color border = Color.fromARGB(255, 90, 167, 255);
  static const  Color focuseBorder = Color.fromARGB(255, 108, 245, 170);
}