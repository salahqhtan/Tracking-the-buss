import 'package:flutter/material.dart';
import 'package:motion_toast/motion_toast.dart';

class Input extends StatelessWidget {
final String title;
final bool enabled;
final VoidCallback onPressed;
final TextInputType keyboardType;

  const Input({super.key, required this.title, required this.enabled, required this.onPressed, required this.keyboardType});


  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: BoxConstraints(maxWidth: 700 , minWidth: 200,),
      child: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(title),
            TextFormField(
              
              keyboardType: keyboardType,
              decoration: InputDecoration(
                filled: true,
                fillColor: const Color.fromARGB(255, 253, 247, 247),

                hintText: title, 
                enabled: enabled,
               
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide(width: 1 , color: Colors.cyan),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide(width: 1 , color: const Color.fromARGB(255, 153, 234, 245)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                  borderSide: BorderSide(width: 1 , color: const Color.fromARGB(255, 141, 247, 164)),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}


class BottonAdd extends StatelessWidget {
  const BottonAdd({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.green,
          elevation: 6,
          foregroundColor: Colors.black
        ),
        onPressed: (){
          MotionToast.success(
            animationCurve:Curves.easeInSine,
            description: Icon(Icons.boy , color: Colors.white,),
             title: Column(
               children: [
                 Text("تم إضافة الطالب بنجاح!" , style: TextStyle(color: Colors.white),), SizedBox(height: 5,)
               ],
             ),
             ).show(context);

        },
       child: Text("إضافة" , style: TextStyle(fontSize: 26 , fontWeight: FontWeight.w600),),
       ),
    );
  }
}



















// // Import the functions you need from the SDKs you need
// import { initializeApp } from "firebase/app";
// // TODO: Add SDKs for Firebase products that you want to use
// // https://firebase.google.com/docs/web/setup#available-libraries

// // Your web app's Firebase configuration
// const firebaseConfig = {
//   apiKey: "AIzaSyDawERoGhZkZQ312xHfLwVR66L0QOzw2Vk",
//   authDomain: "your-smart-path.firebaseapp.com",
//   projectId: "your-smart-path",
//   storageBucket: "your-smart-path.firebasestorage.app",
//   messagingSenderId: "187771940906",
//   appId: "1:187771940906:web:bf23c0eca5feee600e9353"
// };

// // Initialize Firebase
// const app = initializeApp(firebaseConfig);