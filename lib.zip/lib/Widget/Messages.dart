import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:motion_toast/motion_toast.dart';
import 'package:fluttertoast/fluttertoast.dart';



  void success(String msg){
     MotionToast.success(
      toastAlignment: Alignment.center,
      description: Text(msg , style: TextStyle(fontSize: 17 , fontWeight: FontWeight.bold, color: Colors.white),)
      );
  }


  void error(String msg){
     MotionToast.error(
      toastAlignment: Alignment.center,
      description: Text(msg , style: TextStyle(fontSize: 17 , fontWeight: FontWeight.bold , color: Colors.white),)
      );
  }



void msg(String msg , Color color){
  Fluttertoast.showToast(
    gravity: ToastGravity.CENTER,
    msg: msg , backgroundColor: color
    );

}


