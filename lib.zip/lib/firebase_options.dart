// lib/firebase_options.dart

import 'package:firebase_core/firebase_core.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    return const FirebaseOptions(
      apiKey: "AIzaSyDawERoGhZkZQ312xHfLwVR66L0QOzw2Vk",
      authDomain: "your-smart-path.firebaseapp.com",
      projectId: "your-smart-path",
      storageBucket: "your-smart-path.firebasestorage.app",
      messagingSenderId: "187771940906",
      appId: "1:187771940906:web:bf23c0eca5feee600e9353",
    );
  }
}
