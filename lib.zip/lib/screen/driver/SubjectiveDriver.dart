import 'dart:io';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/screen/driver/widget/custom_scaffold.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

/// صفحة البيانات الشخصية للسائق
class SubjectiveDriver extends StatefulWidget {
  final String driverId; // UID السائق الحقيقي

  const SubjectiveDriver({super.key, required this.driverId});

  @override
  State<SubjectiveDriver> createState() => _SubjectiveDriverState();
}

class _SubjectiveDriverState extends State<SubjectiveDriver> {
  final _auth = FirebaseAuth.instance;
  final _firestore = FirebaseFirestore.instance;

  String name = '';
  String email = '';
  String phone = '';
  String address = '';
  String licenseNumber = '';
  bool loading = true;

  File? _userImageFile;
  final String _defaultImagePath = "assets/images/icons8-admin-80.png";
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    loadDriverInfo();
    _loadUserImage();
  }

  /// تحميل بيانات السائق من Firestore
  Future<void> loadDriverInfo() async {
    setState(() => loading = true);

    try {
      final doc =
          await _firestore.collection('Drivers').doc(widget.driverId).get();
      name = doc.data()?['Name'] ?? 'بدون اسم';
      phone = doc.data()?['Phone'] ?? 'غير معروف';
      licenseNumber = doc.data()?['LicenseNumber'] ?? 'غير معروف';
      address = doc.data()?['Address'] ?? 'غير معروف';
      email = doc.data()?['Email'] ?? '';
    } catch (e) {
      Fluttertoast.showToast(msg: "خطأ في تحميل البيانات");
    }

    setState(() => loading = false);
  }

  /// تحميل صورة السائق من الجهاز
  Future<void> _loadUserImage() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/user_image_${widget.driverId}.png';
    final file = File(path);
    if (await file.exists()) {
      setState(() => _userImageFile = file);
    }
  }

  /// حفظ صورة السائق في الجهاز
  Future<void> _saveUserImage(XFile pickedFile) async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/user_image_${widget.driverId}.png';
    final file = File(path);
    final savedImage = await file.writeAsBytes(await pickedFile.readAsBytes());
    setState(() => _userImageFile = savedImage);
  }

  /// حذف الصورة الشخصية
  Future<void> _deleteUserImage() async {
    if (_userImageFile != null) {
      final file = _userImageFile!;
      if (await file.exists()) await file.delete();
      setState(() => _userImageFile = null);
      Fluttertoast.showToast(msg: "تم حذف الصورة، عادت الصورة الافتراضية");
    }
  }

  /// اختيار مصدر الصورة
  void _showImageSourceDialog() {
    AwesomeDialog(
      context: context,
      dialogType: DialogType.noHeader,
      headerAnimationLoop: false,
      title: "اختر صورة",
      desc: "هل تريد اختيار صورة من المعرض أم التقاط صورة بالكاميرا؟",
      btnCancelText: "معرض",
      btnCancelOnPress: () => _pickImage(ImageSource.gallery),
      btnOkText: "كاميرا",
      btnOkOnPress: () => _pickImage(ImageSource.camera),
    ).show();
  }

  /// التقاط أو اختيار الصورة
  Future<void> _pickImage(ImageSource source) async {
    try {
      final pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 80,
      );
      if (pickedFile != null) await _saveUserImage(pickedFile);
    } catch (e) {
      Fluttertoast.showToast(msg: "حدث خطأ أثناء اختيار الصورة");
    }
  }

  /// تغيير كلمة المرور
  Future<void> changePassword() async {
    final passwordController = TextEditingController();
    final confirmController = TextEditingController();

    AwesomeDialog(
      context: context,
      dialogType: DialogType.noHeader,
      animType: AnimType.bottomSlide,
      title: 'تغيير كلمة المرور',
      body: Column(
        children: [
          TextField(
            controller: passwordController,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'كلمة المرور الجديدة',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: confirmController,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'تأكيد كلمة المرور',
              border: OutlineInputBorder(),
            ),
          ),
        ],
      ),
      btnCancel: TextButton(
        child: const Text('إلغاء'),
        onPressed: () => Navigator.pop(context),
      ),
      btnOk: TextButton(
        child: const Text('تأكيد'),
        onPressed: () async {
          final pass = passwordController.text.trim();
          final confirm = confirmController.text.trim();

          if (pass.isEmpty || confirm.isEmpty) {
            Fluttertoast.showToast(msg: 'يرجى تعبئة جميع الحقول');
            return;
          }

          if (pass != confirm) {
            Fluttertoast.showToast(msg: 'كلمتا المرور غير متطابقتين');
            return;
          }

          try {
            await _auth.currentUser!.updatePassword(pass);
            Navigator.pop(context);
            Fluttertoast.showToast(
              msg: 'تم تغيير كلمة المرور بنجاح',
              backgroundColor: Colors.green,
            );
          } catch (e) {
            Fluttertoast.showToast(
              msg: 'فشل في تغيير كلمة المرور',
              backgroundColor: Colors.red,
            );
          }
        },
      ),
    ).show();
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldWithCustomAppBar(
      title: "البيانات الشخصية",
      driverId: widget.driverId, // تمرير UID السائق
      currentIndex: 3,
      body:
          loading
              ? const Center(child: CircularProgressIndicator())
              : SingleChildScrollView(
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 15,
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // صورة المستخدم
                    Center(
                      child: Stack(
                        alignment: Alignment.topRight,
                        children: [
                          InkWell(
                            onTap: _showImageSourceDialog,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(100),
                              child:
                                  _userImageFile != null
                                      ? Image.file(
                                        _userImageFile!,
                                        width: 160,
                                        height: 160,
                                        fit: BoxFit.cover,
                                      )
                                      : Image.asset(
                                        _defaultImagePath,
                                        width: 160,
                                        height: 160,
                                        fit: BoxFit.cover,
                                      ),
                            ),
                          ),
                          if (_userImageFile != null)
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: _deleteUserImage,
                              tooltip: "حذف الصورة المخصصة",
                            ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 25),
                    // الاسم
                    Row(
                      children: [
                        const Text(
                          "الاسم: ",
                          style: TextStyle(fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(width: 10),
                        Text(
                          name,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    const Divider(height: 3, color: Colors.green),
                    const SizedBox(height: 10),
                    // بيانات الهاتف والرخصة والعنوان
                    Container(
                      padding: const EdgeInsets.only(right: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Text(
                                "الهاتف : ",
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                phone,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          const Divider(height: 3, color: Colors.blue),
                          Row(
                            children: [
                              const Text(
                                "الرخصة : ",
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Text(
                                licenseNumber,
                                style: const TextStyle(
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          const Divider(height: 3, color: Colors.blue),
                          Row(
                            children: [
                              const Text(
                                "العنوان : ",
                                style: TextStyle(
                                  fontSize: 15,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              Expanded(
                                child: Text(
                                  address,
                                  style: const TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 8),
                          const Divider(height: 3, color: Colors.blue),
                        ],
                      ),
                    ),
                    const SizedBox(height: 30),
                    // زر تغيير كلمة المرور
                    ElevatedButton.icon(
                      onPressed: changePassword,
                      icon: const Icon(Icons.lock),
                      label: const Text("تغيير كلمة المرور"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.teal,
                        minimumSize: const Size(double.infinity, 50),
                      ),
                    ),
                  ],
                ),
              ),
    );
  }
}
