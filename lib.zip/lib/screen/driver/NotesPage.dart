import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/material.dart';
import 'package:darbk_new/screen/driver/widget/custom_scaffold.dart';

/// صفحة الملاحظات للسائق
class NotesDriver extends StatefulWidget {
  final String driverId; // UID السائق

  const NotesDriver({super.key, required this.driverId});

  @override
  State<NotesDriver> createState() => _NotesDriverState();
}

class _NotesDriverState extends State<NotesDriver> {
  final TextEditingController _controller = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  int _currentIndex = 2; // التبويب رقم 2 في CustomBottomNav
  final Map<String, String> _senderCache = {}; // لتخزين أسماء المرسلين مؤقتاً

  // جلب اسم المرسل مع التخزين المؤقت
  Future<String> getSenderName(String senderId) async {
    if (_senderCache.containsKey(senderId)) return _senderCache[senderId]!;

    try {
      final doc = await _firestore.collection('Drivers').doc(senderId).get();
      if (doc.exists) {
        final name = doc.get('Name') ?? 'غير معروف';
        _senderCache[senderId] = name;
        return name;
      }
    } catch (e) {
      // يمكن تجربة جلب الاسم من ولي الأمر أو الطالب إذا لزم
    }
    return 'غير معروف';
  }

  // إرسال ملاحظة جديدة
  void _sendNote() {
    final message = _controller.text.trim();
    if (message.isNotEmpty) {
      _firestore.collection('Notes').add({
        'Content': message,
        'Date': Timestamp.now(),
        'Sender_ID': widget.driverId,
      });
      _controller.clear();
    }
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldWithCustomAppBar(
      title: "الملاحظات الجماعية",
      driverId: widget.driverId,
      currentIndex: _currentIndex,
      body: Column(
        children: [
          // عرض الملاحظات
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream:
                  _firestore
                      .collection('Notes')
                      .orderBy('Date', descending: false)
                      .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final notes = snapshot.data!.docs;
                if (notes.isEmpty) {
                  return const Center(
                    child: Text(
                      "لا توجد ملاحظات بعد",
                      style: TextStyle(color: Colors.grey, fontSize: 16),
                    ),
                  );
                }

                return ListView.builder(
                  padding: const EdgeInsets.all(8),
                  itemCount: notes.length,
                  itemBuilder: (context, index) {
                    final note = notes[index];
                    final content = note.get('Content');
                    final date = (note.get('Date') as Timestamp).toDate();
                    final senderId = note.get('Sender_ID');
                    final isMe = senderId == widget.driverId;

                    return FutureBuilder<String>(
                      future: getSenderName(senderId),
                      builder: (context, nameSnapshot) {
                        if (!nameSnapshot.hasData)
                          return const SizedBox.shrink();
                        final senderName = nameSnapshot.data!;

                        return Align(
                          alignment:
                              isMe
                                  ? Alignment.centerRight
                                  : Alignment.centerLeft,
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 6),
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color:
                                  isMe
                                      ? const Color.fromARGB(255, 142, 250, 148)
                                      : Colors.grey[300],
                              borderRadius: BorderRadius.only(
                                topLeft: const Radius.circular(12),
                                topRight: const Radius.circular(12),
                                bottomLeft: Radius.circular(isMe ? 12 : 0),
                                bottomRight: Radius.circular(isMe ? 0 : 12),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  isMe ? "أنت" : senderName,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                    color: Colors.blue,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  content,
                                  style: const TextStyle(fontSize: 16),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  "${date.hour}:${date.minute.toString().padLeft(2, '0')} __ ${date.year}/${date.month}/${date.day}",
                                  style: const TextStyle(
                                    fontSize: 10,
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),

          // مربع الإدخال
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: _controller,
                    minLines: 1,
                    maxLines: 3,
                    decoration: const InputDecoration(
                      hintText: "أدخل ملاحظة...",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(20)),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send, color: Colors.teal),
                  onPressed: _sendNote,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
