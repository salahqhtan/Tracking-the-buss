import 'dart:async';
import 'dart:ui';

import 'package:darbk_new/screen/driver/AttendancePage.dart';
import 'package:darbk_new/screen/driver/widget/custom_scaffold.dart';

import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:geolocator/geolocator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

// Tween لتحريك Marker على الخريطة
class LatLngTween extends Tween<LatLng> {
  LatLngTween({required LatLng begin, required LatLng end})
    : super(begin: begin, end: end);

  @override
  LatLng lerp(double t) {
    final lat = lerpDouble(begin!.latitude, end!.latitude, t)!;
    final lng = lerpDouble(begin!.longitude, end!.longitude, t)!;
    return LatLng(lat, lng);
  }
}

// الصفحة الرئيسية للسائق
class HomeDriver extends StatefulWidget {
  final String driverId; // UID السائق

  const HomeDriver({super.key, required this.driverId});

  @override
  State<HomeDriver> createState() => _HomeDriverState();
}

class _HomeDriverState extends State<HomeDriver> with TickerProviderStateMixin {
  GoogleMapController? _mapController;
  Marker? _busMarker;
  Timer? _positionTimer;
  Timer? _historyTimer;

  LatLng _initial = const LatLng(15.3694, 44.1910);
  LatLng _currentPosition = const LatLng(15.3694, 44.1910);
  LatLng _previousPosition = const LatLng(15.3694, 44.1910);

  double _speed = 0.0;
  String? _busId;
  List<LatLng> _history = [];

  bool _loading = true;
  String? _error;

  late AnimationController _animationController;
  late Animation<LatLng> _animation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2000),
    );
    _fetchBusAndStart();
  }

  Future<void> _fetchBusAndStart() async {
    try {
      final uid = widget.driverId;
      final query =
          await FirebaseFirestore.instance
              .collection('Bus')
              .where('Driver_ID', isEqualTo: uid)
              .limit(1)
              .get();

      if (query.docs.isEmpty) {
        setState(() {
          _error = 'لا توجد حافلة لهذا السائق.';
          _loading = false;
        });
        return;
      }

      _busId = query.docs.first.get('Bus_number');
      await _startTracking();
      setState(() => _loading = false);
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  Future<void> _startTracking() async {
    if (_busId == null) return;

    final perm = await Geolocator.requestPermission();
    if (perm == LocationPermission.denied ||
        perm == LocationPermission.deniedForever) {
      setState(() => _error = 'تم رفض إذن الموقع.');
      return;
    }

    _positionTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      final pos = await Geolocator.getCurrentPosition();
      _previousPosition = _currentPosition;
      _currentPosition = LatLng(pos.latitude, pos.longitude);
      _speed = pos.speed * 3.6;

      _animateMarker(_previousPosition, _currentPosition);

      setState(() {
        _history.add(_currentPosition);
      });

      await FirebaseFirestore.instance
          .collection('LiveLocation')
          .doc(_busId)
          .set({
            'lat': _currentPosition.latitude,
            'lng': _currentPosition.longitude,
            'speed': _speed,
            'timestamp': DateTime.now().millisecondsSinceEpoch,
            'Bus_ID': _busId,
          });
    });

    _historyTimer = Timer.periodic(const Duration(minutes: 1), (_) async {
      final pos = await Geolocator.getCurrentPosition();
      final ts = DateTime.now().millisecondsSinceEpoch.toString();
      await FirebaseFirestore.instance
          .collection('LiveLocation')
          .doc(_busId)
          .collection('history')
          .doc(ts)
          .set({'lat': pos.latitude, 'lng': pos.longitude, 'timestamp': ts});
    });
  }

  void _animateMarker(LatLng from, LatLng to) {
    if (from.latitude == to.latitude && from.longitude == to.longitude) return;

    _animationController.reset();
    final tween = LatLngTween(begin: from, end: to);
    _animation = tween.animate(_animationController)..addListener(() {
      final newPos = _animation.value;
      setState(() {
        _busMarker = Marker(
          markerId: const MarkerId('bus'),
          position: newPos,
          icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueBlue),
          rotation: Geolocator.bearingBetween(
            from.latitude,
            from.longitude,
            to.latitude,
            to.longitude,
          ),
        );
      });
      _mapController?.animateCamera(CameraUpdate.newLatLng(newPos));
    });
    _animationController.forward();
  }

  @override
  void dispose() {
    _positionTimer?.cancel();
    _historyTimer?.cancel();
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_error != null) {
      return Scaffold(
        body: Center(
          child: Text(_error!, style: const TextStyle(fontSize: 16)),
        ),
      );
    }

    final polylines = {
      Polyline(
        polylineId: const PolylineId('route'),
        points: _history,
        color: Colors.blue,
        width: 5,
      ),
    };

    return ScaffoldWithCustomAppBar(
      title: "الصفحة الرئيسية",
      driverId: widget.driverId, // 👈 UID السائق
      currentIndex: 0, // 👈 تبويب الرئيسية
      body: Column(
        children: [
          SizedBox(
            height: 300,
            child: Stack(
              children: [
                GoogleMap(
                  initialCameraPosition: CameraPosition(
                    target: _initial,
                    zoom: 16,
                  ),
                  markers: _busMarker != null ? {_busMarker!} : {},
                  polylines: polylines,
                  onMapCreated: (c) => _mapController = c,
                  myLocationEnabled: true,
                  myLocationButtonEnabled: true,
                ),
                Positioned(
                  top: 20,
                  right: 20,
                  child: Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.black87,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Text(
                      '${_speed.toStringAsFixed(1)} كم/س',
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 30),
          const Expanded(child: SingleChildScrollView(child: AttendancePage())),
        ],
      ),
    );
  }
}
