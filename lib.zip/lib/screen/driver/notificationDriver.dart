import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:darbk_new/screen/driver/widget/custom_scaffold.dart';

/// صفحة إرسال الإشعارات للسائق
class NotificationDriver extends StatefulWidget {
  final String driverId; // UID السائق

  const NotificationDriver({super.key, required this.driverId});

  @override
  State<NotificationDriver> createState() => _NotificationDriverState();
}

class _NotificationDriverState extends State<NotificationDriver> {
  final TextEditingController _messageController = TextEditingController();
  String _selectedType = 'رسمي';
  bool _isSending = false;

  final List<String> _types = ['رسمي', 'تنبيه', 'تحذير', 'عام'];

  /// إرسال الإشعار لجميع أولياء الأمور المرتبطين بالحافلة
  Future<void> _sendNotificationToParents() async {
    final driverId = widget.driverId;
    final firestore = FirebaseFirestore.instance;

    if (_messageController.text.trim().isEmpty) {
      Fluttertoast.showToast(msg: "يرجى كتابة نص الإشعار");
      return;
    }

    setState(() => _isSending = true);

    try {
      // الحصول على الحافلة المرتبطة بالسائق
      final busSnap =
          await firestore
              .collection('Bus')
              .where('Driver_ID', isEqualTo: driverId)
              .limit(1)
              .get();

      if (busSnap.docs.isEmpty) {
        Fluttertoast.showToast(msg: "لا توجد حافلة مرتبطة بهذا السائق");
        setState(() => _isSending = false);
        return;
      }

      final busNumber = busSnap.docs.first.data()['Bus_number'];

      // الحصول على أولياء الأمور المرتبطين بالحافلة
      final parentSnap =
          await firestore
              .collection('Parent')
              .where('Bus_ID', isEqualTo: busNumber)
              .get();

      final parents = parentSnap.docs;
      final now = DateTime.now();
      final batch = firestore.batch();

      for (var parent in parents) {
        final notifRef = firestore.collection('Notifications').doc();
        batch.set(notifRef, {
          'Type': _selectedType,
          'Message': _messageController.text.trim(),
          'Receiver_Type': 'Parent',
          'Receiver_ID': parent.id,
          'Sender_Type': 'سائق',
          'Sender_ID': driverId,
          'Send_date': now,
          'isRead': false,
        });
      }

      await batch.commit();
      Fluttertoast.showToast(msg: "تم إرسال الإشعارات بنجاح");

      _messageController.clear();
      setState(() => _selectedType = 'رسمي');
    } catch (e) {
      Fluttertoast.showToast(
        msg: "فشل في إرسال الإشعارات: $e",
        backgroundColor: Colors.red,
      );
    }

    setState(() => _isSending = false);
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldWithCustomAppBar(
      title: "الإشعارات",
      driverId: widget.driverId, // تمرير UID السائق
      currentIndex: 1, // تبويب الإشعارات في CustomBottomNav
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextFormField(
              controller: _messageController,
              maxLines: 5,
              decoration: InputDecoration(
                labelText: 'نص الإشعار',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
            ),
            const SizedBox(height: 16),
            DropdownButtonFormField<String>(
              value: _selectedType,
              items:
                  _types
                      .map(
                        (type) =>
                            DropdownMenuItem(value: type, child: Text(type)),
                      )
                      .toList(),
              onChanged: (val) => setState(() => _selectedType = val!),
              decoration: InputDecoration(
                labelText: 'نوع الإشعار',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isSending ? null : _sendNotificationToParents,
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color.fromARGB(255, 12, 230, 208),
                minimumSize: const Size(double.infinity, 50),
              ),
              child:
                  _isSending
                      ? const CircularProgressIndicator(color: Colors.white)
                      : const Text(
                        "إرسال الإشعار",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
            ),
          ],
        ),
      ),
    );
  }
}
