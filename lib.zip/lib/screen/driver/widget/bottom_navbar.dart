import 'package:darbk_new/screen/driver/HomeDriver.dart';
import 'package:darbk_new/screen/driver/NotesPage.dart';
import 'package:darbk_new/screen/driver/SubjectiveDriver.dart';
import 'package:darbk_new/screen/driver/notificationDriver.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// 🔹 Custom Bottom Navigation Bar لجميع صفحات السائق
class CustomBottomNav extends StatefulWidget {
  final int currentIndex; // لتحديد الصفحة الحالية

  const CustomBottomNav({super.key, required this.currentIndex});

  @override
  State<CustomBottomNav> createState() => _CustomBottomNavState();
}

class _CustomBottomNavState extends State<CustomBottomNav> {
  late int currentIndex;

  @override
  void initState() {
    super.initState();
    currentIndex = widget.currentIndex; // حفظ الصفحة الحالية
  }

  /// التنقل بين الصفحات بناءً على index
  void _navigateToPage(int index) {
    if (index == currentIndex) return;

    setState(() => currentIndex = index);

    final driverId =
        FirebaseAuth.instance.currentUser!.uid; // UID السائق الحالي
    Widget page;

    switch (index) {
      case 0:
        page = HomeDriver(driverId: driverId);
        break;
      case 1:
        page = NotificationDriver(driverId: driverId);
        break;
      case 2:
        page = NotesDriver(driverId: driverId);
        break;
      case 3:
        page = SubjectiveDriver(driverId: driverId);
        break;
      default:
        page = HomeDriver(driverId: driverId);
    }

    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 90,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(30.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.25),
                blurRadius: 20,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _navItem(icon: Icons.home, label: 'الرئيسية', index: 0),
                _navItem(
                  icon: Icons.notifications_active,
                  label: 'الإشعارات',
                  index: 1,
                ),
                _navItem(icon: Icons.feedback, label: 'الملاحظات', index: 2),
                _navItem(icon: Icons.account_circle, label: 'حسابي', index: 3),
              ],
            ),
          ),
        ),
      ),
    );
  }

  /// عنصر أيقونة منفردة في الشريط
  Widget _navItem({
    required IconData icon,
    required String label,
    required int index,
  }) {
    final isSelected = index == currentIndex;

    return GestureDetector(
      onTap: () => _navigateToPage(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color:
              isSelected
                  ? const Color.fromARGB(255, 193, 211, 209).withOpacity(0.20)
                  : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 20,
              color:
                  isSelected
                      ? const Color.fromARGB(255, 23, 195, 92)
                      : const Color.fromARGB(220, 236, 227, 227),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                color: isSelected ? Colors.amberAccent : Colors.white70,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
