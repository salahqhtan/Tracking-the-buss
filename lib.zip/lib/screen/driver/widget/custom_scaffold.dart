import 'package:darbk_new/screen/driver/HomeDriver.dart';
import 'package:darbk_new/screen/driver/NotesPage.dart';
import 'package:darbk_new/screen/driver/SubjectiveDriver.dart';
import 'package:darbk_new/screen/driver/notificationDriver.dart';

import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/screen/parent/widget/drawer.dart';

/// 🔹 AppBar مخصص مع Drawer وأيقونة الإشعارات
class CustomAppBarWithDrawer extends StatelessWidget
    implements PreferredSizeWidget {
  final String title;
  final PreferredSizeWidget? bottom;
  final String driverId; // UID السائق

  const CustomAppBarWithDrawer({
    super.key,
    required this.title,
    this.bottom,
    required this.driverId,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: AppBar(
        backgroundColor: const Color.fromARGB(255, 0, 175, 239),
        elevation: 5,
        centerTitle: true,
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(bottom: Radius.circular(20)),
        ),
        title: Text(
          title,
          style: const TextStyle(
            fontSize: 25,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        bottom: bottom,
        actions: [
          StreamBuilder<QuerySnapshot>(
            stream:
                FirebaseFirestore.instance
                    .collection('Notifications')
                    .where('receiverId', isEqualTo: driverId)
                    .where('isRead', isEqualTo: false)
                    .snapshots(),
            builder: (context, snapshot) {
              int unreadCount = 0;
              if (snapshot.hasData) unreadCount = snapshot.data!.docs.length;

              return Stack(
                children: [
                  IconButton(
                    icon: const Icon(Icons.notifications, size: 28),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder:
                              (_) => NotificationDriver(driverId: driverId),
                        ),
                      );
                    },
                  ),
                  if (unreadCount > 0)
                    Positioned(
                      left: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(4),
                        decoration: const BoxDecoration(
                          color: Colors.red,
                          shape: BoxShape.circle,
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 18,
                          minHeight: 18,
                        ),
                        child: Text(
                          '$unreadCount',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 11,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }

  @override
  Size get preferredSize => Size(
    double.infinity,
    kToolbarHeight + (bottom?.preferredSize.height ?? 0),
  );
}

/// 🔹 Bottom Navigation مخصص
class CustomBottomNav extends StatefulWidget {
  final int currentIndex;
  final String driverId; // UID السائق

  const CustomBottomNav({
    super.key,
    required this.currentIndex,
    required this.driverId,
  });

  @override
  State<CustomBottomNav> createState() => _CustomBottomNavState();
}

class _CustomBottomNavState extends State<CustomBottomNav> {
  late int currentIndex;

  @override
  void initState() {
    super.initState();
    currentIndex = widget.currentIndex;
  }

  void _navigateToPage(int index) {
    if (index == currentIndex) return;
    setState(() => currentIndex = index);

    Widget page;
    switch (index) {
      case 0:
        page = HomeDriver(driverId: widget.driverId);
        break;
      case 1:
        page = NotificationDriver(driverId: widget.driverId);
        break;
      case 2:
        page = NotesDriver(driverId: widget.driverId);
        break;
      case 3:
        page = SubjectiveDriver(driverId: widget.driverId);
        break;
      default:
        page = HomeDriver(driverId: widget.driverId);
    }

    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: SizedBox(
        height: 90,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
          child: Container(
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                colors: [
                  Color(0xFF0F2027),
                  Color(0xFF203A43),
                  Color(0xFF2C5364),
                ],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(30.0),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.25),
                  blurRadius: 20,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(30.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  _navItem(icon: Icons.home, label: 'الرئيسية', index: 0),
                  _navItem(
                    icon: Icons.notifications_active,
                    label: 'الإشعارات',
                    index: 1,
                  ),
                  _navItem(icon: Icons.feedback, label: 'الملاحظات', index: 2),
                  _navItem(
                    icon: Icons.account_circle,
                    label: 'حسابي',
                    index: 3,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _navItem({
    required IconData icon,
    required String label,
    required int index,
  }) {
    final isSelected = index == currentIndex;
    return GestureDetector(
      onTap: () => _navigateToPage(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        decoration: BoxDecoration(
          color:
              isSelected
                  ? const Color.fromARGB(255, 193, 211, 209).withOpacity(0.20)
                  : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 20,
              color:
                  isSelected
                      ? const Color.fromARGB(255, 23, 195, 92)
                      : const Color.fromARGB(220, 236, 227, 227),
            ),
            const SizedBox(height: 2),
            Text(
              label,
              style: TextStyle(
                fontSize: 13,
                color: isSelected ? Colors.amberAccent : Colors.white70,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 🔹 Scaffold موحد مع AppBar و Drawer و Bottom Navigation
class ScaffoldWithCustomAppBar extends StatelessWidget {
  final String title;
  final Widget body;
  final PreferredSizeWidget? bottom;
  final String driverId; // UID السائق
  final int currentIndex;

  const ScaffoldWithCustomAppBar({
    super.key,
    required this.title,
    required this.body,
    required this.driverId,
    this.bottom,
    this.currentIndex = 0,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        drawer: const DrawerParent(),
        appBar: CustomAppBarWithDrawer(
          title: title,
          bottom: bottom,
          driverId: driverId,
        ),
        body: body,
        bottomNavigationBar: CustomBottomNav(
          currentIndex: currentIndex,
          driverId: driverId,
        ),
      ),
    );
  }
}
