import 'dart:io';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/Data.dart';
import 'package:darbk_new/screen/auth/login.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

class DrawerParent extends StatefulWidget {
  const DrawerParent({super.key});

  @override
  State<DrawerParent> createState() => _DrawerWidgetState();
}

class _DrawerWidgetState extends State<DrawerParent> {
  File? _userImageFile;
  final String _defaultImagePath = "assets/images/icons8-admin-80.png";
  final ImagePicker _picker = ImagePicker();

  String? userEmail;
  String? userRole;
  String? userName;

  @override
  void initState() {
    super.initState();
    _loadUserImage();
    _loadUserDataFromFirestore();
  }

  /// جلب بيانات المستخدم من Firestore
  Future<void> _loadUserDataFromFirestore() async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        setState(() {
          userEmail = "غير مسجل الدخول";
          userRole = "غير معروف";
          userName = "";
        });
        return;
      }
      final uid = currentUser.uid;
      final userDoc =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();
      if (userDoc.exists) {
        // ignore: unnecessary_cast
        final data = userDoc.data()! as Map<String, dynamic>;
        setState(() {
          userEmail = data['email'] ?? "غير معروف";
          userRole = data['roles'] ?? "غير محدد";
          userName = data['name'] ?? "";
        });
      } else {
        setState(() {
          userEmail = currentUser.email ?? "غير معروف";
          userRole = "غير محدد";
          userName = "";
        });
      }
    } catch (e) {
      setState(() {
        userEmail = "خطأ في تحميل البيانات";
        userRole = "";
        userName = "";
      });
      Fluttertoast.showToast(msg: "خطأ في جلب بيانات المستخدم");
    }
  }

  /// تحميل الصورة المحلية
  Future<void> _loadUserImage() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/user_image.png';
    final file = File(path);
    if (await file.exists()) {
      setState(() {
        _userImageFile = file;
      });
    }
  }

  /// حفظ الصورة محليًا
  Future<void> _saveUserImage(XFile pickedFile) async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/user_image.png';
    final file = File(path);
    final savedImage = await file.writeAsBytes(await pickedFile.readAsBytes());
    setState(() {
      _userImageFile = savedImage;
    });
  }

  /// حذف الصورة المختارة
  Future<void> _deleteUserImage() async {
    if (_userImageFile != null) {
      final file = _userImageFile!;
      if (await file.exists()) {
        await file.delete();
      }
      setState(() {
        _userImageFile = null;
      });
      Fluttertoast.showToast(msg: "تم حذف الصورة، عادت الصورة الافتراضية");
    }
  }

  /// Dialog لاختيار المصدر
  void _showImageSourceDialog() {
    AwesomeDialog(
      context: context,
      dialogType: DialogType.noHeader,
      headerAnimationLoop: false,
      title: "اختر صورة",
      desc: "هل تريد اختيار صورة من المعرض أم التقاط صورة بالكاميرا؟",
      btnCancelText: "معرض",
      btnCancelOnPress: () => _pickImage(ImageSource.gallery),
      btnOkText: "كاميرا",
      btnOkOnPress: () => _pickImage(ImageSource.camera),
    ).show();
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 80,
      );
      if (pickedFile != null) {
        await _saveUserImage(pickedFile);
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "حدث خطأ أثناء اختيار الصورة");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Colors.grey[100],
      child: SingleChildScrollView(
        child: Column(
          children: [
            const SizedBox(height: 40),

            /// صورة المستخدم مع تأثير ظل وجمالية
            Stack(
              alignment: Alignment.topRight,
              children: [
                GestureDetector(
                  onTap: _showImageSourceDialog,
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 20),
                    padding: const EdgeInsets.all(5),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(
                        colors: [Color(0xFF00BFA6), Color(0xFF00E5FF)],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          offset: const Offset(0, 5),
                        ),
                      ],
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(17),
                      child:
                          _userImageFile != null
                              ? Image.file(
                                _userImageFile!,
                                height: 180,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              )
                              : Image.asset(
                                _defaultImagePath,
                                height: 180,
                                width: double.infinity,
                                fit: BoxFit.cover,
                              ),
                    ),
                  ),
                ),
                if (_userImageFile != null)
                  IconButton(
                    icon: const Icon(Icons.delete, color: Colors.red),
                    onPressed: _deleteUserImage,
                  ),
              ],
            ),

            const SizedBox(height: 20),

            /// اسم وبريد المستخدم مع خلفية بطاقة
            Card(
              margin: const EdgeInsets.symmetric(horizontal: 20),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15),
              ),
              elevation: 5,
              child: Padding(
                padding: const EdgeInsets.symmetric(
                  vertical: 15,
                  horizontal: 20,
                ),
                child: Column(
                  children: [
                    if (userName != null && userName!.isNotEmpty)
                      Text(
                        userName!,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.black87,
                        ),
                      ),
                    if (userEmail != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: Text(
                          "البريد الإلكتروني: $userEmail",
                          style: const TextStyle(
                            fontSize: 16,
                            color: Colors.black87,
                          ),
                        ),
                      ),
                    if (userRole != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 5),
                        child: Text(
                          "الصلاحية: $userRole",
                          style: const TextStyle(
                            fontSize: 15,
                            color: Colors.black54,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 30),
            const Divider(
              thickness: 2,
              color: Colors.black26,
              indent: 20,
              endIndent: 20,
            ),

            /// خيارات القائمة
            const SizedBox(height: 10),

            _buildMenuItem(
              icon: Icons.logout,
              text: "تسجيل الخروج",
              color: Colors.redAccent,
              onTap: () async {
                await FirebaseAuth.instance.signOut();
                await DataUser.remove('role');
                Fluttertoast.showToast(
                  msg: "تم تسجيل الخروج بنجاح",
                  toastLength: Toast.LENGTH_SHORT,
                  gravity: ToastGravity.BOTTOM,
                  backgroundColor: Colors.green,
                  textColor: Colors.white,
                );
                Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginScreen()),
                  (route) => false,
                );
              },
            ),
            _buildMenuItem(
              icon: Icons.info_outline,
              text: "عنا",
              color: Colors.blueAccent,
              onTap: () {
                // صفحة "عنا"
              },
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  /// تصميم عنصر القائمة بشكل أنيق
  Widget _buildMenuItem({
    required IconData icon,
    required String text,
    required Color color,
    required VoidCallback onTap,
  }) {
    return ListTile(
      leading: Icon(icon, color: color, size: 26),
      title: Text(
        text,
        style: TextStyle(fontSize: 17, fontWeight: FontWeight.w600),
      ),
      onTap: onTap,
      horizontalTitleGap: 5,
      contentPadding: const EdgeInsets.symmetric(horizontal: 20),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      tileColor: Colors.white,
      hoverColor: Colors.grey[200],
    );
  }
}
