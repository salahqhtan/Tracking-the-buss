import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

// صفحة حضور الطلاب
class AttendancePage extends StatefulWidget {
  const AttendancePage({Key? key}) : super(key: key);

  @override
  State<AttendancePage> createState() => _AttendancePageState();
}

class _AttendancePageState extends State<AttendancePage> {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Map<String, String> attendanceStatus = {};
  bool _isLoading = true;
  // ignore: unused_field
  List<Map<String, dynamic>> _students = [];
  List<Map<String, dynamic>> _todayAttendance = [];
  String? _driverId;
  Map<String, String> _classes = {};

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);

    final user = _auth.currentUser;
    if (user == null) {
      Navigator.pop(context);
      return;
    }
    _driverId = user.uid;

    await _fetchClasses();

    _students = await _fetchStudents();

    await _fetchTodayAttendance();

    setState(() => _isLoading = false);
  }

  Future<void> _fetchClasses() async {
    final classesSnap = await _firestore.collection('Classes').get();
    _classes.clear();
    for (var doc in classesSnap.docs) {
      _classes[doc.id] = doc.get('Name');
    }
  }

  Future<List<Map<String, dynamic>>> _fetchStudents() async {
    if (_driverId == null) return <Map<String, dynamic>>[];

    var busSnap =
        await _firestore
            .collection('Bus')
            .where('Driver_ID', isEqualTo: _driverId)
            .get();

    if (busSnap.docs.isEmpty) return <Map<String, dynamic>>[];

    var data = busSnap.docs.first.data();
    String busNumber = data['Bus_number'];

    var parentsSnap =
        await _firestore
            .collection('Parent')
            .where('Bus_ID', isEqualTo: busNumber)
            .get();

    if (parentsSnap.docs.isEmpty) return <Map<String, dynamic>>[];

    List<String> parentIds = parentsSnap.docs.map((doc) => doc.id).toList();
    if (parentIds.isEmpty) return <Map<String, dynamic>>[];

    QuerySnapshot<Map<String, dynamic>> studentsSnap;
    if (parentIds.length <= 10) {
      studentsSnap =
          await _firestore
              .collection('Student')
              .where('Parent_ID', whereIn: parentIds)
              .get();
    } else {
      studentsSnap =
          await _firestore
              .collection('Student')
              .where('Parent_ID', whereIn: parentIds.sublist(0, 10))
              .get();
    }

    return studentsSnap.docs.map<Map<String, dynamic>>((doc) {
      final data = doc.data();
      data['id'] = doc.id;
      return data;
    }).toList();
  }

  Future<void> _fetchTodayAttendance() async {
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());

    var attendanceSnap =
        await _firestore
            .collection('Attendance')
            .where('Date', isEqualTo: today)
            .where('Class_ID', isEqualTo: 'Bus')
            .get();

    _todayAttendance = attendanceSnap.docs.map((doc) => doc.data()).toList();

    for (var att in _todayAttendance) {
      if (att['Student_ID'] != null && att['Status'] != null) {
        attendanceStatus[att['Student_ID']] = att['Status'];
      }
    }
  }

  Future<void> submitAttendance() async {
    setState(() => _isLoading = true);
    final today = DateFormat('yyyy-MM-dd').format(DateTime.now());

    var batch = _firestore.batch();
    var oldRecords =
        await _firestore
            .collection('Attendance')
            .where('Date', isEqualTo: today)
            .where('Class_ID', isEqualTo: 'Bus')
            .get();

    for (var doc in oldRecords.docs) {
      batch.delete(doc.reference);
    }
    await batch.commit();

    for (var entry in attendanceStatus.entries) {
      await _firestore.collection('Attendance').add({
        'Student_ID': entry.key,
        'Status': entry.value,
        'Date': today,
        'Class_ID': 'Bus',
      });
    }

    await _fetchTodayAttendance();
    setState(() => _isLoading = false);

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('تم تحديث الحضور بنجاح')));
  }

  @override
  Widget build(BuildContext context) {
    return _isLoading
        ? const Center(child: CircularProgressIndicator())
        : Padding(
          padding: const EdgeInsets.all(16.0),
          child: SingleChildScrollView(
            child: Column(
              children: [
                // يمكن إضافة جداول حضور الطلاب هنا
                const Text("جدول الحضور..."),
              ],
            ),
          ),
        );
  }
}
