import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/Data.dart';
import 'package:darbk_new/screen/parent/widget/custom_scaffold.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class NotesParent extends StatefulWidget {
  const NotesParent({super.key});

  @override
  State<NotesParent> createState() => _NotesParentState();
}

class _NotesParentState extends State<NotesParent> {
  final TextEditingController _controller = TextEditingController();
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  late String currentParentId;

  int _currentIndex = 2; // الملاحظات هي الصفحة رقم 2 في CustomBottomNav

  @override
  void initState() {
    super.initState();
    currentParentId = _auth.currentUser!.uid;
  }

  bool isParent = DataUser.get('type') == 'ولي أمر';
  bool isDriver = DataUser.get('type') == 'سائق';
  bool isStudent = DataUser.get('type') == 'طالب';

  Future<String> getSenderName(String senderId) async {
    try {
      final doc = await _firestore.collection('Parent').doc(senderId).get();
      if (doc.exists && doc.data() != null) {
        return doc.get('Name') ?? 'غير معروف';
      }
    } catch (e) {
      return 'غير معروف';
    }
    return 'غير معروف';
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldWithCustomAppBar(
      title: "الملاحظات الجماعية",
      parentId: currentParentId,
      currentIndex: _currentIndex, // لربط CustomBottomNav
      body: Column(
        children: [
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream:
                  _firestore
                      .collection('Notes')
                      .orderBy('Date', descending: false)
                      .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final notes = snapshot.data!.docs;

                return ListView.builder(
                  padding: const EdgeInsets.all(8),
                  itemCount: notes.length,
                  itemBuilder: (context, index) {
                    final note = notes[index];
                    final content = note.get('Content');
                    final date = (note.get('Date') as Timestamp).toDate();
                    final senderId = note.get('Sender_ID');
                    final isMe = senderId == currentParentId;

                    return FutureBuilder<String>(
                      future: getSenderName(senderId),
                      builder: (context, nameSnapshot) {
                        if (!nameSnapshot.hasData) return const SizedBox();

                        final senderName = nameSnapshot.data!;

                        return Align(
                          alignment:
                              isMe
                                  ? Alignment.centerRight
                                  : Alignment.centerLeft,
                          child: Container(
                            margin: const EdgeInsets.symmetric(vertical: 6),
                            padding: const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color:
                                  isMe
                                      ? const Color.fromARGB(255, 142, 250, 148)
                                      : Colors.grey[300],
                              borderRadius: BorderRadius.only(
                                topLeft: const Radius.circular(12),
                                topRight: const Radius.circular(12),
                                bottomLeft: Radius.circular(isMe ? 12 : 0),
                                bottomRight: Radius.circular(isMe ? 0 : 12),
                              ),
                            ),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  isMe ? "أنت" : senderName,
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12,
                                    color: Colors.blue,
                                  ),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  content,
                                  style: const TextStyle(fontSize: 16),
                                ),
                                const SizedBox(height: 5),
                                Text(
                                  "${date.hour}:${date.minute} __ ${date.year}/${date.month}/${date.day}",
                                  style: const TextStyle(
                                    fontSize: 10,
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    );
                  },
                );
              },
            ),
          ),

          // حقل إدخال الملاحظة
          Container(
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      enabled: isParent || isDriver,
                      controller: _controller,
                      minLines: 1,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        hintText: "أدخل ملاحظة...",
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                        ),
                      ),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.send, color: Colors.teal),
                    onPressed:
                        (isParent || isDriver)
                            ? () {
                              final message = _controller.text.trim();
                              if (message.isNotEmpty) {
                                _firestore.collection('Notes').add({
                                  'Content': message,
                                  'Date': Timestamp.now(),
                                  'Sender_ID': currentParentId,
                                });
                                _controller.clear();
                              }
                            }
                            : null,
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
