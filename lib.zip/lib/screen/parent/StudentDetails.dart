import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';

class StudentDetailsPage extends StatefulWidget {
  final String studentId;
  final Map<String, dynamic> studentData;

  const StudentDetailsPage({
    super.key,
    required this.studentId,
    required this.studentData,
  });

  @override
  State<StudentDetailsPage> createState() => _StudentDetailsPageState();
}

class _StudentDetailsPageState extends State<StudentDetailsPage> {
  int selectedClassNumber = 1;
  String? Classname;
  String? Classstage;
  bool isLoading = true;

  List<int> classNumbers = [];
  List<Map<String, dynamic>> grades = [];

  String get studentName => widget.studentData['Name'];
  String get classId => widget.studentData['Class_id'];

  @override
  void initState() {
    super.initState();
    loadStudentData();
  }

  Future<void> loadStudentData() async {
    setState(() => isLoading = true);
    try {
      final classDoc =
          await FirebaseFirestore.instance
              .collection('Classes')
              .doc(classId)
              .get();

      final currentClassNumber = classDoc.data()?['Number'] ?? 1;
      classNumbers = List.generate(currentClassNumber, (i) => i + 1);
      selectedClassNumber = currentClassNumber;

      await fetchGrades();
    } catch (e) {
      Fluttertoast.showToast(msg: "خطأ في تحميل بيانات الطالب: $e");
    }
    setState(() => isLoading = false);
  }

  Future<void> fetchGrades() async {
    grades.clear();
    final addedSubjects = <String>{};

    try {
      final gradeSnapshot =
          await FirebaseFirestore.instance
              .collection('Grades')
              .where('Student_id', isEqualTo: widget.studentId)
              .get();

      final futures = gradeSnapshot.docs.map((doc) async {
        final gradeData = doc.data();
        final gradeClassId = gradeData['Class_ID'];
        final subjectId = gradeData['Subject_id'];

        if (addedSubjects.contains(subjectId)) return;
        addedSubjects.add(subjectId);

        final results = await Future.wait([
          FirebaseFirestore.instance
              .collection('Classes')
              .doc(gradeClassId)
              .get(),
          FirebaseFirestore.instance
              .collection('Subjects')
              .doc(subjectId)
              .get(),
        ]);

        final classDoc = results[0];
        final subjectDoc = results[1];

        final number = classDoc.data()?['Number'] ?? 0;
        final className = classDoc.data()?['Name'] ?? 'غير معروف';
        final classStage = classDoc.data()?['Stage'] ?? 'غير معروف';

        if (number == selectedClassNumber) {
          setState(() {
            Classname = className;
            Classstage = classStage;
          });

          final subjectData = subjectDoc.data() ?? {};
          final term1 = gradeData['Term1_scor'] ?? 0;
          final term2 = gradeData['Term2_scor'] ?? 0;
          final rawTotal = gradeData['Total_scor'];
          final total =
              (rawTotal is num)
                  ? rawTotal.toDouble()
                  : ((term1 is num ? term1.toDouble() : 0.0) +
                      (term2 is num ? term2.toDouble() : 0.0));

          grades.add({
            'subject_name': subjectData['Name'] ?? 'غير معروف',
            'term1_score': term1,
            'term2_score': term2,
            'total_score': total,
          });
        }
      });

      await Future.wait(futures);
    } catch (e) {
      Fluttertoast.showToast(msg: "خطأ في تحميل الدرجات: $e");
    }

    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final total_term1 = grades.fold<double>(
      0.0,
      (sum, g) => sum + (g['term1_score'] is num ? g['term1_score'] : 0),
    );
    final total_term2 = grades.fold<double>(
      0.0,
      (sum, g) => sum + (g['term2_score'] is num ? g['term2_score'] : 0),
    );
    final total = grades.fold<double>(
      0.0,
      (sum, g) => sum + (g['total_score'] is num ? g['total_score'] : 0),
    );

    // ✅ شرط النجاح الصحيح: لازم جميع المواد فوق 50
    final status =
        grades.every((g) => (g['total_score'] ?? 0) >= 50) ? 'ناجح' : 'راسب';

    final avgScore = grades.isNotEmpty ? total / grades.length : 0.0;
    String grade = '';
    if (avgScore < 50) {
      grade = 'ضعيف';
    } else if (avgScore < 65) {
      grade = 'مقبول';
    } else if (avgScore < 75) {
      grade = 'جيد';
    } else if (avgScore < 85) {
      grade = 'جيد جدًا';
    } else {
      grade = 'ممتاز';
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF4F9FA),
        appBar: AppBar(
          title: const Text(" بيانات الطالب"),
          backgroundColor: const Color.fromARGB(255, 52, 189, 219),
          elevation: 4,
        ),
        body:
            isLoading
                ? const Center(child: CircularProgressIndicator())
                : ListView(
                  padding: const EdgeInsets.all(12),
                  children: [
                    // بطاقة بيانات الطالب
                    Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      elevation: 5,
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Row(
                          children: [
                            CircleAvatar(
                              radius: 35,
                              backgroundColor: Colors.teal.shade100,
                              child: const Icon(
                                Icons.person,
                                size: 40,
                                color: Colors.teal,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    studentName,
                                    style: const TextStyle(
                                      fontSize: 22,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  Text(
                                    "الصف: $Classname",
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                  Text(
                                    "المرحلة: $Classstage",
                                    style: TextStyle(
                                      fontSize: 16,
                                      color: Colors.grey[700],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            PopupMenuButton<int>(
                              icon: const Icon(
                                Icons.menu_book,
                                color: Colors.teal,
                              ),
                              onSelected: (num) {
                                setState(() {
                                  selectedClassNumber = num;
                                  fetchGrades();
                                });
                              },
                              itemBuilder:
                                  (context) =>
                                      classNumbers
                                          .map(
                                            (e) => PopupMenuItem(
                                              value: e,
                                              child: Text('الصف $e'),
                                            ),
                                          )
                                          .toList(),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // جدول المواد والدرجات
                    Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      elevation: 5,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child:
                            grades.isEmpty
                                ? const Center(child: Text("لا توجد درجات"))
                                : SingleChildScrollView(
                                  scrollDirection: Axis.horizontal,
                                  child: DataTable(
                                    columnSpacing: 30,
                                    headingRowColor: WidgetStateProperty.all(
                                      Colors.teal.shade100,
                                    ),
                                    columns: const [
                                      DataColumn(label: Text('المادة')),
                                      DataColumn(label: Text('الفصل الأول')),
                                      DataColumn(label: Text('الفصل الثاني')),
                                      DataColumn(label: Text('المجموع')),
                                    ],
                                    rows:
                                        grades.map((g) {
                                          return DataRow(
                                            cells: [
                                              DataCell(Text(g['subject_name'])),
                                              DataCell(
                                                Text('${g['term1_score']}'),
                                              ),
                                              DataCell(
                                                Text('${g['term2_score']}'),
                                              ),
                                              DataCell(
                                                Text('${g['total_score']}'),
                                              ),
                                            ],
                                          );
                                        }).toList(),
                                  ),
                                ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    // ملخص
                    Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      elevation: 5,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: DataTable(
                            columns: const [
                              DataColumn(label: Text("الجزء الأول")),
                              DataColumn(label: Text("الجزء الثاني")),
                              DataColumn(label: Text("المجموع")),
                              DataColumn(label: Text("المعدل")),
                              DataColumn(label: Text("التقدير")),
                              DataColumn(label: Text("الحالة")),
                            ],
                            rows: [
                              DataRow(
                                cells: [
                                  DataCell(Text('$total_term1')),
                                  DataCell(Text('$total_term2')),
                                  DataCell(Text('$total')),
                                  DataCell(Text(avgScore.toStringAsFixed(2))),
                                  DataCell(Text(grade)),
                                  DataCell(
                                    Text(
                                      status,
                                      style: TextStyle(
                                        color:
                                            status == 'راسب'
                                                ? Colors.red
                                                : Colors.green,
                                        fontWeight: FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
      ),
    );
  }
}
