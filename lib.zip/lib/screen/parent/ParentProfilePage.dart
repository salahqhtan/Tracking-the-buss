import 'dart:io';
import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/Data.dart';
import 'package:darbk_new/screen/parent/ParentStudent.dart';
import 'package:darbk_new/screen/parent/widget/custom_scaffold.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

class SubjectiveParent extends StatefulWidget {
  const SubjectiveParent({super.key});
  static const routeScreen = "Subjective";

  @override
  State<SubjectiveParent> createState() => _SubjectiveState();
}

class _SubjectiveState extends State<SubjectiveParent>
    with TickerProviderStateMixin {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  late String currentParentId;
  late User currentUser;

  String name = '';
  String email = '';
  String phone = "";
  String? busNumber;

  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _passwordConfController = TextEditingController();

  bool _loading = false;
  bool isParent = DataUser.get('type') == 'ولي أمر';

  File? _userImageFile;
  final String _defaultImagePath = "assets/images/icons8-admin-80.png";
  final ImagePicker _picker = ImagePicker();

  late TabController _tabController;
  int _currentIndex = 3;

  @override
  void initState() {
    super.initState();
    currentUser = _auth.currentUser!;
    currentParentId = currentUser.uid;
    loadParentData();
    _loadUserImage();
    _tabController = TabController(length: 2, vsync: this);
  }

  Future<void> loadParentData() async {
    final doc =
        await _firestore.collection('Parent').doc(currentParentId).get();
    if (doc.exists) {
      final data = doc.data()!;
      name = data['Name'] ?? '';
      email = data['Email'] ?? '';
      phone = data['Phone'] ?? '';
      busNumber = data['Bus_ID'] ?? '';
      setState(() {});
    }
  }

  Future<void> _loadUserImage() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/user_image.png';
    final file = File(path);
    if (await file.exists()) setState(() => _userImageFile = file);
  }

  Future<void> _saveUserImage(XFile pickedFile) async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/user_image.png';
    final file = File(path);
    final savedImage = await file.writeAsBytes(await pickedFile.readAsBytes());
    setState(() => _userImageFile = savedImage);
  }

  // ignore: unused_element
  Future<void> _deleteUserImage() async {
    if (_userImageFile != null) {
      final file = _userImageFile!;
      if (await file.exists()) await file.delete();
      setState(() => _userImageFile = null);
      Fluttertoast.showToast(msg: "تم حذف الصورة، عادت الصورة الافتراضية");
    }
  }

  void _showImageSourceDialog() {
    AwesomeDialog(
      context: context,
      dialogType: DialogType.noHeader,
      title: "اختر صورة",
      desc: "هل تريد اختيار صورة من المعرض أم التقاط صورة بالكاميرا؟",
      btnCancelText: "معرض",
      btnCancelOnPress: () => _pickImage(ImageSource.gallery),
      btnOkText: "كاميرا",
      btnOkOnPress: () => _pickImage(ImageSource.camera),
    ).show();
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 80,
      );
      if (pickedFile != null) await _saveUserImage(pickedFile);
    } catch (e) {
      Fluttertoast.showToast(msg: "حدث خطأ أثناء اختيار الصورة");
    }
  }

  Future<void> _updatePassword() async {
    String newPassword = _passwordController.text.trim();
    String newPasswordConf = _passwordConfController.text.trim();

    AwesomeDialog(
      context: context,
      dialogType: DialogType.noHeader,
      body: Column(
        children: [
          TextFormField(
            controller: _passwordController,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'كلمة المرور الجديدة',
              prefixIcon: Icon(Icons.lock_outline),
            ),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: _passwordConfController,
            obscureText: true,
            decoration: const InputDecoration(
              labelText: 'تأكيد كلمة المرور',
              prefixIcon: Icon(Icons.lock_outline),
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            onPressed: () async {
              if (newPassword.isNotEmpty && newPasswordConf.isNotEmpty) {
                if (newPassword == newPasswordConf) {
                  try {
                    await currentUser.updatePassword(newPassword);
                    await _firestore
                        .collection('Parent')
                        .doc(currentParentId)
                        .update({'Password': newPassword});
                    Fluttertoast.showToast(
                      msg: "تم تحديث كلمة المرور بنجاح",
                      backgroundColor: Colors.green,
                    );
                    Navigator.pop(context);
                  } catch (e) {
                    Fluttertoast.showToast(
                      msg: "فشل في تحديث كلمة المرور",
                      backgroundColor: Colors.red,
                    );
                  }
                } else {
                  Fluttertoast.showToast(
                    msg: 'كلمة المرور غير متطابقة!',
                    backgroundColor: Colors.red,
                  );
                }
              }
            },
            icon: const Icon(Icons.save),
            label: const Text("تغيير"),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.teal,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(30),
              ),
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 24),
            ),
          ),
        ],
      ),
    ).show();
  }

  @override
  Widget build(BuildContext context) {
    return ScaffoldWithCustomAppBar(
      title: "ملفي الشخصي",
      parentId: currentParentId,
      currentIndex: _currentIndex,
      bottom: TabBar(
        controller: _tabController,
        labelColor: Colors.white,
        unselectedLabelColor: Colors.white70,
        indicator: BoxDecoration(
          borderRadius: BorderRadius.circular(25),
          gradient: LinearGradient(
            colors: [Colors.teal, Colors.greenAccent.shade700],
          ),
        ),
        tabs: const [
          Tab(icon: Icon(Icons.person), text: "شخصي"),
          Tab(icon: Icon(Icons.family_restroom), text: "الأبناء"),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // 👤 تبويب شخصي
          _loading
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                padding: const EdgeInsets.all(20),
                children: [
                  Center(
                    child: Stack(
                      alignment: Alignment.bottomRight,
                      children: [
                        Hero(
                          tag: "profile_image",
                          child: CircleAvatar(
                            radius: 70,
                            backgroundImage:
                                _userImageFile != null
                                    ? FileImage(_userImageFile!)
                                    : AssetImage(_defaultImagePath)
                                        as ImageProvider,
                            backgroundColor: Colors.grey[200],
                          ),
                        ),
                        Positioned(
                          bottom: 5,
                          right: 5,
                          child: CircleAvatar(
                            backgroundColor: Colors.teal,
                            child: IconButton(
                              icon: const Icon(
                                Icons.camera_alt,
                                color: Colors.white,
                                size: 20,
                              ),
                              onPressed: _showImageSourceDialog,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                  Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                    elevation: 5,
                    margin: const EdgeInsets.only(bottom: 16),
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        children: [
                          _infoTile(Icons.person, "الاسم", name),
                          const Divider(),
                          _infoTile(Icons.phone, "الهاتف", phone),
                          const Divider(),
                          _infoTile(Icons.email, "البريد", email),
                        ],
                      ),
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: _updatePassword,
                    icon: const Icon(Icons.lock_reset),
                    label: const Text("تغيير كلمة المرور"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      padding: const EdgeInsets.symmetric(
                        vertical: 14,
                        horizontal: 24,
                      ),
                    ),
                  ),
                ],
              ),
          // 👨‍👩‍👧‍👦 تبويب الأبناء
          ParentStudent(
            firestore: _firestore,
            currentParentId: currentParentId,
            busNumber: busNumber,
          ),
        ],
      ),
    );
  }

  Widget _infoTile(IconData icon, String label, String value) {
    return Row(
      children: [
        Icon(icon, color: Colors.teal),
        const SizedBox(width: 12),
        Text(
          "$label: ",
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.black87,
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(color: Colors.black54, fontSize: 15),
          ),
        ),
      ],
    );
  }
}
