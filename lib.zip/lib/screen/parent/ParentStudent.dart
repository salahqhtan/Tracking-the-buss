import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/screen/parent/StudentDetails.dart';
import 'package:flutter/material.dart';

class ParentStudent extends StatelessWidget {
  const ParentStudent({
    super.key,
    required FirebaseFirestore firestore,
    required this.currentParentId,
    required this.busNumber,
  }) : _firestore = firestore;

  final FirebaseFirestore _firestore;
  final String currentParentId;
  final String? busNumber;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream:
          _firestore
              .collection('Student')
              .where('Parent_ID', isEqualTo: currentParentId)
              .snapshots(),
      builder: (context, snapshot) {
        // 🟢 حالة التحميل
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        // 🟠 حالة الخطأ
        if (snapshot.hasError) {
          return const Center(child: Text("حدث خطأ في تحميل البيانات."));
        }

        final students = snapshot.data?.docs ?? [];

        // 🔴 إذا لا يوجد بيانات
        if (students.isEmpty) {
          return const Center(
            child: Text(
              "لا توجد بيانات أبناء حالياً.",
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
            ),
          );
        }

        // ✅ عرض القائمة
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: students.length,
          itemBuilder: (context, index) {
            final student = students[index].data() as Map<String, dynamic>;
            final classId = student['Class_id'];

            return FutureBuilder<DocumentSnapshot>(
              future:
                  classId != null
                      ? _firestore.collection('Classes').doc(classId).get()
                      : null,
              builder: (context, classSnapshot) {
                String gradeName = 'غير معروف';

                if (classSnapshot.hasData && classSnapshot.data != null) {
                  final classData =
                      classSnapshot.data!.data() as Map<String, dynamic>?;
                  gradeName = classData?['Name'] ?? 'غير معروف';
                }

                return Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 5,
                  margin: const EdgeInsets.only(bottom: 12),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(16),
                    onTap: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder:
                              (_) => StudentDetailsPage(
                                studentId: students[index].id,
                                studentData: {
                                  ...student,
                                  'GradeName': gradeName,
                                },
                              ),
                        ),
                      );
                    },
                    child: ListTile(
                      contentPadding: const EdgeInsets.all(12),
                      leading: CircleAvatar(
                        radius: 28,
                        backgroundColor: Colors.blue.shade100,
                        child: Icon(
                          Icons.person,
                          size: 28,
                          color: Colors.blue.shade700,
                        ),
                      ),
                      title: Text(
                        student['Name'] ?? 'بدون اسم',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      subtitle: Padding(
                        padding: const EdgeInsets.only(top: 4),
                        child: Text(
                          "الصف: $gradeName\n"
                          "رقم الحافلة: ${busNumber ?? 'غير محدد'}",
                          style: const TextStyle(fontSize: 14),
                        ),
                      ),
                      trailing: Icon(
                        Icons.arrow_forward_ios,
                        size: 18,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ),
                );
              },
            );
          },
        );
      },
    );
  }
}
