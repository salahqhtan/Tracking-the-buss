import 'dart:async';
import 'dart:math' as math;
import 'package:darbk_new/screen/parent/widget/custom_scaffold.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class HomeParent extends StatefulWidget {
  const HomeParent({super.key});
  @override
  State<HomeParent> createState() => _HomeParentState();
}

class _HomeParentState extends State<HomeParent> with TickerProviderStateMixin {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  String? busNumber, driverName, routeName, routeStart, routeEnd;
  LatLng? parentLocation;

  bool _loading = true, _mapLoading = true;
  String? _liveBusId;

  GoogleMapController? _mapController;
  Marker? _busMarker;
  List<LatLng> _history = [];

  late AnimationController _animationController;
  Animation<LatLng>? _animation;
  LatLng? _prevPos;

  double? _distanceToParent;

  int _currentIndex = 0;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1500),
    );
    loadParentAndBusInfo();
  }

  Future<void> loadParentAndBusInfo() async {
    final uid = _auth.currentUser?.uid;
    if (uid == null) return;

    final parentDoc = await _firestore.collection('Parent').doc(uid).get();
    if (!parentDoc.exists) return;

    final parentData = parentDoc.data()!;
    final busId = parentData['Bus_ID'];

    if (busId == null) {
      setState(() => _loading = false);
      return;
    }

    if (parentData['lat'] != null && parentData['lng'] != null) {
      parentLocation = LatLng(parentData['lat'], parentData['lng']);
    }

    busNumber = busId.toString();
    final busQuery =
        await _firestore
            .collection('Bus')
            .where('Bus_number', isEqualTo: busId)
            .limit(1)
            .get();

    if (busQuery.docs.isEmpty) {
      setState(() => _loading = false);
      return;
    }

    final busDoc = busQuery.docs.first;
    _liveBusId = busDoc.id;
    final driverId = busDoc.data()['Driver_ID'];
    final routeId = busDoc.data()['Route_ID'];

    if (driverId != null) {
      final d = await _firestore.collection('Drivers').doc(driverId).get();
      driverName = d.data()?['Name'];
    }

    if (routeId != null) {
      final r = await _firestore.collection('Routes').doc(routeId).get();
      final rd = r.data();
      routeName = rd?['Name'];
      routeStart = rd?['Start_location'];
      routeEnd = rd?['End_location'];
    }

    setState(() => _loading = false);
    _listenLiveLocation();
  }

  void _listenLiveLocation() {
    if (_liveBusId == null) {
      setState(() => _mapLoading = false);
      return;
    }

    _firestore.collection('LiveLocation').doc(_liveBusId).snapshots().listen((
      snap,
    ) {
      final data = snap.data();
      if (data == null) return;

      final lat = data['lat'], lng = data['lng'];
      final p = LatLng(lat, lng);

      if (parentLocation != null) {
        _distanceToParent = _calculateDistance(
          parentLocation!.latitude,
          parentLocation!.longitude,
          lat,
          lng,
        );
      }

      if (_prevPos != null) {
        final tween = Tween<LatLng>(begin: _prevPos!, end: p);
        _animation = tween.animate(_animationController)..addListener(() {
          final pos = _animation!.value;
          _busMarker = Marker(
            markerId: const MarkerId('bus'),
            position: pos,
            icon: BitmapDescriptor.defaultMarkerWithHue(
              BitmapDescriptor.hueAzure,
            ),
            rotation: _bearing(
              _prevPos!.latitude,
              _prevPos!.longitude,
              p.latitude,
              p.longitude,
            ),
          );
          _mapController?.animateCamera(CameraUpdate.newLatLng(pos));
          setState(() {});
        });
        _animationController.forward(from: 0);
      } else {
        _busMarker = Marker(
          markerId: const MarkerId('bus'),
          position: p,
          icon: BitmapDescriptor.defaultMarkerWithHue(
            BitmapDescriptor.hueAzure,
          ),
        );
        setState(() {});
      }

      _history.add(p);
      _prevPos = p;
      setState(() => _mapLoading = false);
    });
  }

  double _toRadians(double degree) => degree * math.pi / 180;

  double _bearing(double lat1, double lon1, double lat2, double lon2) {
    final dLon = _toRadians(lon2 - lon1);
    final y = math.sin(dLon) * math.cos(_toRadians(lat2));
    final x =
        math.cos(_toRadians(lat1)) * math.sin(_toRadians(lat2)) -
        math.sin(_toRadians(lat1)) *
            math.cos(_toRadians(lat2)) *
            math.cos(dLon);
    final bearing = math.atan2(y, x);
    return (bearing * 180 / math.pi + 360) % 360;
  }

  double _calculateDistance(
    double lat1,
    double lon1,
    double lat2,
    double lon2,
  ) {
    const earthRadius = 6371;
    final dLat = _toRadians(lat2 - lat1);
    final dLon = _toRadians(lon2 - lon1);
    final a =
        math.sin(dLat / 2) * math.sin(dLat / 2) +
        math.cos(_toRadians(lat1)) *
            math.cos(_toRadians(lat2)) *
            math.sin(dLon / 2) *
            math.sin(dLon / 2);
    final c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a));
    return earthRadius * c;
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final uid = _auth.currentUser?.uid ?? '';

    return ScaffoldWithCustomAppBar(
      title: "الصفحة الرئيسية",
      parentId: uid,
      currentIndex: _currentIndex,
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xffe0f7fa), Color(0xff80deea)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child:
            _loading
                ? const Center(child: CircularProgressIndicator())
                : Column(
                  children: [
                    SizedBox(
                      height: 300,
                      child:
                          _mapLoading
                              ? const Center(child: CircularProgressIndicator())
                              : GoogleMap(
                                initialCameraPosition: CameraPosition(
                                  target:
                                      _history.isNotEmpty
                                          ? _history.last
                                          : const LatLng(15.3694, 44.1910),
                                  zoom: 16,
                                ),
                                markers:
                                    _busMarker != null ? {_busMarker!} : {},
                                polylines: {
                                  Polyline(
                                    polylineId: const PolylineId('route'),
                                    points: _history,
                                    color: Colors.blueAccent,
                                    width: 5,
                                  ),
                                },
                                onMapCreated: (c) => _mapController = c,
                              ),
                    ),
                    const SizedBox(height: 12),
                    if (_distanceToParent != null)
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 16),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.greenAccent, Colors.blueAccent],
                          ),
                          borderRadius: BorderRadius.circular(16),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 6,
                              offset: const Offset(0, 3),
                            ),
                          ],
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(
                              Icons.directions_bus,
                              color: Colors.white,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              "المسافة المتبقية: ${_distanceToParent!.toStringAsFixed(2)} كم",
                              style: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                          ],
                        ),
                      ),
                    const SizedBox(height: 16),
                    Expanded(
                      child: ListView(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        children: [
                          _infoCard("تفاصيل الحافلة", [
                            "رقم الحافلة: ${busNumber ?? '-'}",
                            "اسم السائق: ${driverName ?? '-'}",
                          ]),
                          const SizedBox(height: 12),
                          _infoCard("تفاصيل المسار", [
                            "اسم المسار: ${routeName ?? '-'}",
                            "نقطة البداية: ${routeStart ?? '-'}",
                            "نقطة النهاية: ${routeEnd ?? '-'}",
                          ]),
                        ],
                      ),
                    ),
                  ],
                ),
      ),
    );
  }

  Widget _infoCard(String title, List<String> details) {
    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 4,
      shadowColor: Colors.black26,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            for (var d in details)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 4),
                child: Text(d, style: const TextStyle(fontSize: 16)),
              ),
          ],
        ),
      ),
    );
  }
}
