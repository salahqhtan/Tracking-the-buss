import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/screen/parent/widget/custom_scaffold.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class NotificationsParent extends StatelessWidget {
  const NotificationsParent({Key? key}) : super(key: key);

  IconData getIcon(String type) {
    switch (type) {
      case 'تنبيه':
        return Icons.warning_amber_rounded;
      case 'غياب':
        return Icons.person_off;
      case 'رسمي':
        return Icons.announcement_rounded;
      case 'عام':
        return Icons.campaign_rounded;
      default:
        return Icons.notifications;
    }
  }

  Color getColor(String type) {
    switch (type) {
      case 'تنبيه':
        return Colors.orange.shade600;
      case 'غياب':
        return Colors.red.shade600;
      case 'رسمي':
        return Colors.blue.shade600;
      case 'عام':
        return Colors.green.shade600;
      default:
        return Colors.grey.shade600;
    }
  }

  @override
  Widget build(BuildContext context) {
    final currentUserId = FirebaseAuth.instance.currentUser?.uid ?? '';

    return ScaffoldWithCustomAppBar(
      title: "الإشعارات",
      parentId: currentUserId,
      currentIndex: 1,
      body: StreamBuilder<QuerySnapshot>(
        stream:
            FirebaseFirestore.instance
                .collection('Notifications')
                .where('Receiver_ID', isEqualTo: currentUserId)
                .orderBy('Send_date', descending: true)
                .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }

          if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
            return const Center(
              child: Text(
                'لا توجد إشعارات حالياً.',
                style: TextStyle(fontSize: 18, color: Colors.grey),
              ),
            );
          }

          final notifications = snapshot.data!.docs;

          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            itemCount: notifications.length,
            itemBuilder: (context, index) {
              final data = notifications[index].data() as Map<String, dynamic>;
              final type = data['Type'] ?? 'غير معروف';
              final message = data['Message'] ?? '';
              final timestamp = data['Send_date'] as Timestamp?;
              final isRead = data['isRead'] ?? false;

              final date =
                  timestamp != null
                      ? DateFormat(
                        'yyyy/MM/dd – hh:mm a',
                      ).format(timestamp.toDate())
                      : 'غير معروف';

              return GestureDetector(
                onTap: () {
                  // يمكن إضافة تفاعل عند الضغط على الإشعار
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 250),
                  margin: const EdgeInsets.only(bottom: 14),
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    gradient:
                        isRead
                            ? LinearGradient(
                              colors: [Colors.white, Colors.white],
                            )
                            : LinearGradient(
                              colors: [
                                getColor(type).withOpacity(0.1),
                                getColor(type).withOpacity(0.05),
                              ],
                            ),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: getColor(type), width: 1),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 6,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Stack(
                        children: [
                          CircleAvatar(
                            radius: 24,
                            backgroundColor: getColor(type).withOpacity(0.2),
                            child: Icon(
                              getIcon(type),
                              size: 26,
                              color: getColor(type),
                            ),
                          ),
                          if (!isRead)
                            Positioned(
                              top: 0,
                              right: 0,
                              child: Container(
                                width: 12,
                                height: 12,
                                decoration: BoxDecoration(
                                  color: Colors.redAccent,
                                  shape: BoxShape.circle,
                                ),
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              type,
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: getColor(type),
                              ),
                            ),
                            const SizedBox(height: 6),
                            Text(
                              message,
                              style: const TextStyle(
                                fontSize: 15,
                                color: Colors.black87,
                              ),
                            ),
                            const SizedBox(height: 6),
                            Align(
                              alignment: Alignment.bottomRight,
                              child: Text(
                                date,
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
