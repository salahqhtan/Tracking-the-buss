// استيراد حزمة Firebase Firestore للتعامل مع قاعدة البيانات السحابية
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/Data.dart';

import 'package:darbk_new/Widget/Messages.dart';

import 'package:darbk_new/loading.dart';
import 'package:darbk_new/screen/admin/homeScreenAddmin.dart';
import 'package:darbk_new/screen/driver/HomeDriver.dart';
import 'package:darbk_new/screen/parent/ParentDashboard.dart';

// استيراد حزمة Firebase Auth لتسجيل الدخول والمصادقة
import 'package:firebase_auth/firebase_auth.dart';

// استيراد الحزمة الأساسية لتصميم الواجهات
import 'package:flutter/material.dart';
import 'package:awesome_dialog/awesome_dialog.dart';

// استيراد شاشة لوحة تحكم المدير

// استيراد شاشة الطالب (يمكن تغييرها لاحقاً حسب الدور)

// استيراد شاشة إنشاء حساب جديد
// import 'signup_screen.dart';

// تعريف شاشة المدير
class AdminPage extends StatelessWidget {
  const AdminPage({super.key});

  @override
  Widget build(BuildContext context) =>
      Scaffold(body: Center(child: Text('مرحبا بك أيها المدير')));
}

// تعريف شاشة المعلم
class TeacherPage extends StatelessWidget {
  const TeacherPage({super.key});

  @override
  Widget build(BuildContext context) =>
      Scaffold(body: Center(child: Text('مرحبا بك أيها المعلم')));
}

// تعريف شاشة الطالب
class StudentPage extends StatelessWidget {
  const StudentPage({super.key});

  @override
  Widget build(BuildContext context) =>
      Scaffold(body: Center(child: Text('مرحبا بك أيها الطالب')));
}

// تعريف شاشة تسجيل الدخول كـ Stateful Widget
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  // متغيرات للتحكم في النصوص المدخلة
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  // إنشاء مثيل من Firebase Auth لتسجيل الدخول
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // إنشاء مثيل من Firestore للوصول إلى قاعدة البيانات
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // متغير لتحديد ما إذا كانت عملية تسجيل الدخول جارية
  bool _isLoading = false;
  String selectedRole = 'parent';
  List<Map<dynamic, dynamic>> allroles = [
    {'title': 'ولي الأمر', 'role': 'parent'},
    {'title': 'سائق', 'role': 'driver'},
    {'title': 'طالب', 'role': 'student'},
    {'title': 'إدارة المدرسة', 'role': 'admin'},
  ];

  Future<void> _login() async {
    String email = _emailController.text.trim();
    String password = _passwordController.text;

    if (email.isEmpty || password.isEmpty) {
      AwesomeDialog(
        context: context,
        animType: AnimType.rightSlide,
        dialogType: DialogType.warning,
        title: 'تنبيه',
        desc: 'يرجى إدخال البريد وكلمة المرور',
        btnOkOnPress: () {},
      ).show();
      return;
    }

    setState(() {
      _isLoading = true;
    });

    try {
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      DocumentSnapshot userDoc =
          await _firestore
              .collection('users')
              .doc(userCredential.user!.uid)
              .get();

      if (!userDoc.exists) {
        throw Exception("المستخدم غير موجود في قاعدة البيانات");
      }

      String rolesDoc = userDoc.get('roles');

      if (rolesDoc != selectedRole) {
        msg('خطأ في الصلاحيات', Colors.red);
        return;
      }

      if (selectedRole == 'admin') {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => HomeAdmin()),
        );
      } else if (selectedRole == 'driver') {
        final driverId = FirebaseAuth.instance.currentUser!.uid;

        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => HomeDriver(driverId: driverId)),
        );
      } else if (selectedRole == 'parent') {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => HomeParent()),
        );
      } else if (selectedRole == 'student') {
        Navigator.pushReplacement(
          context,
          MaterialPageRoute(builder: (_) => HomeParent()),
        );
      } else {
        throw Exception("دور غير معروف: $selectedRole");
      }

      await DataUser.save('type', '$selectedRole');
      await DataUser.save('role', '$selectedRole');

      if (DataUser.get('nameSchool') == null) {
        DataUser.save('nameSchool', 'أسم المدرسة');
      }
    } on FirebaseAuthException catch (e) {
      AwesomeDialog(
        context: context,
        animType: AnimType.rightSlide,
        dialogType: DialogType.error,
        title: 'خطأ في تسجيل الدخول',
        desc: e.message ?? 'حدث خطأ أثناء تسجيل الدخول',
        btnOkOnPress: () {},
      ).show();
    } catch (e) {
      AwesomeDialog(
        context: context,
        animType: AnimType.rightSlide,
        dialogType: DialogType.error,
        title: 'خطأ',
        desc: 'حدث خطأ:\n$e',
        btnOkOnPress: () {},
      ).show();
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Stack(
          children: [
            SizedBox.expand(
              child: Image.asset("assets/images/login1.png", fit: BoxFit.cover),
            ),

            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.black.withOpacity(0.4),
                    Colors.black.withOpacity(0.2),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
            ),

            Center(
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 400, minWidth: 200),
                child: Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color.fromARGB(
                      255,
                      20,
                      139,
                      147,
                    ).withOpacity(0.50), // لون أبيض شفاف (25% شفافية)
                    borderRadius: BorderRadius.circular(
                      20,
                    ), // حواف دائرية للمربع
                    boxShadow: [
                      BoxShadow(
                        color: const Color.fromARGB(
                          255,
                          0,
                          0,
                          0,
                        ).withOpacity(0.4), // ظل خفيف
                        blurRadius: 10,
                        offset: Offset(0, 6),
                      ),
                    ],
                  ),
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        const SizedBox(height: 30),

                        Container(
                          padding: const EdgeInsets.all(4),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            gradient: const LinearGradient(
                              colors: [
                                Color.fromARGB(255, 252, 254, 255),
                                Color(0xFF0E4D64),
                              ],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                          ),
                          child: CircleAvatar(
                            radius: 40,
                            backgroundColor: Colors.white.withOpacity(0.2),
                            child: Image.asset(
                              "assets/images/icon_login.png",
                              width: 50,
                              height: 50,
                            ),
                          ),
                        ),
                        const SizedBox(height: 10),

                        const Text(
                          "دربكـ",
                          style: TextStyle(
                            fontSize: 45,
                            fontWeight: FontWeight.w900,
                            color: Color.fromARGB(255, 247, 251, 253),
                            shadows: [
                              Shadow(
                                offset: Offset(2, 2),
                                blurRadius: 5,
                                color: Colors.black54,
                              ),
                            ],
                          ),
                        ),

                        const SizedBox(height: 40),

                        TextField(
                          controller: _emailController,
                          keyboardType: TextInputType.emailAddress,
                          style: const TextStyle(color: Colors.black),
                          decoration: InputDecoration(
                            label: Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Text(
                                'البريد الإلكتروني',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ),
                            labelStyle: const TextStyle(color: Colors.black54),
                            prefixIcon: const Icon(
                              Icons.email,
                              color: Colors.black54,
                            ),
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                              borderSide: BorderSide.none,
                            ),
                          ),
                        ),

                        const SizedBox(height: 20),

                        TextField(
                          controller: _passwordController,
                          obscureText: true,
                          style: const TextStyle(color: Colors.black),
                          decoration: InputDecoration(
                            label: Padding(
                              padding: const EdgeInsets.only(top: 8.0),
                              child: Text(
                                'كلمة المرور',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                            ),
                            labelStyle: const TextStyle(color: Colors.black54),
                            prefixIcon: const Icon(
                              Icons.lock,
                              color: Colors.black54,
                            ),
                            filled: true,
                            fillColor: Colors.white,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                              borderSide: BorderSide.none,
                            ),
                          ),
                        ),
                        SizedBox(height: 20),

                        Container(
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: Colors.white,
                          ),
                          child: DropdownButtonFormField<dynamic>(
                            borderRadius: BorderRadius.circular(20),
                            alignment: Alignment.center,
                            decoration: InputDecoration(
                              fillColor: Colors.white,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(15),
                                borderSide: BorderSide.none,
                              ),
                            ),
                            value: selectedRole,
                            items:
                                allroles
                                    .map(
                                      (ctx) => DropdownMenuItem<dynamic>(
                                        alignment: Alignment.centerRight,
                                        value: ctx['role'],
                                        child: Text(ctx['title']),
                                      ),
                                    )
                                    .toList(),
                            onChanged: (val) {
                              setState(() {
                                selectedRole = val!;
                                print(selectedRole);
                              });
                            },
                          ),
                        ),

                        const SizedBox(height: 40),

                        SizedBox(
                          width: double.infinity,
                          child: ElevatedButton.icon(
                            icon: const Icon(
                              Icons.login,
                              size: 22,
                              color: Colors.white,
                            ),
                            style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(15),
                              ),
                              elevation: 5,
                              shadowColor: Colors.black54,
                              backgroundColor: const Color(0xFF2AA6CF),
                            ),
                            onPressed: _login,
                            label: const Text(
                              'دخول',
                              style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                              ),
                            ),
                          ),
                        ),

                        const SizedBox(height: 20),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            if (_isLoading == true) Loading(),
          ],
        ),
      ),
    );
  }
}
