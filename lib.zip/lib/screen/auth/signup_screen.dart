import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class RegisterUserPage extends StatefulWidget {
  const RegisterUserPage({super.key});

  @override
  State<RegisterUserPage> createState() => _RegisterUserPageState();
}

class _RegisterUserPageState extends State<RegisterUserPage> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  String selectedRole = 'parent';

  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  bool _isLoading = false;

  final _formKey = GlobalKey<FormState>();

  Future<void> registerUser() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() {
      _isLoading = true;
    });

    try {
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(
            email: emailController.text.trim(),
            password: passwordController.text.trim(),
          );

      String uid = userCredential.user!.uid;
      String relatedId = "";

      if (selectedRole == 'employee') {
        DocumentReference ref = await _firestore.collection('employees').add({
          'name': nameController.text,
          'created_at': FieldValue.serverTimestamp(),
        });
        relatedId = ref.id;
      } else if (selectedRole == 'parent') {
        DocumentReference ref = await _firestore.collection('parents').add({
          'name': nameController.text,
          'phone': '',
          'created_at': FieldValue.serverTimestamp(),
        });
        relatedId = ref.id;
      } else if (selectedRole == 'driver') {
        DocumentReference ref = await _firestore.collection('drivers').add({
          'name': nameController.text,
          'license': '',
          'created_at': FieldValue.serverTimestamp(),
        });
        relatedId = ref.id;
      } else if (selectedRole == 'student') {
        DocumentReference ref = await _firestore.collection('students').add({
          'name': nameController.text,
          'class': '',
          'created_at': FieldValue.serverTimestamp(),
        });
        relatedId = ref.id;
      }

      await _firestore.collection('users').doc(uid).set({
        'id': uid,
        'name': nameController.text,
        'email': emailController.text.trim(),
        'roles': selectedRole,
        'related_id': relatedId,
      });

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text("تم التسجيل بنجاح ✅"),
            backgroundColor: Colors.green,
          ),
        );
        Navigator.pop(context); // العودة للخلف بعد التسجيل
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("خطأ: $e"), backgroundColor: Colors.redAccent),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text("تسجيل مستخدم جديد"),
          backgroundColor: const Color(0xFF2AA6CF),
          elevation: 6,
          shadowColor: Colors.black45,
        ),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF2196F3), Color(0xFF0D47A1)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 40),
              child: Card(
                color: Colors.white.withOpacity(0.95),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(25),
                ),
                elevation: 15,
                shadowColor: Colors.blueAccent.withOpacity(0.4),
                child: Padding(
                  padding: const EdgeInsets.all(28.0),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // الاسم
                        TextFormField(
                          controller: nameController,
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'يرجى إدخال الاسم';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            labelText: "الاسم",
                            prefixIcon: const Icon(Icons.person_outline),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),

                        // البريد الإلكتروني
                        TextFormField(
                          controller: emailController,
                          keyboardType: TextInputType.emailAddress,
                          validator: (value) {
                            if (value == null || value.trim().isEmpty) {
                              return 'يرجى إدخال البريد الإلكتروني';
                            }
                            if (!RegExp(
                              r'^[^@]+@[^@]+\.[^@]+',
                            ).hasMatch(value)) {
                              return 'يرجى إدخال بريد إلكتروني صحيح';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            labelText: "البريد الإلكتروني",
                            prefixIcon: const Icon(Icons.email_outlined),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),

                        // كلمة المرور
                        TextFormField(
                          controller: passwordController,
                          obscureText: true,
                          validator: (value) {
                            if (value == null || value.length < 6) {
                              return 'يجب أن تكون كلمة المرور 6 أحرف على الأقل';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                            labelText: "كلمة المرور",
                            prefixIcon: const Icon(Icons.lock_outline),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                          ),
                        ),
                        const SizedBox(height: 20),

                        // اختيار الدور
                        InputDecorator(
                          decoration: InputDecoration(
                            labelText: "الدور",
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 4,
                            ),
                          ),
                          child: DropdownButtonHideUnderline(
                            child: DropdownButton<String>(
                              value: selectedRole,
                              isExpanded: true,
                              items: const [
                                DropdownMenuItem(
                                  value: 'admin',
                                  child: Text('مدير'),
                                ),
                                DropdownMenuItem(
                                  value: 'employee',
                                  child: Text('موظف'),
                                ),
                                DropdownMenuItem(
                                  value: 'parent',
                                  child: Text('ولي أمر'),
                                ),
                                DropdownMenuItem(
                                  value: 'driver',
                                  child: Text('سائق'),
                                ),
                                DropdownMenuItem(
                                  value: 'student',
                                  child: Text('طالب'),
                                ),
                              ],
                              onChanged: (value) {
                                if (value != null) {
                                  setState(() {
                                    selectedRole = value;
                                  });
                                }
                              },
                            ),
                          ),
                        ),

                        const SizedBox(height: 35),

                        // زر التسجيل
                        _isLoading
                            ? const CircularProgressIndicator(
                              color: Color(0xFF2AA6CF),
                            )
                            : SizedBox(
                              width: double.infinity,
                              child: ElevatedButton(
                                onPressed: registerUser,
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: const Color(0xFF2AA6CF),
                                  padding: const EdgeInsets.symmetric(
                                    vertical: 16,
                                  ),
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(15),
                                  ),
                                  elevation: 6,
                                  shadowColor: Colors.black45,
                                ),
                                child: const Text(
                                  "تسجيل",
                                  style: TextStyle(
                                    fontSize: 22,
                                    fontWeight: FontWeight.bold,
                                    letterSpacing: 1,
                                  ),
                                ),
                              ),
                            ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
