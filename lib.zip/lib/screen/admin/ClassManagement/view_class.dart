import 'package:cloud_firestore/cloud_firestore.dart'; // مكتبة Firebase Firestore للتعامل مع قاعدة البيانات

import 'package:darbk_new/Widget/Messages.dart'; // استيراد مكتبة الرسائل (رسائل الخطأ أو النجاح)

import 'package:flutter/material.dart'; // مكتبة Flutter الأساسية لبناء الواجهة

// تبويب عرض الصفوف مع إمكانية الحذف
class ViewClassesTab extends StatefulWidget {
  const ViewClassesTab({super.key});

  @override
  State<ViewClassesTab> createState() => _ViewClassesTabState();
}

class _ViewClassesTabState extends State<ViewClassesTab> {
  final CollectionReference classesCollection = FirebaseFirestore.instance
      .collection('Classes');

  Future<void> deleteClass(String docId) async {
    try {
      await classesCollection.doc(docId).delete();
      msg('تم حذف الصف بنجاح', Colors.green);
    } catch (e) {
      msg('حدث خطأ أثناء الحذف: $e', Colors.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: classesCollection.orderBy('Number').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(child: Text('حدث خطأ: ${snapshot.error}'));
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }
        final docs = snapshot.data!.docs;
        if (docs.isEmpty) {
          return const Center(child: Text('لا توجد صفوف حتى الآن'));
        }
        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: docs.length,
          itemBuilder: (context, index) {
            final doc = docs[index];
            final stage = doc.get('Stage') ?? '';
            final name = doc.get('Name') ?? '';
            final number = doc.get('Number') ?? 0;
            return Card(
              margin: const EdgeInsets.symmetric(vertical: 6),
              child: ListTile(
                title: Text('الصف: $name'),
                subtitle: Text('المرحلة: $stage\nالرقم: $number'),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed:
                      () => showDialog(
                        context: context,
                        builder:
                            (ctx) => AlertDialog(
                              title: const Text('تأكيد الحذف'),
                              content: const Text(
                                'هل أنت متأكد من حذف هذا الصف؟',
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.of(ctx).pop(),
                                  child: const Text('إلغاء'),
                                ),
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(ctx).pop();
                                    deleteClass(doc.id);
                                  },
                                  child: const Text(
                                    'حذف',
                                    style: TextStyle(color: Colors.red),
                                  ),
                                ),
                              ],
                            ),
                      ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
