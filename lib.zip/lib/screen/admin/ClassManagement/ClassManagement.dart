import 'package:darbk_new/screen/admin/ClassManagement/add_class.dart';
import 'package:darbk_new/screen/admin/ClassManagement/view_class.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart'; // شريط التنقل السفلي المخصص للإدارة
import 'package:flutter/material.dart'; // مكتبة Flutter الأساسية لبناء الواجهة

// صفحة إدارة الصفوف مع تبويبات
class ClassManagementScreen extends StatefulWidget {
  const ClassManagementScreen({super.key});

  @override
  State<ClassManagementScreen> createState() => _ClassManagementScreenState();
}

class _ClassManagementScreenState extends State<ClassManagementScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        // 👈 لازم هنا
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: const Color.fromARGB(255, 150, 229, 240),
            title: const Text(
              'إدارة السائقين',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 25),
            ),
            bottom: TabBar(
              controller: _tabController,
              tabs: const [Tab(text: 'إضافة صف'), Tab(text: 'عرض الصفوف')],
            ),
          ),
          body: TabBarView(
            controller: _tabController,
            children: const [AddClassesTab(), ViewClassesTab()],
          ),
          bottomNavigationBar: CustomBottomNav(currentIndex: 6),
        ),
      ),
    );
  }
}

// تبويب إضافة الصفوف
