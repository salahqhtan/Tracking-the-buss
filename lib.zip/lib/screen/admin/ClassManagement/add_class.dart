import 'package:cloud_firestore/cloud_firestore.dart'; // مكتبة Firebase Firestore للتعامل مع قاعدة البيانات
import 'package:darbk_new/Color.dart'; // استيراد ألوان مخصصة للمشروع
import 'package:darbk_new/Widget/Messages.dart'; // استيراد مكتبة الرسائل (رسائل الخطأ أو النجاح)

import 'package:flutter/material.dart'; // مكتبة Flutter الأساسية لبناء الواجهة

class AddClassesTab extends StatefulWidget {
  const AddClassesTab({super.key});

  @override
  State<AddClassesTab> createState() => _AddClassesTabState();
}

class _AddClassesTabState extends State<AddClassesTab> {
  final TextEditingController stageController = TextEditingController();
  final TextEditingController nameController = TextEditingController();

  Future<void> saveClass() async {
    if (stageController.text.isEmpty || nameController.text.isEmpty) {
      msg('يرجى تعبئة جميع الحقول', Colors.red);
      return;
    }

    try {
      QuerySnapshot querySnapshot =
          await FirebaseFirestore.instance
              .collection('Classes')
              .orderBy('Number', descending: true)
              .limit(1)
              .get();

      int newNumber = 1;
      if (querySnapshot.docs.isNotEmpty) {
        var maxNumber = querySnapshot.docs.first.get('Number') as int;
        newNumber = maxNumber + 1;
      }

      await FirebaseFirestore.instance.collection('Classes').add({
        'Stage': stageController.text.trim(),
        'Name': nameController.text.trim(),
        'Number': newNumber,
      });

      msg('تم إضافة الصف بنجاح', Colors.green);

      stageController.clear();
      nameController.clear();
    } catch (e) {
      msg('حدث خطأ أثناء الإضافة: $e', Colors.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 600, minWidth: 220),
          child: Card(
            color: ScreenColorS.card,
            margin: const EdgeInsets.all(10),
            child: Container(
              padding: const EdgeInsets.all(10),
              child: ListView(
                shrinkWrap: true,
                children: [
                  TextFormField(
                    controller: stageController,
                    decoration: InputDecoration(
                      labelText: 'المرحلة',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: nameController,
                    decoration: InputDecoration(
                      labelText: 'اسم الصف',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ScreenColorS.focuseBorder,
                    ),
                    onPressed: saveClass,
                    child: const Text(
                      'إضافة صف',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
