import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:darbk_new/screen/admin/add_usere.dart';
import 'package:darbk_new/screen/admin/view_admin.dart';
import 'package:darbk_new/screen/admin/widget/CustomAppBar.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';
import 'package:flutter/material.dart';

class NoAccessPage extends StatelessWidget {
  const NoAccessPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'هذه الصفحة مخصصة فقط لمستخدمي الإدارة',
        style: TextStyle(fontSize: 18, color: Colors.orange),
        textAlign: TextAlign.center,
      ),
    );
  }
}

class SubjectiveAdmin extends StatefulWidget {
  const SubjectiveAdmin({super.key});

  @override
  State<SubjectiveAdmin> createState() => _SubjectiveAdminState();
}

class _SubjectiveAdminState extends State<SubjectiveAdmin>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<Tab> tabs = [];
  List<Widget> tabViews = [];
  String? userRole;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchUserRoleAndSetupTabs();
  }

  Future<void> fetchUserRoleAndSetupTabs() async {
    try {
      User? user = FirebaseAuth.instance.currentUser;
      if (user == null) {
        setState(() {
          isLoading = false;
        });
        return;
      }

      DocumentSnapshot userDoc =
          await FirebaseFirestore.instance
              .collection('users') // تأكد من اسم المجموعة صحيح
              .doc(user.uid)
              .get();

      if (!userDoc.exists) {
        setState(() {
          isLoading = false;
        });
        return;
      }

      userRole = userDoc.get('roles');

      if (userRole == 'admin') {
        tabs = const [Tab(text: 'إضافة حساب'), Tab(text: 'عرض الحسابات')];
        tabViews = const [AddAccountPage(), UsersListWidget()];
      } else if (userRole == 'employee') {
        tabs = const [Tab(text: 'عرض الحسابات')];
        tabViews = const [UsersListWidget()];
      } else {
        // لباقي الأدوار نعرض صفحة واحدة فقط بدون تبويبات
        tabs = [];
        tabViews = [];
      }

      // إنشاء TabController فقط إذا لدينا تبويبات
      if (tabs.isNotEmpty) {
        _tabController = TabController(length: tabs.length, vsync: this);
      }

      setState(() {
        isLoading = false;
      });
    } catch (e) {
      print('Error fetching user role: $e');
      setState(() {
        isLoading = false;
      });
    }
  }

  @override
  void dispose() {
    if (tabs.isNotEmpty) {
      _tabController.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return Directionality(
        textDirection: TextDirection.rtl,
        child: Scaffold(body: Center(child: CircularProgressIndicator())),
      );
    }

    if (tabs.isEmpty) {
      // عرض صفحة مختلفة لباقي الأدوار
      return Directionality(
        textDirection: TextDirection.rtl,
        child: ScaffoldWithCustomAppBar(
          title: 'تنبيه',
          body: const NoAccessPage(),
          bottomNavigationBar: CustomBottomNav(currentIndex: 3),
        ),
      );
    }

    // لو التبويبات موجودة - عرضها
    return Directionality(
      textDirection: TextDirection.rtl,
      child: ScaffoldWithCustomAppBar(
        title: 'حسابي',
        bottom: TabBar(
          controller: _tabController,
          tabs: tabs,
          indicatorColor: Colors.black,
          labelStyle: const TextStyle(fontWeight: FontWeight.bold),
        ),
        body: TabBarView(controller: _tabController, children: tabViews),
        bottomNavigationBar: CustomBottomNav(currentIndex: 3),
      ),
    );
  }
}
