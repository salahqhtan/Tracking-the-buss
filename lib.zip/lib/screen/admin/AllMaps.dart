import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/screen/admin/widget/CustomAppBar.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';
import 'package:flutter/material.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'dart:async';

class LatLngTween extends Tween<LatLng> {
  LatLngTween({required LatLng begin, required LatLng end})
    : super(begin: begin, end: end);

  @override
  LatLng lerp(double t) {
    return LatLng(
      begin!.latitude + (end!.latitude - begin!.latitude) * t,
      begin!.longitude + (end!.longitude - begin!.longitude) * t,
    );
  }
}

class AllMaps extends StatefulWidget {
  const AllMaps({super.key});

  @override
  State<AllMaps> createState() => _AllMapsState();
}

class _AllMapsState extends State<AllMaps> with TickerProviderStateMixin {
  GoogleMapController? _mapController;
  LatLng _defaultPosition = const LatLng(15.3694, 44.1910);
  Marker? _busMarker;
  LatLng? _previousPosition;
  Timer? _updateTimer;

  late AnimationController _animationController;
  Animation<LatLng>? _animation;

  List<String> _busIds = [];
  String? _selectedBusId;

  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _loadBusIds();
  }

  Future<void> _loadBusIds() async {
    try {
      final querySnapshot =
          await FirebaseFirestore.instance.collection('LiveLocation').get();
      final ids = querySnapshot.docs.map((doc) => doc.id).toList();

      if (ids.isEmpty) {
        setState(() {
          _error = 'لا توجد حافلات متاحة';
          _loading = false;
        });
        return;
      }

      setState(() {
        _busIds = ids;
        _selectedBusId = ids.first;
        _loading = false;
      });

      _startLiveTracking();
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  void _startLiveTracking() {
    _updateTimer?.cancel();
    _previousPosition = null;
    _busMarker = null;

    if (_selectedBusId == null) return;

    _updateTimer = Timer.periodic(const Duration(seconds: 3), (_) async {
      final doc =
          await FirebaseFirestore.instance
              .collection('LiveLocation')
              .doc(_selectedBusId)
              .get();
      final data = doc.data();
      if (data != null) {
        final lat = data['lat'] as double;
        final lng = data['lng'] as double;
        final currentPos = LatLng(lat, lng);

        if (_previousPosition != null &&
            (_previousPosition!.latitude != currentPos.latitude ||
                _previousPosition!.longitude != currentPos.longitude)) {
          final tween = LatLngTween(begin: _previousPosition!, end: currentPos);

          _animation = tween.animate(_animationController)..addListener(() {
            final pos = _animation!.value;
            _busMarker = Marker(
              markerId: const MarkerId("bus"),
              position: pos,
              icon: BitmapDescriptor.defaultMarkerWithHue(
                BitmapDescriptor.hueBlue,
              ),
            );
            _mapController?.animateCamera(CameraUpdate.newLatLng(pos));
            setState(() {});
          });

          _animationController.forward(from: 0);
        } else {
          _busMarker = Marker(
            markerId: const MarkerId("bus"),
            position: currentPos,
            icon: BitmapDescriptor.defaultMarkerWithHue(
              BitmapDescriptor.hueBlue,
            ),
          );
          setState(() {});
          _mapController?.animateCamera(
            CameraUpdate.newLatLngZoom(currentPos, 15),
          );
        }

        _previousPosition = currentPos;
      }
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    _updateTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    if (_error != null) {
      return Scaffold(body: Center(child: Text(_error!)));
    }

    return Directionality(
      textDirection: TextDirection.rtl,
      child: ScaffoldWithCustomAppBar(
        title: "تتبع الحافلات",
        body: Stack(
          children: [
            GoogleMap(
              initialCameraPosition: CameraPosition(
                target: _busMarker?.position ?? _defaultPosition,
                zoom: 15,
              ),
              markers: _busMarker != null ? {_busMarker!} : {},
              onMapCreated: (controller) => _mapController = controller,
              myLocationEnabled: true,
            ),

            // أزرار الحافلات في أسفل الشاشة:
            Positioned(
              bottom: 20,
              left: 10,
              right: 10,
              child: SizedBox(
                height: 50,
                child: ListView.separated(
                  scrollDirection: Axis.horizontal,
                  itemCount: _busIds.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 10),
                  itemBuilder: (context, index) {
                    final busId = _busIds[index];
                    final isSelected = busId == _selectedBusId;

                    return ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor:
                            isSelected ? Colors.green : Colors.grey,
                      ),
                      onPressed: () {
                        setState(() {
                          _selectedBusId = busId;
                        });
                        _startLiveTracking();
                      },
                      child: Text('حافلة $busId'),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
        bottomNavigationBar: CustomBottomNav(currentIndex: 8),
      ),
    );
  }
}
