import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:darbk_new/Widget/Messages.dart';

import 'package:flutter/material.dart';

class AddSubjectPage extends StatefulWidget {
  const AddSubjectPage({super.key});

  @override
  State<AddSubjectPage> createState() => _AddSubjectPageState();
}

class _AddSubjectPageState extends State<AddSubjectPage> {
  List<TextEditingController> subjectControllers = [TextEditingController()];
  String? selectedClassId;
  List<Map<String, dynamic>> classes = [];
  int numberSubject = 1;

  @override
  void initState() {
    super.initState();
    fetchClasses();
  }

  Future<void> fetchClasses() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('Classes').get();
    setState(() {
      classes =
          snapshot.docs
              .map((doc) => {'id': doc.id, 'name': doc['Name'] ?? ''})
              .toList();
    });
  }

  void addSubjectField() {
    if (numberSubject >= 11) {
      msg("لا يمكنك إضافة أكثر من 11 مادة", Colors.red);
      return;
    }

    setState(() {
      numberSubject += 1;
      subjectControllers.add(TextEditingController());
    });
  }

  Future<void> saveSubjects() async {
    if (selectedClassId == null) {
      msg('يرجى اختيار الصف', Colors.red);
      return;
    }

    final existingSubjectsSnapshot =
        await FirebaseFirestore.instance
            .collection('Subjects')
            .where('Class_id', isEqualTo: selectedClassId)
            .get();

    final existingNames =
        existingSubjectsSnapshot.docs
            .map((doc) => doc['Name'].toString().trim())
            .toList();

    List<String> added = [];

    for (var controller in subjectControllers) {
      final name = controller.text.trim();
      if (name.isEmpty) continue;

      if (existingNames.contains(name)) {
        continue; // تجاهل المادة المكررة
      }

      await FirebaseFirestore.instance.collection('Subjects').add({
        'Name': name,
        'Class_id': selectedClassId,
      });

      added.add(name);
    }

    if (added.isEmpty) {
      msg('لم يتم إضافة مواد جديدة (قد تكون مكررة)', Colors.orange);
    } else {
      msg('تمت إضافة ${added.length} مادة بنجاح', Colors.green);
    }

    setState(() {
      subjectControllers = [TextEditingController()];
      numberSubject = 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 600, minWidth: 220),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'إضافة مواد للصف',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.bold,
                      color: Colors.teal[800],
                    ),
                  ),
                  const SizedBox(height: 20),

                  // Dropdown الصف
                  DropdownButtonFormField<dynamic>(
                    value: selectedClassId,
                    items:
                        classes
                            .map(
                              (cls) => DropdownMenuItem(
                                value: cls['id'],
                                child: Text(cls['name']),
                              ),
                            )
                            .toList(),
                    onChanged: (val) => setState(() => selectedClassId = val),
                    decoration: InputDecoration(
                      labelText: 'اختر الصف',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      filled: true,
                      fillColor: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 20),

                  // حقول المواد
                  ...subjectControllers.asMap().entries.map((entry) {
                    final index = entry.key;
                    final controller = entry.value;

                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: TextFormField(
                        controller: controller,
                        decoration: InputDecoration(
                          labelText: 'اسم المادة ${index + 1}',
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          filled: true,
                          fillColor: Colors.white,
                          prefixIcon: const Icon(
                            Icons.book,
                            color: Colors.teal,
                          ),
                        ),
                      ),
                    );
                  }).toList(),

                  const SizedBox(height: 10),
                  Row(
                    children: [
                      IconButton(
                        onPressed: addSubjectField,
                        icon: Icon(
                          Icons.add_circle,
                          color: Colors.teal[700],
                          size: 32,
                        ),
                      ),
                      const SizedBox(width: 10),
                      const Text(
                        'إضافة مادة جديدة',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),

                  // زر الحفظ
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.teal[700],
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(25),
                      ),
                    ),
                    onPressed: saveSubjects,
                    child: const Text(
                      'إضافة جميع المواد',
                      style: TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
