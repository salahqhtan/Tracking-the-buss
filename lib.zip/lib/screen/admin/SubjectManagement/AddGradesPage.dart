import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/Color.dart';

import 'package:flutter/material.dart';

class AddGradesPage extends StatefulWidget {
  const AddGradesPage({super.key});

  @override
  State<AddGradesPage> createState() => _AddGradesPageState();
}

class _AddGradesPageState extends State<AddGradesPage> {
  String? selectedClassId;
  String? selectedStudentId;
  String? selectedSubjectId;

  List<Map<String, dynamic>> classes = [];
  List<Map<String, dynamic>> students = [];
  List<Map<String, dynamic>> subjects = [];

  final TextEditingController term1Controller = TextEditingController();
  final TextEditingController term2Controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchClasses();
  }

  Future<void> fetchClasses() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('Classes').get();
    setState(() {
      classes =
          snapshot.docs
              .map((doc) => {'id': doc.id, 'name': doc['Name'] ?? ''})
              .toList();
    });
  }

  Future<void> fetchStudents() async {
    if (selectedClassId == null) {
      setState(() {
        students = [];
        selectedStudentId = null;
      });
      return;
    }
    final snapshot =
        await FirebaseFirestore.instance
            .collection('Student')
            .where('Class_id', isEqualTo: selectedClassId)
            .get();

    setState(() {
      students =
          snapshot.docs
              .map((doc) => {'id': doc.id, 'name': doc['Name'] ?? ''})
              .toList();
      selectedStudentId = null;
    });
  }

  Future<void> fetchSubjects() async {
    if (selectedClassId == null) {
      setState(() {
        subjects = [];
        selectedSubjectId = null;
      });
      return;
    }
    final snapshot =
        await FirebaseFirestore.instance
            .collection('Subjects')
            .where('Class_id', isEqualTo: selectedClassId)
            .get();

    setState(() {
      subjects =
          snapshot.docs
              .map((doc) => {'id': doc.id, 'name': doc['Name'] ?? ''})
              .toList();
      selectedSubjectId = null;
    });
  }

  Future<void> saveGrade() async {
    if (selectedStudentId == null ||
        selectedSubjectId == null ||
        term1Controller.text.isEmpty ||
        term2Controller.text.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('يرجى تعبئة جميع الحقول')));
      return;
    }

    final term1 = int.tryParse(term1Controller.text) ?? 0;
    final term2 = int.tryParse(term2Controller.text) ?? 0;
    final total = term1 + term2;

    await FirebaseFirestore.instance.collection('Grades').add({
      'Student_id': selectedStudentId,
      'Subject_id': selectedSubjectId,
      'Term1_scor': term1,
      'Term2_scor': term2,
      'Total_scor': total,
    });

    ScaffoldMessenger.of(
      context,
    ).showSnackBar(const SnackBar(content: Text('تم إضافة الدرجات بنجاح')));

    term1Controller.clear();
    term2Controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              DropdownButtonFormField<String>(
                value: selectedClassId,
                decoration: InputDecoration(
                  labelText: 'اختر الصف',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                items:
                    classes
                        .map(
                          (cls) => DropdownMenuItem<String>(
                            value: cls['id'],
                            child: Text(cls['name']),
                          ),
                        )
                        .toList(),
                onChanged: (val) {
                  setState(() {
                    selectedClassId = val;
                    selectedStudentId = null;
                    selectedSubjectId = null;
                    students = [];
                    subjects = [];
                  });
                  fetchStudents();
                  fetchSubjects();
                },
              ),
              const SizedBox(height: 16),

              DropdownButtonFormField<String>(
                value: selectedStudentId,
                decoration: InputDecoration(
                  labelText: 'اختر الطالب',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                items:
                    students
                        .map(
                          (stu) => DropdownMenuItem<String>(
                            value: stu['id'],
                            child: Text(stu['name']),
                          ),
                        )
                        .toList(),
                onChanged: (val) {
                  setState(() {
                    selectedStudentId = val;
                  });
                },
              ),
              const SizedBox(height: 16),

              DropdownButtonFormField<String>(
                value: selectedSubjectId,
                decoration: InputDecoration(
                  labelText: 'اختر المادة',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                items:
                    subjects
                        .map(
                          (sub) => DropdownMenuItem<String>(
                            value: sub['id'],
                            child: Text(sub['name']),
                          ),
                        )
                        .toList(),
                onChanged: (val) {
                  setState(() {
                    selectedSubjectId = val;
                  });
                },
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: term1Controller,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'الجزء الأول',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              TextFormField(
                controller: term2Controller,
                keyboardType: TextInputType.number,
                decoration: InputDecoration(
                  labelText: 'الجزء الثاني',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
              ),

              const SizedBox(height: 24),

              ElevatedButton(
                onPressed: saveGrade,
                style: ElevatedButton.styleFrom(
                  backgroundColor: ScreenColorS.focuseBorder,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                ),
                child: const Text(
                  'حفظ الدرجات',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
