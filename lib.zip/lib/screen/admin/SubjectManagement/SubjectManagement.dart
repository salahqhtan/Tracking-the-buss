import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/screen/admin/SubjectManagement/AddGradesPage.dart';
import 'package:darbk_new/screen/admin/SubjectManagement/AddSubjectsTab.dart';
import 'package:darbk_new/screen/admin/widget/CustomAppBar.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';
import 'package:darbk_new/screen/admin/widget/drawer.dart';

class SubjectListPage extends StatefulWidget {
  const SubjectListPage({super.key});

  @override
  State<SubjectListPage> createState() => _SubjectListPageState();
}

class _SubjectListPageState extends State<SubjectListPage>
    with SingleTickerProviderStateMixin {
  String? selectedClassId;
  List<Map<String, dynamic>> classes = [];
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    fetchClasses();
    _tabController = TabController(length: 3, vsync: this);
  }

  Future<void> fetchClasses() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('Classes').get();
    setState(() {
      classes =
          snapshot.docs
              .map((doc) => {'id': doc.id, 'name': doc['Name'] ?? ''})
              .toList();
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Widget buildClassSelector() {
    return GestureDetector(
      onTap:
          () => showModalBottomSheet(
            context: context,
            shape: const RoundedRectangleBorder(
              borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
            ),
            builder:
                (context) => Container(
                  padding: const EdgeInsets.all(14),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Text(
                        'اختر الصف',
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        height: 300, // ارتفاع مناسب للـ BottomSheet
                        child: GridView.builder(
                          itemCount: classes.length,
                          gridDelegate:
                              SliverGridDelegateWithMaxCrossAxisExtent(
                                maxCrossAxisExtent: 200, // أقصى عرض لكل بطاقة
                                crossAxisSpacing: 10,
                                mainAxisSpacing: 10,
                                childAspectRatio: 3, // نسبة العرض إلى الارتفاع
                              ),
                          itemBuilder: (context, index) {
                            final cls = classes[index];
                            return Card(
                              elevation: 5,
                              color:
                                  selectedClassId == cls['id']
                                      ? Colors.teal[100]
                                      : Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(10),
                                onTap: () {
                                  setState(() {
                                    selectedClassId = cls['id'];
                                  });
                                  Navigator.pop(context);
                                },
                                child: Center(
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      CircleAvatar(
                                        backgroundColor: Colors.tealAccent,
                                        child: Text(
                                          cls['name'][0],
                                          style: const TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                      const SizedBox(width: 8),
                                      Flexible(
                                        child: Text(
                                          cls['name'],
                                          style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          overflow: TextOverflow.ellipsis,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
          ),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        decoration: BoxDecoration(
          color: Colors.teal.withOpacity(0.1),
          borderRadius: BorderRadius.circular(15),
          border: Border.all(color: Colors.teal, width: 1.5),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              selectedClassId == null
                  ? 'اختر الصف'
                  : classes.firstWhere(
                    (c) => c['id'] == selectedClassId,
                  )['name'],
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const Icon(Icons.arrow_drop_down, color: Colors.teal, size: 28),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        drawer: const DrawerWidget(),
        appBar: CustomAppBarWithDrawer(
          title: 'إدارة المواد',
          bottom: TabBar(
            controller: _tabController,
            indicatorColor: Colors.tealAccent,
            indicatorWeight: 4,
            labelStyle: const TextStyle(fontWeight: FontWeight.bold),
            tabs: const [
              Tab(text: 'قائمة المواد'),
              Tab(text: 'إضافة مادة'),
              Tab(text: 'إضافة درجات'),
            ],
          ),
        ),
        bottomNavigationBar: CustomBottomNav(currentIndex: 4),
        body: TabBarView(
          controller: _tabController,
          children: [
            // 1. قائمة المواد مع اختيار الصف
            Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                children: [
                  buildClassSelector(),
                  const SizedBox(height: 14),
                  Expanded(
                    child:
                        selectedClassId == null
                            ? const Center(
                              child: Text(
                                'يرجى اختيار الصف',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            )
                            : SubjectListForClass(classId: selectedClassId!),
                  ),
                ],
              ),
            ),

            // 2. صفحة إضافة مادة
            AddSubjectPage(),

            // 3. صفحة إضافة درجات
            AddGradesPage(),
          ],
        ),
      ),
    );
  }
}

// ================================
// عنصر فرعي: عرض المواد حسب الصف
// ================================
class SubjectListForClass extends StatefulWidget {
  final String classId;
  const SubjectListForClass({required this.classId, super.key});

  @override
  State<SubjectListForClass> createState() => _SubjectListForClassState();
}

class _SubjectListForClassState extends State<SubjectListForClass> {
  List<Map<String, dynamic>> subjects = [];

  @override
  void didUpdateWidget(covariant SubjectListForClass oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.classId != widget.classId) {
      fetchSubjects();
    }
  }

  @override
  void initState() {
    super.initState();
    fetchSubjects();
  }

  Future<void> fetchSubjects() async {
    final snapshot =
        await FirebaseFirestore.instance
            .collection('Subjects')
            .where('Class_id', isEqualTo: widget.classId)
            .get();

    setState(() {
      subjects =
          snapshot.docs
              .map((doc) => {'id': doc.id, 'name': doc['Name'] ?? ''})
              .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (subjects.isEmpty) {
      return const Center(
        child: Text(
          'لا توجد مواد في هذا الصف',
          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
        ),
      );
    }

    return ListView.builder(
      itemCount: subjects.length,
      itemBuilder: (context, index) {
        final subject = subjects[index];
        return Card(
          elevation: 5,
          shadowColor: Colors.teal.withOpacity(0.5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
          margin: const EdgeInsets.symmetric(vertical: 8),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: Colors.tealAccent,
              child: Text(
                subject['name'][0],
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            title: Text(
              subject['name'],
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            trailing: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: const Icon(Icons.edit, color: Colors.orange),
                  onPressed: () {
                    // تعديل المادة
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    // حذف المادة
                  },
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
