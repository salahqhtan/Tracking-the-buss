import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:awesome_dialog/awesome_dialog.dart';


final FirebaseFirestore _firestore = FirebaseFirestore.instance;

class UsersListWidget extends StatelessWidget {
  const UsersListWidget({super.key});

  Color _getRoleColor(String role) {
    switch (role) {
      case 'admin':
        return Colors.blue;
      case 'employee':
        return Colors.green;
      case 'parent':
        return Colors.orange;
      case 'driver':
        return Colors.purple;
      case 'student':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  // حذف مستخدم مع تأكيد باستخدام AwesomeDialog
  void _deleteUser(BuildContext context, String userId, String userName) {
    AwesomeDialog(
      context: context,
      dialogType: DialogType.question,
      animType: AnimType.rightSlide,
      title: 'تأكيد الحذف',
      desc: 'هل أنت متأكد من حذف المستخدم "$userName"؟',
      btnCancelOnPress: () {},
      btnOkOnPress: () async {
        try {
          await _firestore.collection('users').doc(userId).delete();
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('تم حذف المستخدم بنجاح'),
              backgroundColor: Colors.green,
            ),
          );
        } catch (e) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('حدث خطأ أثناء الحذف: $e'),
              backgroundColor: Colors.redAccent,
            ),
          );
        }
      },
    ).show();
  }

  // تعديل مستخدم مع تأكيد باستخدام AwesomeDialog
  void _editUser(
    BuildContext context,
    String userId,
    Map<String, dynamic> userData,
  ) {
    AwesomeDialog(
      context: context,
      dialogType: DialogType.question,
      animType: AnimType.rightSlide,
      title: 'تأكيد التعديل',
      desc: 'هل تريد تعديل بيانات المستخدم "${userData['name']}"؟',
      btnCancelOnPress: () {},
      btnOkOnPress: () {
        // هنا يمكنك فتح صفحة التعديل أو تنفيذ الإجراء المطلوب
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('تم الضغط على تعديل المستخدم: ${userData['name']}'),
          ),
        );
      },
    ).show();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: _firestore.collection('users').snapshots(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final users = snapshot.data!.docs;
        return ListView.builder(
          padding: const EdgeInsets.all(10),
          itemCount: users.length,
          itemBuilder: (context, index) {
            var doc = users[index];
            var data = doc.data() as Map<String, dynamic>;
            String userId = doc.id;
            String role = data['role'] ?? '';
            String userName = data['name'] ?? '';

            return Card(
              elevation: 3,
              margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 4),
              child: ListTile(
                leading: const Icon(Icons.account_circle, size: 40),
                title: Text(userName),
                subtitle: Text(data['email'] ?? ''),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 12,
                          height: 12,
                          decoration: BoxDecoration(
                            color: _getRoleColor(role),
                            shape: BoxShape.circle,
                          ),
                        ),
                        const SizedBox(width: 6),
                        Text(role),
                      ],
                    ),
                    const SizedBox(width: 10),
                    IconButton(
                      icon: const Icon(Icons.edit, color: Colors.blueAccent),
                      tooltip: 'تعديل',
                      onPressed: () => _editUser(context, userId, data),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete, color: Colors.redAccent),
                      tooltip: 'حذف',
                      onPressed: () => _deleteUser(context, userId, userName),
                    ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }
}
