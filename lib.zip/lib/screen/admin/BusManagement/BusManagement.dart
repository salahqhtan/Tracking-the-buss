import 'package:darbk_new/screen/admin/BusManagement/AddBus.dart';
import 'package:darbk_new/screen/admin/BusManagement/DeleteBus.dart';
import 'package:darbk_new/screen/admin/BusManagement/EditBus.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';

import 'package:flutter/material.dart';

class BusManagement extends StatefulWidget {
  @override
  _BusManagementState createState() => _BusManagementState();
}

class _BusManagementState extends State<BusManagement>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color.fromARGB(255, 150, 229, 240),

          title: Text(
            'إدارة الحافلات',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 25),
          ),
          bottom: TabBar(
            controller: _tabController,
            tabs: [
              Tab(text: "إضافة", icon: Icon(Icons.add)),
              Tab(text: "تعديل", icon: Icon(Icons.edit)),
              Tab(text: "حذف", icon: Icon(Icons.delete)),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [AddBusTab(), EditBusTab(), DeleteBusTab()],
        ),
        bottomNavigationBar: CustomBottomNav(currentIndex: 6),
      ),
    );
  }
}
