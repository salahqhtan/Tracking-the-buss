
import 'package:darbk_new/Color.dart';
import 'package:darbk_new/Widget/Circle.dart';
import 'package:darbk_new/Widget/Messages.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:searchfield/searchfield.dart';



class EditBusTab extends StatefulWidget {
  @override
  State<EditBusTab> createState() => _EditBusTabState();
}

class _EditBusTabState extends State<EditBusTab> {
  List<SearchFieldListItem<DocumentSnapshot>> suggestions = [];
  DocumentSnapshot? selectedBus;
  final busController = TextEditingController();
  final capacityController = TextEditingController();
  dynamic selectedRouteId;
  dynamic selectedDriverId;
  List<Map<String, dynamic>> routes = [];
  List<Map<String, dynamic>> drivers = [];
   bool _isloading = false;

  @override
  void initState() {
    super.initState();
    loadBuses();
    loadRoutesAndDrivers();
  }

  Future<void> loadBuses() async {
    final snapshot = await FirebaseFirestore.instance.collection('Bus').get();
    setState(() {
      suggestions = snapshot.docs
          .map((doc) => SearchFieldListItem(doc['Bus_number'], item: doc))
          .toList();
    });
  }

  Future<void> loadRoutesAndDrivers() async {
    final routeSnapshot = await FirebaseFirestore.instance.collection('Routes').get();
    final driverSnapshot = await FirebaseFirestore.instance.collection('Driver').get();
    setState(() {
      routes = routeSnapshot.docs.map((doc) => {'id': doc.id, 'name': doc['Name']}).toList();
      drivers = driverSnapshot.docs.map((doc) => {'id': doc.id, 'name': doc['Name']}).toList();
    });
  }

  void updateBus() async {
    setState(() {
      _isloading =true;
    });
    if (selectedBus != null) {
      await FirebaseFirestore.instance.collection('Bus').doc(selectedBus!.id).update({
        'Bus_number': busController.text,
        'Capacity': int.tryParse(capacityController.text) ?? 0,
        'Route_ID': selectedRouteId,
        'Driver_ID': selectedDriverId,
      });
      msg('تم تحديث  بيانات الحافلة', Colors.green);
      loadBuses();
       setState(() {
      _isloading =false;
    });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Center(
          child: ConstrainedBox(
             constraints: BoxConstraints(
                          maxWidth: 600 , minWidth: 220,
                        ),
            child: ListView(
              padding: EdgeInsets.all(16),
              children: [
                SearchField<DocumentSnapshot>(
                  suggestions: suggestions,
                  hint: 'ابحث عن الحافلة ',
                    searchInputDecoration: SearchInputDecoration(
                      suffixIcon: Icon(Icons.search),
                                            border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.focuseBorder,
                            ),
                          ),
                    ),
                  onSuggestionTap: (item) {
                    setState(() {
                      selectedBus = item.item;
                      busController.text = selectedBus!['Bus_number'];
                      capacityController.text = selectedBus!['Capacity'].toString();
                      selectedRouteId = selectedBus!['Route_ID'];
                      selectedDriverId = selectedBus!['Driver_ID'];
                    });
                  },
                ),
                SizedBox(height: 20),
                if (selectedBus != null) ...[
                  Text('تعديل بيانات الحافلة:', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 20),
                  TextField(
                    controller: busController,
                    decoration: InputDecoration(
                      labelText: 'رقم الحافلة',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 15),
                  TextField(
                    controller: capacityController,
                    decoration: InputDecoration(
                      labelText: 'السعة',
                      border: OutlineInputBorder(),
                    ),
                    keyboardType: TextInputType.number,
                  ),
                  SizedBox(height: 15),
                  DropdownButtonFormField(
                    value: selectedRouteId,
                    items: routes
                        .map((route) => DropdownMenuItem(
                              value: route['id'],
                              child: Text(route['name']),
                            ))
                        .toList(),
                    onChanged: (value) => setState(() => selectedRouteId = value),
                    decoration: InputDecoration(
                      labelText: "المسار",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 15),
                  DropdownButtonFormField(
                    value: selectedDriverId,
                    items: drivers
                        .map((driver) => DropdownMenuItem(
                              value: driver['id'],
                              child: Text(driver['name']),
                            ))
                        .toList(),
                    onChanged: (value) => setState(() => selectedDriverId = value),
                    decoration: InputDecoration(
                      labelText: "السائق",
                      border: OutlineInputBorder(),
                    ),
                  ),
                  SizedBox(height: 25),
                  ElevatedButton(
                    onPressed: updateBus,
                    child: Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text('تحديث البيانات', style: TextStyle(fontSize: 16)),
                    ),
                    style: ElevatedButton.styleFrom(
                      
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
        _isloading? Circle() :SizedBox(),
      ],
    );
  }
}