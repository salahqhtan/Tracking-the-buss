import 'package:darbk_new/Widget/Circle.dart';
import 'package:darbk_new/Widget/Messages.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class DeleteBusTab extends StatefulWidget {
  @override
  State<DeleteBusTab> createState() => _DeleteBusTabState();
}

class _DeleteBusTabState extends State<DeleteBusTab> {
  List<DocumentSnapshot> buses = [];
  bool _isloading = false;

  @override
  void initState() {
    super.initState();
    loadBuses();
  }

  Future<void> loadBuses() async {
    final snapshot = await FirebaseFirestore.instance.collection('Bus').get();
    setState(() {
      buses = snapshot.docs;
    });
  }

  void deleteBus(String busId) async {
    setState(() {
      _isloading = true;
    });
    await FirebaseFirestore.instance.collection('Bus').doc(busId).delete();
    loadBuses();
    msg('تم حذف الحافلة ', Colors.blue);

    setState(() {
      _isloading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(maxWidth: 600, minWidth: 220),
            child: ListView(
              padding: EdgeInsets.all(16),
              children: [
                Text('قائمة الحافلات:', style: TextStyle(fontSize: 16)),
                SizedBox(height: 10),
                ...buses.map(
                  (bus) => Card(
                    margin: EdgeInsets.only(bottom: 10),
                    child: ListTile(
                      title: Text('رقم الحافلة: ${bus['Bus_number']}'),
                      subtitle: Text('السعة: ${bus['Capacity']}'),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () => deleteBus(bus.id),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        _isloading ? Circle() : SizedBox(),
      ],
    );
  }
}
