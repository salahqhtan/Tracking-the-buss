
import 'package:darbk_new/Color.dart';
import 'package:darbk_new/Widget/Circle.dart';
import 'package:darbk_new/Widget/Messages.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';


class AddBusTab extends StatefulWidget {
  @override
  _AddBusTabState createState() => _AddBusTabState();
}

class _AddBusTabState extends State<AddBusTab> {
  final busNumberController = TextEditingController();
  final capacityController = TextEditingController();
  dynamic selectedRouteId;
  dynamic selectedDriverId;
  List<Map<String, dynamic>> routes = [];
  List<Map<String, dynamic>> drivers = [];
  bool _isloading = false;

  @override
  void initState() {
    super.initState();
    loadRoutesAndDrivers();
  }

  Future<void> loadRoutesAndDrivers() async {
    final routeSnapshot = await FirebaseFirestore.instance.collection('Routes').get();
    final driverSnapshot = await FirebaseFirestore.instance.collection('Drivers').get();
    setState(() {
      routes = routeSnapshot.docs.map((doc) => {'id': doc.id, 'name': doc['Name']}).toList();
      drivers = driverSnapshot.docs.map((doc) => {'id': doc.id, 'name': doc['Name']}).toList();
    });
  }

  void addBus() async {
    setState(() {
      _isloading =true;
    });
    await FirebaseFirestore.instance.collection('Bus').add({
      'Bus_number': busNumberController.text,
      'Capacity': int.tryParse(capacityController.text) ?? 0,
      'Route_ID': selectedRouteId,
      'Driver_ID': selectedDriverId,
    });
    msg('تم إضافة الحافلة', Colors.green);
  
    busNumberController.clear();
    capacityController.clear();
    setState(() {
      selectedRouteId = null;
      selectedDriverId = null;
      _isloading =false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: ConstrainedBox(
               constraints: BoxConstraints(
                            maxWidth: 600 , minWidth: 220,
                          ),
              child: Card(
                color: ScreenColorS.card,
                  margin: EdgeInsets.all(10),
                child: Container(
                  padding: EdgeInsets.all(10),
                  child: ListView(
                    padding: EdgeInsets.all(16),
                    children: [
                      TextField(
                        controller: busNumberController,
                        decoration: InputDecoration(
                           border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.focuseBorder,
                            ),
                          ),
                          labelText: "رقم الحافلة"),
                      ),
                      SizedBox(height: 10),
                      TextField(
                        controller: capacityController,
                        decoration: InputDecoration(
                           border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.focuseBorder,
                            ),
                          ),
                          labelText: "السعة"),
                        keyboardType: TextInputType.number,
                      ),
                      SizedBox(height: 10),
                      DropdownButtonFormField(
                        value: selectedRouteId,
                        items: routes
                            .map((route) => DropdownMenuItem(
                                  value: route['id'],
                                  child: Text(route['name']),
                                ))
                            .toList(),
                        onChanged: (value) => setState(() => selectedRouteId = value),
                        decoration: InputDecoration(
                           border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.focuseBorder,
                            ),
                          ),
                          labelText: "المسار"),
                      ),
                      SizedBox(height: 10),
                      DropdownButtonFormField(
                        value: selectedDriverId,
                        items: drivers
                            .map((driver) => DropdownMenuItem(
                                  value: driver['id'],
                                  child: Text(driver['name']),
                                ))
                            .toList(),
                        onChanged: (value) => setState(() => selectedDriverId = value),
                        decoration: InputDecoration(
                           border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.focuseBorder,
                            ),
                          ),
                          labelText: "السائق"),
                      ),
                      SizedBox(height: 20),
                      ElevatedButton(
                         style: ElevatedButton.styleFrom(
                          backgroundColor: ScreenColorS.focuseBorder
                        ),
                        onPressed: addBus,
                        child: Text("إضافة" , style: TextStyle(fontSize: 24 , fontWeight: FontWeight.w800),),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
        _isloading? Circle() :SizedBox(),
      ],
    );
  }
}