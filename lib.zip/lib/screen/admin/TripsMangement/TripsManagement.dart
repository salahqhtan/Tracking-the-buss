// import 'package:darbk_new/Color.dart';
import 'package:darbk_new/screen/admin/RouteManagement/AddRoute.dart';
import 'package:darbk_new/screen/admin/RouteManagement/DeleteRoute.dart';
import 'package:darbk_new/screen/admin/RouteManagement/EditRoute.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';
// import 'package:darbk_new/admin/widget/drawer.dart';
import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:searchfield/searchfield.dart';

class TripsManagement extends StatefulWidget {
  @override
  _TripsManagementState createState() => _TripsManagementState();
}

class _TripsManagementState extends State<TripsManagement>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: const Color.fromARGB(255, 150, 229, 240),
          title: const Text(
            'إدارة المسارات',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 25),
          ),
          bottom: TabBar(
            controller: _tabController,
            tabs: const [
              Tab(text: "إضافة", icon: Icon(Icons.add)),
              Tab(text: "تعديل", icon: Icon(Icons.edit)),
              Tab(text: "حذف", icon: Icon(Icons.delete)),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [AddRouteTab(), EditRouteTab(), DeleteRouteTab()],
        ),
        bottomNavigationBar: const CustomBottomNav(currentIndex: 6),
      ),
    );
  }
}
