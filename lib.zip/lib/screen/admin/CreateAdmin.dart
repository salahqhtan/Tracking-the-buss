import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class CreateAdminAccountPage extends StatefulWidget {
  const CreateAdminAccountPage({super.key});

  @override
  State<CreateAdminAccountPage> createState() => _CreateAdminAccountPageState();
}

class _CreateAdminAccountPageState extends State<CreateAdminAccountPage> {
  final TextEditingController emailController = TextEditingController(
    text: "admin1@gmail.com",
  );
  final TextEditingController passwordController = TextEditingController(
    text: "123456",
  );
  final TextEditingController nameController = TextEditingController(
    text: "Admin",
  );
  final String userType = "Admin";

  bool isLoading = false;

  // دالة لإنشاء حساب مدير جديد
  Future<void> createAccount() async {
    setState(() => isLoading = true);

    try {
      UserCredential userCredential = await FirebaseAuth.instance
          .createUserWithEmailAndPassword(
            email: emailController.text.trim(),
            password: passwordController.text.trim(),
          );

      String uid = userCredential.user!.uid;

      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'uid': uid,
        'email': emailController.text.trim(),
        'name': nameController.text.trim(),
        'type': userType,
      });

      await FirebaseFirestore.instance
          .collection('School Administor')
          .doc(uid)
          .set({
            'uid': uid,
            'Email': emailController.text.trim(),
            'Name': nameController.text.trim(),
            'Password':
                passwordController.text
                    .trim(), // غير آمن تخزين كلمة المرور نص عادي
            'type': userType,
          });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم إنشاء حساب المدير بنجاح')),
      );

      // تنظيف الحقول بعد الإنشاء
      nameController.clear();
      emailController.clear();
      passwordController.clear();
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('فشل إنشاء الحساب: ${e.message}')));
    } finally {
      setState(() => isLoading = false);
    }
  }

  // دالة لحذف مستخدم من Firestore فقط
  Future<void> deleteUser(String uid) async {
    setState(() => isLoading = true);

    try {
      await FirebaseFirestore.instance.collection('users').doc(uid).delete();
      await FirebaseFirestore.instance
          .collection('School Administor')
          .doc(uid)
          .delete();

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('تم حذف المستخدم بنجاح')));
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('فشل حذف المستخدم: $e')));
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('إدارة حسابات مديري المدرسة'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // نموذج إنشاء حساب جديد
            TextField(
              controller: nameController,
              decoration: const InputDecoration(labelText: 'الاسم'),
            ),
            TextField(
              controller: emailController,
              keyboardType: TextInputType.emailAddress,
              decoration: const InputDecoration(labelText: 'الإيميل'),
            ),
            TextField(
              controller: passwordController,
              obscureText: true,
              decoration: const InputDecoration(labelText: 'كلمة المرور'),
            ),
            const SizedBox(height: 20),

            if (isLoading)
              const CircularProgressIndicator()
            else
              ElevatedButton(
                onPressed: createAccount,
                child: const Text('إنشاء الحساب'),
              ),

            const SizedBox(height: 30),

            const Text(
              'قائمة مديري المدرسة',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const Divider(),

            // عرض قائمة المستخدمين من Firestore
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                stream:
                    FirebaseFirestore.instance
                        .collection('School Administor')
                        .snapshots(),
                builder: (context, snapshot) {
                  if (snapshot.hasError) {
                    return Center(child: Text('حدث خطأ: ${snapshot.error}'));
                  }
                  if (snapshot.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  final docs = snapshot.data!.docs;

                  if (docs.isEmpty) {
                    return const Center(child: Text('لا يوجد مدراء مسجلين'));
                  }

                  return ListView.builder(
                    itemCount: docs.length,
                    itemBuilder: (context, index) {
                      final data = docs[index].data()! as Map<String, dynamic>;
                      final uid = docs[index].id;
                      final name = data['Name'] ?? 'غير معروف';
                      final email = data['Email'] ?? 'غير معروف';

                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 6),
                        child: ListTile(
                          title: Text(name),
                          subtitle: Text(email),
                          trailing: IconButton(
                            icon: const Icon(Icons.delete, color: Colors.red),
                            onPressed: () async {
                              final confirm = await showDialog<bool>(
                                context: context,
                                builder:
                                    (ctx) => AlertDialog(
                                      title: const Text('تأكيد الحذف'),
                                      content: Text(
                                        'هل تريد حذف المدير $name؟',
                                      ),
                                      actions: [
                                        TextButton(
                                          onPressed:
                                              () =>
                                                  Navigator.of(ctx).pop(false),
                                          child: const Text('إلغاء'),
                                        ),
                                        TextButton(
                                          onPressed:
                                              () => Navigator.of(ctx).pop(true),
                                          child: const Text('حذف'),
                                        ),
                                      ],
                                    ),
                              );

                              if (confirm == true) {
                                await deleteUser(uid);
                              }
                            },
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
