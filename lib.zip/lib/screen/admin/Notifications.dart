import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/screen/admin/widget/CustomAppBar.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:searchfield/searchfield.dart';
import 'package:uuid/uuid.dart';

class NotificationsAdmin extends StatefulWidget {
  @override
  State<NotificationsAdmin> createState() => _NotificationsAdminState();
}

class _NotificationsAdminState extends State<NotificationsAdmin> {
  final TextEditingController messageController = TextEditingController();
  final TextEditingController searchParentController = TextEditingController();

  List<Map<String, dynamic>> allParents = [];
  List<Map<String, dynamic>> filteredParents = [];
  List<String> selectedParentIDs = [];

  List<String> busIds = [];
  String? selectedBus;
  String? selectedType;
  bool sendToAll = false;

  final List<String> notificationTypes = ['رسمي', 'غياب', 'تنبيه', 'عام'];

  @override
  void initState() {
    super.initState();
    fetchParents();
    fetchBuses();
  }

  Future<void> fetchParents() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('Parent').get();
    setState(() {
      allParents =
          snapshot.docs.map((doc) {
            return {'id': doc.id, 'name': doc['Name'], 'bus': doc['Bus_ID']};
          }).toList();
    });
  }

  Future<void> fetchBuses() async {
    final snapshot = await FirebaseFirestore.instance.collection('Bus').get();
    setState(() {
      busIds =
          snapshot.docs.map((doc) => doc['Bus_number'].toString()).toList();
    });
  }

  void selectSingleParent(String name) {
    final match = allParents.firstWhere(
      (p) => p['name'] == name,
      orElse: () => {},
    );
    if (match.isNotEmpty) {
      setState(() {
        filteredParents = [match];
        selectedParentIDs = [match['id']];
        selectedBus = null;
        sendToAll = false;
      });
    }
  }

  void selectParentsByBus(String busId) {
    setState(() {
      selectedBus = busId;
      sendToAll = false;
      searchParentController.clear();
      filteredParents = allParents.where((p) => p['bus'] == busId).toList();
      selectedParentIDs.clear();
    });
  }

  void toggleSelectAll(bool selectAll) {
    setState(() {
      if (selectAll) {
        selectedParentIDs =
            filteredParents.map((p) => p['id'] as String).toList();
      } else {
        selectedParentIDs.clear();
      }
    });
  }

  void toggleSendToAll(bool? value) {
    setState(() {
      sendToAll = value ?? false;
      if (sendToAll) {
        selectedParentIDs.clear();
        filteredParents.clear();
        selectedBus = null;
        searchParentController.clear();
      }
    });
  }

  Future<void> sendNotification() async {
    if (messageController.text.isEmpty || selectedType == null) {
      Fluttertoast.showToast(msg: 'يرجى كتابة الرسالة واختيار نوع الإشعار');
      return;
    }

    List<String> targetIDs = [];

    if (sendToAll) {
      targetIDs = allParents.map((p) => p['id'] as String).toList();
    } else {
      if (selectedParentIDs.isEmpty) {
        Fluttertoast.showToast(
          msg: 'يرجى اختيار مستلمين أو تفعيل "إرسال للجميع"',
        );
        return;
      }
      targetIDs = selectedParentIDs;
    }

    final batch = FirebaseFirestore.instance.batch();
    final uuid = Uuid();

    try {
      for (var receiverId in targetIDs) {
        final doc =
            FirebaseFirestore.instance.collection('Notifications').doc();
        batch.set(doc, {
          'Notifications_ID': uuid.v4(),
          'Type': selectedType,
          'Message': messageController.text.trim(),
          'Receiver_Type': 'Parent',
          'Receiver_ID': receiverId,
          'Sender_Type': 'Admin',
          'Sender_ID': 'admin-001',
          'Send_date': DateTime.now(),
        });
      }

      await batch.commit();

      messageController.clear();
      searchParentController.clear();
      setState(() {
        selectedParentIDs.clear();
        filteredParents.clear();
        selectedBus = null;
        selectedType = null;
        sendToAll = false;
      });

      Fluttertoast.showToast(
        msg: ' تم إرسال الإشعار بنجاح',
        backgroundColor: Colors.green,
        textColor: Colors.white,
      );
    } catch (e) {
      Fluttertoast.showToast(
        msg: ' حدث خطأ أثناء إرسال الإشعار',
        backgroundColor: Colors.red,
        textColor: Colors.white,
      );
    }
  }

  // ignore: unused_element
  Future<void> _sendAutoNotification(
    String id,
    String receiverId,
    String type,
    String message,
  ) async {
    final notificationRef = FirebaseFirestore.instance
        .collection('Notifications')
        .doc(id);
    await notificationRef.set({
      'Notifications_ID': id,
      'Type': type,
      'Message': message,
      'Receiver_Type': 'Parent',
      'Receiver_ID': receiverId,
      'Sender_Type': 'System',
      'Sender_ID': 'system-auto',
      'Send_date': DateTime.now(),
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: ScaffoldWithCustomAppBar(
        title: 'إرسال إشعار',
        body: Padding(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              TextFormField(
                controller: messageController,
                maxLines: 3,
                decoration: InputDecoration(
                  labelText: 'نص الإشعار',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
              ),
              SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: selectedType,
                decoration: InputDecoration(
                  labelText: 'نوع الإشعار',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                ),
                items:
                    notificationTypes
                        .map(
                          (type) =>
                              DropdownMenuItem(value: type, child: Text(type)),
                        )
                        .toList(),
                onChanged: (val) => setState(() => selectedType = val),
              ),
              SizedBox(height: 12),
              CheckboxListTile(
                title: Text('إرسال إلى جميع أولياء الأمور'),
                value: sendToAll,
                onChanged: toggleSendToAll,
              ),
              if (!sendToAll) ...[
                SearchField<String>(
                  controller: searchParentController,
                  hint: 'ابحث باسم ولي الأمر',
                  searchInputDecoration: SearchInputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  suggestions:
                      allParents
                          .map(
                            (p) => SearchFieldListItem<String>(
                              p['name'],
                              item: p['id'],
                            ),
                          )
                          .toList(),
                  onSuggestionTap: (item) => selectSingleParent(item.searchKey),
                  enabled: selectedBus == null,
                ),
                SizedBox(height: 12),
                DropdownButtonFormField<String>(
                  value: selectedBus,
                  decoration: InputDecoration(
                    labelText: 'الحافلة',
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                  ),
                  items:
                      busIds
                          .map(
                            (busId) => DropdownMenuItem(
                              value: busId,
                              child: Text('الحافلة رقم $busId'),
                            ),
                          )
                          .toList(),
                  onChanged: (val) {
                    if (selectedParentIDs.isEmpty && val != null) {
                      selectParentsByBus(val);
                    }
                  },
                ),
              ],
              if (filteredParents.isNotEmpty && !sendToAll) ...[
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('عدد النتائج: ${filteredParents.length}'),
                    TextButton(
                      onPressed: () => toggleSelectAll(true),
                      child: Text('تحديد الكل'),
                    ),
                    TextButton(
                      onPressed: () => toggleSelectAll(false),
                      child: Text('إلغاء التحديد'),
                    ),
                  ],
                ),
                ...filteredParents.map((parent) {
                  return CheckboxListTile(
                    title: Text(parent['name']),
                    value: selectedParentIDs.contains(parent['id']),
                    onChanged: (val) {
                      setState(() {
                        if (val == true) {
                          selectedParentIDs.add(parent['id']);
                        } else {
                          selectedParentIDs.remove(parent['id']);
                        }
                      });
                    },
                  );
                }),
              ],
              SizedBox(height: 24),
              ElevatedButton(
                onPressed: sendNotification,
                child: Text(
                  'إرسال الإشعار',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  padding: EdgeInsets.symmetric(vertical: 5),
                  backgroundColor: Colors.blue,
                ),
              ),
            ],
          ),
        ),

        // إضافة شريط التنقل السفلي مع تمرير currentIndex = 1 (لصفحة الإشعارات)
        bottomNavigationBar: CustomBottomNav(currentIndex: 1),
      ),
    );
  }
}
