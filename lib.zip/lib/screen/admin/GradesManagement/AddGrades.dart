// import 'package:darbk_new/Color.dart';
// import 'package:darbk_new/Widget/Messages.dart';
// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:fluttertoast/fluttertoast.dart';

// import 'package:searchfield/searchfield.dart';

// class GradesManagement extends StatefulWidget {
//   @override
//   _GradesManagementState createState() => _GradesManagementState();
// }

// class _GradesManagementState extends State<GradesManagement> {
//   String? selectedClassId;
//   String? selectedSubjectId;
//   String selectedTerm = 'Term1';
//   String? selectedStudentId;

//   List<DocumentSnapshot> allStudents = [];
//   List<DocumentSnapshot> filteredStudents = [];
//   List<DocumentSnapshot> subjects = [];
//   List<DocumentSnapshot> classes = [];
//   Map<String, Map<String, TextEditingController>> scoreControllers = {};

//   final searchController = TextEditingController();
//   final termOptions = const [
//     DropdownMenuItem(value: 'Term1', child: Text('الجزء الأول')),
//     DropdownMenuItem(value: 'Term2', child: Text('الجزء الثاني')),
//     DropdownMenuItem(value: 'Total', child: Text('العام كامل')),
//   ];

//   bool isLoading = false;
//   bool isSaving = false;

//   @override
//   void initState() {
//     super.initState();
//     _fetchInitialData();
//   }

//   Future<void> _fetchInitialData() async {
//     setState(() => isLoading = true);
//     try {
//       final classSnap =
//           await FirebaseFirestore.instance.collection('Classes').get();
//       final studentSnap =
//           await FirebaseFirestore.instance.collection('Student').get();

//       setState(() {
//         classes = classSnap.docs;
//         allStudents = studentSnap.docs;
//         isLoading = false;
//       });
//     } catch (e) {
//       setState(() => isLoading = false);
//       msg('فشل في تحميل البيانات: ${e.toString()}', Colors.red);
//     }
//   }

//   Future<void> _loadSubjects() async {
//     if (selectedClassId == null) return;
//     setState(() => isLoading = true);
//     try {
//       final subSnap =
//           await FirebaseFirestore.instance
//               .collection('Subjects')
//               .where('Class_id', isEqualTo: selectedClassId)
//               .get();

//       setState(() {
//         subjects = subSnap.docs;
//         isLoading = false;
//       });
//     } catch (e) {
//       setState(() => isLoading = false);
//      msg('فشل في تحميل المواد: ${e.toString()}', Colors.red);
//     }
//   }

//   Future<void> _filterStudentsAndLoadScores() async {
//     if (selectedClassId == null) return;
//     setState(() => isLoading = true);

//     try {
     
//       filteredStudents =
//           allStudents.where((s) {
//             final matchesClass = s['Class_id'] == selectedClassId;
//             final matchesStudent =
//                 selectedStudentId == null || s.id == selectedStudentId;
//             return matchesClass && matchesStudent;
//           }).toList();

  
//       scoreControllers.clear();
//       for (var student in filteredStudents) {
//         scoreControllers[student.id] = {};
//         for (var subject in subjects) {
//           final gradeSnap =
//               await FirebaseFirestore.instance
//                   .collection('Grades')
//                   .where('Student_id', isEqualTo: student.id)
//                   .where('Subject_id', isEqualTo: subject.id)
//                   .where('Class_ID', isEqualTo: selectedClassId)
//                   .limit(1)
//                   .get();

//           final data =
//               gradeSnap.docs.isNotEmpty ? gradeSnap.docs.first.data()! : {};
//           final score =
//               selectedTerm == 'Term1'
//                   ? (data['Term1_scor'] ?? 0)
//                   : selectedTerm == 'Term2'
//                   ? (data['Term2_scor'] ?? 0)
//                   : (data['Total_scor'] ??
//                       (data['Term1_scor'] ?? 0) + (data['Term2_scor'] ?? 0));

//           scoreControllers[student.id]![subject.id] = TextEditingController(
//             text: score.toString(),
//           );
//         }
//       }
//     } catch (e) {
//       msg('فشل في تحميل الدرجات: ${e.toString()}', Colors.red);
//     }

//     setState(() => isLoading = false);
//   }

//  Future<void> _saveAllGrades() async {
//   if (isSaving) return;
//   setState(() => isSaving = true);

//   try {
//     final batch = FirebaseFirestore.instance.batch();

//     for (var student in filteredStudents) {
//       final controllers = scoreControllers[student.id]!;
//       for (var subject in subjects) {
//         if (selectedSubjectId != null && selectedSubjectId != subject.id)
//           continue;

//         final score = int.tryParse(controllers[subject.id]?.text ?? '0') ?? 0;
//         final gradeQuery = await FirebaseFirestore.instance
//             .collection('Grades')
//             .where('Student_id', isEqualTo: student.id)
//             .where('Subject_id', isEqualTo: subject.id)
//             .limit(1)
//             .get();

//         if (gradeQuery.docs.isNotEmpty) {
      
//           final existingData = gradeQuery.docs.first.data();
          
//           if (selectedTerm == 'Term1') {
//             batch.update(gradeQuery.docs.first.reference, {
//               'Term1_scor': score,
//               'Total_scor': (score + (existingData['Term2_scor'] ?? 0)),
//             });
//           } else if (selectedTerm == 'Term2') {
//             batch.update(gradeQuery.docs.first.reference, {
//               'Term2_scor': score,
//               'Total_scor': ((existingData['Term1_scor'] ?? 0) + score),
//             });
//           } else {
//             Fluttertoast.showToast(
//               gravity: ToastGravity.CENTER,
//               backgroundColor: Colors.red,
//               msg: "لا يمكنك التعديل يرجى تعدل كل جزء منفصل");
//             continue;
//           }
//         } else {
          
//           final ref = FirebaseFirestore.instance.collection('Grades').doc();
//           if (selectedTerm == 'Term1') {
//             batch.set(ref, {
//               'Student_id': student.id,
//               'Subject_id': subject.id,
//               'Class_ID': selectedClassId,
//               'Term1_scor': score,
//               'Term2_scor': 0,
//               'Total_scor': score,
//             });
//           } else if (selectedTerm == 'Term2') {
//             batch.set(ref, {
//               'Student_id': student.id,
//               'Subject_id': subject.id,
//               'Class_ID': selectedClassId,
//               'Term1_scor': 0,
//               'Term2_scor': score,
//               'Total_scor': score,
//             });
//           } else {
//             Fluttertoast.showToast(
//               gravity: ToastGravity.CENTER,
//               backgroundColor: Colors.red,
//               msg: "لا يمكنك التعديل يرجى تعدل كل جزء منفصل");
//             break;
//           }
//         }
//       }
//     }

//     await batch.commit();
//     msg('تم تحديث جميع الدرجات بنجاح', Colors.green);
//   } catch (e) {
//     msg( 'فشل في حفظ الدرجات: ${e.toString()}', Colors.red);
//   }

//   setState(() => isSaving = false);
// }

//   String _getStatus(double avg, bool hasFailingSubject) {
//     int passMarkPerSubject = 50;
//     if (selectedTerm == 'Term1' || selectedTerm == 'Term2') {
//       passMarkPerSubject = 25;
//     }

//     if (hasFailingSubject) {
//       return 'راسب';
//     }
//     if (avg >= 90) return 'ممتاز';
//     if (avg >= 75) return 'جيد جدًا';
//     if (avg >= passMarkPerSubject) return 'ناجح';
//     return 'راسب';
//   }

//   double _calculatePercentage(double total, int subjectCount) {
//     if (selectedTerm == 'Term1' || selectedTerm == 'Term2') {
      
//       return (total * 2) / (subjectCount * 100) * 100;
//     } else {
      
//       return total / (subjectCount * 100) * 100;
//     }
//   }

//   void _showAverageDetails(
//     String studentName,
//     List<int> scores,
//     List<DocumentSnapshot> subjectsToShow,
//   ) {
//     showDialog(
//       context: context,
//       builder:
//           (_) => AlertDialog(
//             title: Text('تفاصيل المعدل للطالب $studentName'),
//             content: Column(
//               mainAxisSize: MainAxisSize.min,
//               children: List.generate(subjectsToShow.length, (index) {
//                 return ListTile(
//                   title: Text(subjectsToShow[index]['Name']),
//                   trailing: Text(scores[index].toString()),
//                 );
//               }),
//             ),
//             actions: [
//               TextButton(
//                 onPressed: () => Navigator.pop(context),
//                 child: Text('إغلاق'),
//               ),
//             ],
//           ),
//     );
//   }



//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
    
//         title: Text(
//           'إدارة الدرجات',
//           style: TextStyle(fontWeight: FontWeight.w800 , fontSize: 25),
//         ),
//          backgroundColor: const Color.fromARGB(255, 150, 229, 240),),
//       backgroundColor: Colors.white,
//       body: Container(
        
//         child: ListView(
          
//           children: [
//               SizedBox(height: 12),
//                   Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 10),
//                     child: Row(
//                       children: [
//                         Expanded(flex: 2, child: _buildClassDropdown()),
//                         SizedBox(width: 5),
//                         Expanded(flex: 2, child: _buildTermDropdown()),
//                       ],
//                     ),
//                   ),
//                   SizedBox(height: 12),
//                   Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 10),
//                     child: Row(
//                       children: [
//                         Expanded(flex: 2, child: _buildStudentSearchField()),
//                         SizedBox(width: 5),
//                         if (selectedClassId != null)
//                           Expanded(flex: 2, child: _buildSubjectDropdown()),
//                         if (selectedClassId != null) SizedBox(height: 12),
//                       ],
//                     ),
//                   ),
        
//                    if (filteredStudents.isNotEmpty) ...[
//               Padding(
//                 padding: const EdgeInsets.all(8.0),
//                 child: ElevatedButton(
//                   onPressed: isSaving ? null : _saveAllGrades,
//                   style: ElevatedButton.styleFrom(backgroundColor: Colors.blue),
//                   child:
//                       isSaving
//                           ? CircularProgressIndicator(color: Colors.red)
//                           : Text(
//                             'حفظ كل الدرجات',
//                             style: TextStyle(
//                               fontSize: 20,
//                               fontWeight: FontWeight.w500,
//                               color: const Color.fromARGB(255, 255, 255, 255),
//                             ),
//                           ),
//                 ),
//               ),
//               SizedBox(height: 20),
//             ],
        
            
//             if (isLoading)
//               Center(child: CircularProgressIndicator())
//             else if (filteredStudents.isNotEmpty)
//               _buildGradesTable()
//             else
//               Text('لا يوجد طلاب لعرضهم. يرجى اختيار صف أو طالب.'),
//           ],
//         ),
//       ),
//     );
//   }

//   Widget _buildClassDropdown() {
//     return Container(
//       child: DropdownButtonFormField<String>(
//         decoration: InputDecoration(
//           labelText: 'الصف الدراسي',
//           border: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.border),
//           ),
//           enabledBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.border),
//           ),
//           focusedBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
//           ),
//         ),
//         value: selectedClassId,
//         items:
//             classes
//                 .map(
//                   (c) => DropdownMenuItem(
//                     value: c.id,
//                     child: Text(c['Name'] ?? 'بدون اسم'),
//                   ),
//                 )
//                 .toList(),
//         onChanged: (val) async {
//           setState(() {
//             selectedClassId = val;
//             selectedSubjectId = null;
//             selectedStudentId = null;
//             filteredStudents.clear();
//             subjects.clear();
//           });
//           await _loadSubjects();
//           await _filterStudentsAndLoadScores();
//         },
//       ),
//     );
//   }

//   Widget _buildSubjectDropdown() {
//     return Expanded(
//       child: DropdownButtonFormField<String>(
//         decoration: InputDecoration(
//           labelText: 'المادة الدراسية',
//           border: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.border),
//           ),
//           enabledBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.border),
//           ),
//           focusedBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
//           ),
//         ),
//         value: selectedSubjectId,
//         items: [
//           DropdownMenuItem(value: null, child: Text('كل المواد')),
//           ...subjects.map(
//             (s) => DropdownMenuItem(
//               value: s.id,
//               child: Text(s['Name'] ?? 'بدون اسم'),
//             ),
//           ),
//         ],
//         onChanged: (val) {
//           setState(() => selectedSubjectId = val);
//         },
//       ),
//     );
//   }

//   Widget _buildTermDropdown() {
//     return Expanded(
//       child: DropdownButtonFormField<String>(
//         decoration: InputDecoration(
//           labelText: 'الجزء',
//           border: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.border),
//           ),
//           enabledBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.border),
//           ),
//           focusedBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
//           ),
//         ),
//         value: selectedTerm,
//         items: termOptions,
//         onChanged: (val) async {
//           setState(() => selectedTerm = val ?? 'Term1');
//           await _filterStudentsAndLoadScores();
//         },
//       ),
//     );
//   }

//   Widget _buildStudentSearchField() {
//     return Expanded(
//       child: SearchField(
//         controller: searchController,
//         suggestions:
//             allStudents
//                 .map((s) => SearchFieldListItem(s['Name'], item: s))
//                 .toList(),
//         suggestionState: Suggestion.expand,
//         hint: 'ابحث عن الطالب بالاسم',
//         searchInputDecoration: SearchInputDecoration(
//           suffixIcon: Icon(Icons.search),
//           border: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.border),
//           ),
//           enabledBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.border),
//           ),
//           focusedBorder: OutlineInputBorder(
//             borderRadius: BorderRadius.circular(15),
//             borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
//           ),
//         ),
//         maxSuggestionsInViewPort: 6,
//         itemHeight: 50,
//         onSuggestionTap: (SearchFieldListItem item) async {
//           final student = item.item as DocumentSnapshot;
//           setState(() {
//             selectedStudentId = student.id;
//             searchController.text = student['Name'];
//           });
//           await _filterStudentsAndLoadScores();
//         },
//         onSubmit: (String value) async {
//           final found = allStudents.firstWhere(
//             (s) => s['Name'].toString().toLowerCase() == value.toLowerCase(),
//             orElse: () => null!,
//           );
//           if (found != null) {
//             setState(() {
//               selectedStudentId = found.id;
//             });
//             await _filterStudentsAndLoadScores();
//           } else {
//            msg('الطالب غير موجود', Colors.blue);
//           }
//         },
//       ),
//     );
//   }

//   Widget _buildGradesTable() {
//     int passMarkPerSubject = 50;
//     if (selectedTerm == 'Term1' || selectedTerm == 'Term2') {
//       passMarkPerSubject = 25;
//     }

 
//     List<DocumentSnapshot> displayedSubjects = subjects;
//     if (selectedSubjectId != null) {
//       displayedSubjects =
//           subjects.where((sub) => sub.id == selectedSubjectId).toList();
//     }

//     return SingleChildScrollView(
//       scrollDirection: Axis.horizontal,
//       child: Table(
//         defaultColumnWidth: IntrinsicColumnWidth(),
//         border: TableBorder.all(color: Colors.grey.shade400),
//         defaultVerticalAlignment: TableCellVerticalAlignment.middle,
//         children: [
          
//           TableRow(
//             decoration: BoxDecoration(color: Colors.grey[300]),
//             children: [
//               _buildTableHeaderCell('الاسم'),
//               ...displayedSubjects
//                   .map((sub) => _buildTableHeaderCell(sub['Name'] ?? ''))
//                   .toList(),
//               _buildTableHeaderCell('المجموع'),
//               _buildTableHeaderCell('النسبة %'),
//               _buildTableHeaderCell('الحالة'),
//             ],
//           ),

      
//           ...filteredStudents.map((student) {
//             final controllers = scoreControllers[student.id]!;
//             double totalScore = 0;
//             int countSubjects = 0;
//             bool isFail = false;

           
//             for (var subject in displayedSubjects) {
//               final scoreText = controllers[subject.id]?.text ?? '0';
//               final score = int.tryParse(scoreText) ?? 0;
//               if (score < passMarkPerSubject) isFail = true;
//               totalScore += score;
//               countSubjects++;
//             }

//             double percentage = _calculatePercentage(totalScore, countSubjects);
//             final status = _getStatus(percentage, isFail);

//             return TableRow(
//               children: [
//                 _buildTableTextCell(student['Name']),
//                 ...displayedSubjects.map((sub) {
//                   return Padding(
//                     padding: const EdgeInsets.symmetric(horizontal: 4),
//                     child: TextField(
//                       controller: controllers[sub.id],
//                       keyboardType: TextInputType.number,
//                       decoration: InputDecoration(border: InputBorder.none),
//                       onChanged: (val) => setState(() {}),
//                     ),
//                   );
//                 }).toList(),
//                 _buildTableTextCell(totalScore.toStringAsFixed(1)),
//                 _buildTableTextCell(percentage.toStringAsFixed(1) + '%'),
//                 _buildTableTextCell(status),
//               ],
//             );
//           }).toList(),
//         ],
//       ),
//     );
//   }

//   Widget _buildTableHeaderCell(String text) {
//     return Padding(
//       padding: const EdgeInsets.all(8.0),
//       child: Center(
//         child: Text(text, style: TextStyle(fontWeight: FontWeight.bold)),
//       ),
//     );
//   }

//   Widget _buildTableTextCell(String? text) {
//     return Padding(
//       padding: const EdgeInsets.all(8.0),
//       child: Text(text ?? '', textAlign: TextAlign.center),
//     );
//   }
// }
