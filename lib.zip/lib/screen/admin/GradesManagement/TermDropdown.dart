//ويدجيت اختيار الجزء (TermDropdown.dart).
import 'package:flutter/material.dart';
import 'package:darbk_new/Color.dart';

class TermDropdown extends StatelessWidget {
  final String selectedTerm;
  final Function(String?) onChanged;

  const TermDropdown({required this.selectedTerm, required this.onChanged});

  final List<DropdownMenuItem<String>> termOptions = const [
    DropdownMenuItem(value: 'Term1', child: Text('الجزء الأول')),
    DropdownMenuItem(value: 'Term2', child: Text('الجزء الثاني')),
    DropdownMenuItem(value: 'Total', child: Text('العام كامل')),
  ];

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      decoration: InputDecoration(
        labelText: 'الجزء',
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
        ),
      ),
      value: selectedTerm,
      items: termOptions,
      onChanged: onChanged,
    );
  }
}
