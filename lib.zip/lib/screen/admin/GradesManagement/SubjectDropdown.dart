//ويدجيت اختيار المادة الدراسية (SubjectDropdown.dart)
import 'package:flutter/material.dart';
import 'package:darbk_new/Color.dart';

class SubjectDropdown extends StatelessWidget {
  final List subjects;
  final String? selectedSubjectId;
  final Function(String?) onChanged;

  const SubjectDropdown({
    required this.subjects,
    required this.selectedSubjectId,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      decoration: InputDecoration(
        labelText: 'المادة الدراسية',
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
        ),
      ),
      value: selectedSubjectId,
      items: [
        DropdownMenuItem(value: null, child: Text('كل المواد')),
        ...subjects.map(
          (s) => DropdownMenuItem(
            value: s.id,
            child: Text(s['Name'] ?? 'بدون اسم'),
          ),
        ),
      ],
      onChanged: onChanged,
    );
  }
}
