import 'package:flutter/material.dart'; // استيراد مكتبة Flutter الأساسية
import 'package:cloud_firestore/cloud_firestore.dart'; // استيراد مكتبة Firestore للتعامل مع قواعد البيانات السحابية

// تعريف Widget اسمه GradesTable وهو من نوع StatelessWidget لأنه لا يحتفظ بحالة داخلية
class GradesTable extends StatelessWidget {
  // متغيرات تُمرر للصف من الخارج لتغذية الجدول بالبيانات
  final List<DocumentSnapshot> subjects; // قائمة المواد (تأتي من Firestore)
  final String selectedStudentId; // معرف الطالب المحدد لعرض درجاته
  final Map<String, Map<String, TextEditingController>> scoreControllers;
  // خريطة تحوي Controllers لكل مادة ولكل طالب (لإدارة النصوص في حقول الدرجات)
  final VoidCallback onScoreChanged; // دالة استدعاء عند تغيير قيمة الدرجة
  final String Function(double avg, bool hasFailingSubject) getStatus;
  // دالة ترجع حالة الطالب بناءً على المعدل ووجود مادة راسب (لكن سنعدل استخدامها لاحقاً)

  // الكونستركتور يستقبل المتغيرات المطلوبة ويجب تمريرها عند إنشاء الكائن
  const GradesTable({
    required this.subjects,
    required this.selectedStudentId,
    required this.scoreControllers,
    required this.onScoreChanged,
    required this.getStatus,
    super.key,
  });

  // دالة بناء واجهة الجدول
  @override
  Widget build(BuildContext context) {
    // الحصول على مجموعة TextEditingController الخاصة بالطالب المختار، وإن لم تكن موجودة تعطي خريطة فارغة
    final controllers = scoreControllers[selectedStudentId] ?? {};

    return Center(
      // يحصر الجدول في مركز الصفحة أفقياً وعمودياً
      child: SingleChildScrollView(
        // يسمح بالتمرير عمودياً في حالة الجدول طويل
        scrollDirection: Axis.vertical,
        child: SingleChildScrollView(
          // يسمح بالتمرير أفقياً في حالة عرض الجدول أكبر من الشاشة
          scrollDirection: Axis.horizontal,
          child: Directionality(
            // يحدد اتجاه النص والعناصر داخل هذا الجزء
            textDirection:
                TextDirection
                    .rtl, // العرض من اليمين إلى اليسار (مهم للغات العربية)
            child: Container(
              // صندوق يحتوي الجدول ويعطيه شكلًا وزخرفة
              width: 370, // عرض ثابت للجدول، يمكن تعديله
              height: 350, // ارتفاع ثابت للجدول، يمكن تعديله
              margin: const EdgeInsets.all(16), // مسافة خارجية حول الجدول
              decoration: BoxDecoration(
                // زخرفة خلفية وحدود وظلال للجدول
                color: Colors.white,
                borderRadius: BorderRadius.circular(10), // زوايا دائرية
                border: Border.all(
                  color: const Color.fromARGB(255, 164, 164, 164),
                ), // حد رمادي للجدول
                boxShadow: [
                  // ظل خفيف لجعل الجدول مرتفع عن الخلفية
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                    offset: Offset(2, 2),
                  ),
                ],
              ),
              child: Table(
                // بناء الجدول نفسه
                defaultVerticalAlignment:
                    TableCellVerticalAlignment
                        .middle, // محاذاة محتويات الخلايا عمودياً في الوسط
                columnWidths: const {
                  0: FixedColumnWidth(40), // عرض العمود الأول (رقم الصف)
                  1: FlexColumnWidth(3), // عرض العمود الثاني (اسم المادة)
                  2: FixedColumnWidth(70), // عرض العمود الثالث (الدرجة)
                  3: FixedColumnWidth(70), // عرض العمود الرابع (الحالة)
                },
                border: TableBorder.symmetric(
                  // الحدود بين الصفوف والأعمدة داخل الجدول
                  inside: BorderSide(color: Colors.grey.shade300),
                ),
                children: [
                  // صف رأس الجدول مع خلفية بلون أزرق فاتح وزوايا علوية مدورة
                  TableRow(
                    decoration: BoxDecoration(
                      color: Colors.blue.shade100,
                      borderRadius: BorderRadius.vertical(
                        top: Radius.circular(8),
                      ),
                    ),
                    children: [
                      _buildHeaderCell('رقم'), // رأس العمود الأول
                      _buildHeaderCell('المادة'), // رأس العمود الثاني
                      _buildHeaderCell('الدرجة'), // رأس العمود الثالث
                      _buildHeaderCell('الحالة'), // رأس العمود الرابع
                    ],
                  ),

                  // صفوف بيانات المواد، مع تطبيق ألوان بديلة للصفوف لجمالية العرض
                  ...subjects.asMap().entries.map((entry) {
                    final index = entry.key; // رقم الصف الحالي
                    final subject = entry.value; // بيانات المادة

                    // جلب أو إنشاء TextEditingController لدرجة المادة الحالية للطالب المحدد
                    final controller =
                        controllers[subject.id] ??
                        TextEditingController(text: '0');
                    final scoreText = controller.text; // نص الدرجة
                    final score =
                        int.tryParse(scoreText) ??
                        0; // تحويل الدرجة إلى عدد صحيح (افتراضياً 0)

                    // تعديل هنا: إذا الدرجة >= 50 تظهر "ناجح"، وإلا "راسب"
                    final status = score >= 50 ? 'ناجح' : 'راسب';

                    return TableRow(
                      decoration: BoxDecoration(
                        color:
                            index.isEven
                                ? Colors.grey.shade50
                                : Colors.grey.shade100,
                      ),
                      children: [
                        _buildCell((index + 1).toString()), // رقم الصف
                        _buildCell(subject['Name'] ?? ''), // اسم المادة
                        Padding(
                          padding: const EdgeInsets.all(
                            6.0,
                          ), // تباعد داخلي حول حقل النص
                          child: TextField(
                            controller:
                                controller, // ربط الحقل بـ Controller المناسب
                            keyboardType:
                                TextInputType
                                    .number, // نوع لوحة المفاتيح أرقام فقط
                            decoration: InputDecoration(
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(
                                  6,
                                ), // حدود دائرية لحقل النص
                              ),
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 10,
                                vertical: 8,
                              ),
                              fillColor: Colors.white,
                              filled: true, // تعبئة خلفية الحقل بالأبيض
                            ),
                            textAlign: TextAlign.center, // محاذاة النص للوسط
                            style: const TextStyle(
                              fontSize: 16,
                            ), // حجم الخط داخل الحقل
                            onChanged:
                                (val) =>
                                    onScoreChanged(), // استدعاء دالة عند تغير النص (تحديث الحالة)
                          ),
                        ),
                        _buildCell(
                          status, // عرض حالة المادة (ناجح، راسب)
                          color:
                              status == 'راسب'
                                  ? Colors.red
                                  : Colors
                                      .green
                                      .shade700, // لون النص حسب الحالة
                          fontWeight: FontWeight.bold, // خط عريض للحالة
                        ),
                      ],
                    );
                  }).toList(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // دالة لبناء خلايا رأس الجدول (عناوين الأعمدة)
  Widget _buildHeaderCell(String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 14,
        horizontal: 5,
      ), // تباعد داخلي للخلايا
      child: Center(
        child: Text(
          text,
          style: const TextStyle(
            fontWeight: FontWeight.bold, // خط عريض
            fontSize: 18, // حجم الخط أكبر قليلاً
            color: Colors.black87, // لون نص داكن
          ),
        ),
      ),
    );
  }

  // دالة لبناء خلايا البيانات في الجدول
  Widget _buildCell(
    String text, {
    Color color = Colors.black, // اللون الافتراضي للنص أسود
    FontWeight fontWeight = FontWeight.normal, // وزن الخط الافتراضي عادي
  }) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        vertical: 16,
        horizontal: 4,
      ), // تباعد داخلي للخلايا
      child: Center(
        child: Text(
          text,
          style: TextStyle(
            color: color,
            fontWeight: fontWeight,
            fontSize: 16,
          ), // تنسيق النص
        ),
      ),
    );
  }
}
