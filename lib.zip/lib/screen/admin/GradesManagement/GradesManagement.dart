import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:darbk_new/screen/admin/widget/CustomAppBar.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';
import 'ClassDropdown.dart';
import 'SubjectDropdown.dart';
import 'TermDropdown.dart';
import 'StudentSearchField.dart';
import 'GradesTable.dart';
import 'package:darbk_new/Widget/Messages.dart';

class GradesManagement extends StatefulWidget {
  @override
  _GradesManagementState createState() => _GradesManagementState();
}

class _GradesManagementState extends State<GradesManagement> {
  // ================================
  // المتغيرات الأساسية لإدارة الدرجات
  // ================================
  String? selectedClassId; // الصف المحدد
  String? selectedSubjectId; // المادة المحددة
  String selectedTerm = 'Term1'; // الجزء المحدد (Term1, Term2, Total)
  String? selectedStudentId; // الطالب المحدد

  List<DocumentSnapshot> allStudents = []; // جميع الطلاب
  List<DocumentSnapshot> filteredStudents = []; // الطلاب بعد تصفية الصف
  List<DocumentSnapshot> subjects = []; // المواد للصف المحدد
  List<DocumentSnapshot> classes = []; // جميع الصفوف
  Map<String, Map<String, TextEditingController>> scoreControllers = {}; 
  // مخزن للتحكم بالدرجات لكل طالب ولكل مادة

  final searchController = TextEditingController();

  bool isLoading = false; // لتحديد حالة التحميل
  bool isSaving = false; // لتحديد حالة الحفظ

  @override
  void initState() {
    super.initState();
    _fetchInitialData(); // تحميل البيانات الأولية
  }

  // ================================
  // تحميل جميع الصفوف والطلاب عند البداية
  // ================================
  Future<void> _fetchInitialData() async {
    setState(() => isLoading = true);
    try {
      final classSnap = await FirebaseFirestore.instance.collection('Classes').get();
      final studentSnap = await FirebaseFirestore.instance.collection('Student').get();

      setState(() {
        classes = classSnap.docs;
        allStudents = studentSnap.docs;
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      msg('فشل في تحميل البيانات: ${e.toString()}', Colors.red);
    }
  }

  // ================================
  // تحميل المواد للصف المحدد
  // ================================
  Future<void> _loadSubjects() async {
    if (selectedClassId == null) return;
    setState(() => isLoading = true);
    try {
      final subSnap = await FirebaseFirestore.instance
          .collection('Subjects')
          .where('Class_id', isEqualTo: selectedClassId)
          .get();

      setState(() {
        subjects = subSnap.docs;
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
      msg('فشل في تحميل المواد: ${e.toString()}', Colors.red);
    }
  }

  // ================================
  // تصفية الطلاب للصف المحدد وتحميل درجاتهم
  // ================================
  Future<void> _filterStudentsAndLoadScores() async {
    if (selectedClassId == null) return;
    setState(() => isLoading = true);

    try {
      // تصفية الطلاب حسب الصف والطالب المحدد
      filteredStudents = allStudents.where((s) {
        final matchesClass = s['Class_id'] == selectedClassId;
        final matchesStudent =
            selectedStudentId == null || s.id == selectedStudentId;
        return matchesClass && matchesStudent;
      }).toList();

      // إعداد Controllers لكل طالب ولكل مادة
      scoreControllers.clear();
      for (var student in filteredStudents) {
        scoreControllers[student.id] = {};
        for (var subject in subjects) {
          final gradeSnap = await FirebaseFirestore.instance
              .collection('Grades')
              .where('Student_id', isEqualTo: student.id)
              .where('Subject_id', isEqualTo: subject.id)
              .where('Class_ID', isEqualTo: selectedClassId)
              .limit(1)
              .get();

          final data = gradeSnap.docs.isNotEmpty ? gradeSnap.docs.first.data() : {};
          final score = selectedTerm == 'Term1'
              ? (data['Term1_scor'] ?? 0)
              : selectedTerm == 'Term2'
                  ? (data['Term2_scor'] ?? 0)
                  : (data['Total_scor'] ?? (data['Term1_scor'] ?? 0) + (data['Term2_scor'] ?? 0));

          scoreControllers[student.id]![subject.id] = TextEditingController(
            text: score.toString(),
          );
        }
      }
    } catch (e) {
      msg('فشل في تحميل الدرجات: ${e.toString()}', Colors.red);
    }

    setState(() => isLoading = false);
  }

  // ================================
  // حفظ جميع الدرجات دفعة واحدة
  // ================================
  Future<void> _saveAllGrades() async {
    if (isSaving) return;
    setState(() => isSaving = true);

    try {
      final batch = FirebaseFirestore.instance.batch();

      for (var student in filteredStudents) {
        final controllers = scoreControllers[student.id]!;
        for (var subject in subjects) {
          if (selectedSubjectId != null && selectedSubjectId != subject.id)
            continue;

          final score = int.tryParse(controllers[subject.id]?.text ?? '0') ?? 0;
          final gradeQuery = await FirebaseFirestore.instance
              .collection('Grades')
              .where('Student_id', isEqualTo: student.id)
              .where('Subject_id', isEqualTo: subject.id)
              .limit(1)
              .get();

          if (gradeQuery.docs.isNotEmpty) {
            final existingData = gradeQuery.docs.first.data();
            batch.update(gradeQuery.docs.first.reference, {
              'Term1_scor': selectedTerm == 'Term1' ? score : existingData['Term1_scor'] ?? 0,
              'Term2_scor': selectedTerm == 'Term2' ? score : existingData['Term2_scor'] ?? 0,
              'Total_scor': selectedTerm == 'Term1'
                  ? score + (existingData['Term2_scor'] ?? 0)
                  : (existingData['Term1_scor'] ?? 0) + (selectedTerm == 'Term2' ? score : 0),
            });
          } else {
            final ref = FirebaseFirestore.instance.collection('Grades').doc();
            batch.set(ref, {
              'Student_id': student.id,
              'Subject_id': subject.id,
              'Class_ID': selectedClassId,
              'Term1_scor': selectedTerm == 'Term1' ? score : 0,
              'Term2_scor': selectedTerm == 'Term2' ? score : 0,
              'Total_scor': score,
            });
          }
        }
      }

      await batch.commit();
      msg('تم تحديث جميع الدرجات بنجاح', Colors.green);
    } catch (e) {
      msg('فشل في حفظ الدرجات: ${e.toString()}', Colors.red);
    }

    setState(() => isSaving = false);
  }

  // ================================
  // تحديد حالة الطالب حسب المعدل
  // ================================
  String _getStatus(double avg, bool hasFailingSubject) {
    int passMarkPerSubject = (selectedTerm == 'Term1' || selectedTerm == 'Term2') ? 25 : 50;

    if (hasFailingSubject) return 'راسب';
    if (avg >= 90) return 'ممتاز';
    if (avg >= 75) return 'جيد جدًا';
    if (avg >= passMarkPerSubject) return 'ناجح';
    return 'راسب';
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: ScaffoldWithCustomAppBar(
        title: "إدارة الدرجات",
        body: Padding(
          padding: const EdgeInsets.all(12.0),
          child: Column(
            children: [
              // ================================
              // بطاقة اختيار الصف والجزء والطالب
              // ================================
              Card(
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: ClassDropdown(
                              classes: classes,
                              selectedClassId: selectedClassId,
                              onChanged: (val) async {
                                setState(() {
                                  selectedClassId = val;
                                  selectedSubjectId = null;
                                  selectedStudentId = null;
                                  filteredStudents.clear();
                                  subjects.clear();
                                });
                                await _loadSubjects();
                                await _filterStudentsAndLoadScores();
                              },
                            ),
                          ),
                          SizedBox(width: 8),
                          Expanded(
                            flex: 2,
                            child: TermDropdown(
                              selectedTerm: selectedTerm,
                              onChanged: (val) async {
                                setState(() => selectedTerm = val ?? 'Term1');
                                await _filterStudentsAndLoadScores();
                              },
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: StudentSearchField(
                              allStudents: allStudents,
                              selectedStudentId: selectedStudentId,
                              searchController: searchController,
                              onStudentSelected: (student) async {
                                setState(() {
                                  selectedStudentId = student.id;
                                  searchController.text = student['Name'];
                                });
                                await _filterStudentsAndLoadScores();
                              },
                              onStudentSubmitted: (String value) async {
                                final found = allStudents.firstWhere(
                                  (s) =>
                                      s['Name'].toString().toLowerCase() == value.toLowerCase(),
                                  orElse: () => null!,
                                );
                                if (found != null) {
                                  setState(() {
                                    selectedStudentId = found.id;
                                  });
                                  await _filterStudentsAndLoadScores();
                                } else {
                                  msg('الطالب غير موجود', Colors.blue);
                                }
                              },
                            ),
                          ),
                          SizedBox(width: 8),
                          if (selectedClassId != null)
                            Expanded(
                              flex: 2,
                              child: SubjectDropdown(
                                subjects: subjects,
                                selectedSubjectId: selectedSubjectId,
                                onChanged: (val) {
                                  setState(() => selectedSubjectId = val);
                                },
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 12),

              // ================================
              // زر الحفظ
              // ================================
              if (filteredStudents.isNotEmpty)
                ElevatedButton.icon(
                  onPressed: isSaving ? null : _saveAllGrades,
                  icon: Icon(Icons.save),
                  label: Text(
                    isSaving ? 'جاري الحفظ...' : 'حفظ كل الدرجات',
                    style: TextStyle(fontSize: 18),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.teal,
                    padding: EdgeInsets.symmetric(vertical: 14, horizontal: 20),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                ),
              SizedBox(height: 12),

              // ================================
              // جدول عرض الدرجات
              // ================================
              Expanded(
                child: isLoading
                    ? Center(child: CircularProgressIndicator())
                    : filteredStudents.isNotEmpty
                        ? selectedStudentId != null
                            ? GradesTable(
                                subjects: subjects,
                                selectedStudentId: selectedStudentId!,
                                scoreControllers: scoreControllers,
                                onScoreChanged: () {
                                  setState(() {});
                                },
                                getStatus: _getStatus,
                              )
                            : Center(
                                child: Text(
                                  'يرجى اختيار طالب لعرض الدرجات المفصلة',
                                  style: TextStyle(fontSize: 16, color: Colors.black54),
                                ),
                              )
                        : Center(
                            child: Text(
                              'لا توجد بيانات للصف المحدد',
                              style: TextStyle(fontSize: 16, color: Colors.black54),
                            ),
                          ),
              ),
            ],
          ),
        ),
        bottomNavigationBar: CustomBottomNav(currentIndex: 6),
      ),
    );
  }
}
