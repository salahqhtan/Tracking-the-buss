//ويدجيت اختيار الصف الدراسي (ClassDropdown.dart).
import 'package:flutter/material.dart';
import 'package:darbk_new/Color.dart';

class ClassDropdown extends StatelessWidget {
  /// قائمة الصفوف الدراسية (كل عنصر يجب أن يحتوي على خاصية `id` و`Name`)
  final List<dynamic> classes;

  /// الصف الدراسي المحدد حالياً (id)
  final String? selectedClassId;

  /// دالة تستدعى عند تغيير الاختيار، تستقبل الـ id للصف المختار أو null
  final void Function(String?) onChanged;

  const ClassDropdown({
    Key? key,
    required this.classes,
    required this.selectedClassId,
    required this.onChanged,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField<String>(
      decoration: InputDecoration(
        labelText: 'الصف الدراسي',
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
        ),
      ),
      value: selectedClassId,
      items:
          classes.map((c) {
            return DropdownMenuItem<String>(
              value: c.id,
              child: Text(c['Name'] ?? 'بدون اسم'),
            );
          }).toList(),
      onChanged: onChanged,
    );
  }
}
