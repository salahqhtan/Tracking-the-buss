//ويدجيت حقل البحث عن الطالب (StudentSearchField.dart).
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:searchfield/searchfield.dart';
import 'package:darbk_new/Color.dart';

class StudentSearchField extends StatelessWidget {
  final List<DocumentSnapshot> allStudents;
  final String? selectedStudentId;
  final TextEditingController searchController;
  final Function(DocumentSnapshot) onStudentSelected;
  final Function(String) onStudentSubmitted;

  const StudentSearchField({
    required this.allStudents,
    required this.selectedStudentId,
    required this.searchController,
    required this.onStudentSelected,
    required this.onStudentSubmitted,
  });

  @override
  Widget build(BuildContext context) {
    return SearchField(
      controller: searchController,
      suggestions:
          allStudents
              .map((s) => SearchFieldListItem(s['Name'], item: s))
              .toList(),
      suggestionState: Suggestion.expand,
      hint: 'ابحث عن الطالب بالاسم',
      searchInputDecoration: SearchInputDecoration(
        suffixIcon: Icon(Icons.search),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
        ),
      ),
      maxSuggestionsInViewPort: 6,
      itemHeight: 50,
      onSuggestionTap: (SearchFieldListItem item) {
        final student = item.item as DocumentSnapshot;
        onStudentSelected(student);
      },
      onSubmit: onStudentSubmitted,
    );
  }
}
