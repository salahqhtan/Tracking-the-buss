import 'package:darbk_new/Color.dart';
import 'package:darbk_new/Widget/Messages.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:searchfield/searchfield.dart';




class EditDriverTab extends StatefulWidget {
  @override
  State<EditDriverTab> createState() => _EditDriverTabState();
}

class _EditDriverTabState extends State<EditDriverTab> {
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final licenseController = TextEditingController();
  final addressController = TextEditingController();
  final nationalIdController = TextEditingController();

  List<SearchFieldListItem<DocumentSnapshot>> driverSuggestions = [];
  DocumentSnapshot? selectedDriver;

  @override
  void initState() {
    super.initState();
    fetchDrivers();
  }

  Future<void> fetchDrivers() async {
    final snapshot = await FirebaseFirestore.instance.collection('Drivers').get();
    setState(() {
      driverSuggestions = snapshot.docs
          .map((doc) => SearchFieldListItem(doc['Name'], item: doc))
          .toList();
    });
  }

  void updateDriver() async {
    if (selectedDriver != null) {
      await FirebaseFirestore.instance
          .collection('Drivers')
          .doc(selectedDriver!.id)
          .update({
        'Name': nameController.text.trim(),
        'Phone': phoneController.text.trim(),
        'LicenseNumber': licenseController.text.trim(),
        'Address': addressController.text.trim(),
        'NationalID': nationalIdController.text.trim(),
      });
      setState(() => selectedDriver = null);
      nameController.clear();
      phoneController.clear();
      licenseController.clear();
      addressController.clear();
      nationalIdController.clear();

     msg(' تم تعديل السائق بنجاح', Colors.green);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
         constraints: BoxConstraints(
                      maxWidth: 600 , minWidth: 220,
                    ),
        child: ListView(
          padding: EdgeInsets.all(16),
          children: [
            SearchField<DocumentSnapshot>(
               searchInputDecoration: SearchInputDecoration(
                  suffixIcon: Icon(Icons.search),
                                        border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.border,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.border,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.focuseBorder,
                        ),
                      ),
                ),
              suggestions: driverSuggestions,
              hint: 'ابحث عن السائق',
              onSuggestionTap: (item) {
                final data = item.item!.data() as Map<String, dynamic>;
                setState(() {
                  selectedDriver = item.item;
                  nameController.text = data['Name'] ?? '';
                  phoneController.text = data['Phone'] ?? '';
                  licenseController.text = data['LicenseNumber'] ?? '';
                  addressController.text = data['Address'] ?? '';
                  nationalIdController.text = data['NationalID'] ?? '';
                });
              },
            ),
            SizedBox(height: 16),
            if (selectedDriver != null) ...[
              TextField(controller: nameController, decoration: InputDecoration(labelText: 'اسم السائق')),
              SizedBox(height: 10),
              TextField(controller: phoneController, decoration: InputDecoration(labelText: 'رقم الهاتف')),
              SizedBox(height: 10),
              TextField(controller: licenseController, decoration: InputDecoration(labelText: 'رقم الرخصة')),
              SizedBox(height: 10),
              TextField(controller: addressController, decoration: InputDecoration(labelText: 'العنوان')),
              SizedBox(height: 10),
              TextField(controller: nationalIdController, decoration: InputDecoration(labelText: 'رقم الهوية')),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: updateDriver,
                child: Text('تحديث البيانات'),
              ),
            ]
          ],
        ),
      ),
    );
  }
}
