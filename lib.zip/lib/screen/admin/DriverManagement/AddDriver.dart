import 'package:darbk_new/Color.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AddDriverTab extends StatefulWidget {
  @override
  State<AddDriverTab> createState() => _AddDriverTabState();
}

class _AddDriverTabState extends State<AddDriverTab> {
  final _formKey = GlobalKey<FormState>();

  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final licenseController = TextEditingController();
  final addressController = TextEditingController();
  final nationalIdController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  final FirebaseAuth _auth = FirebaseAuth.instance;
  bool isLoading = false;

  Future<void> createAccount() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => isLoading = true);

    try {
      final email = emailController.text.trim();
      final password = passwordController.text.trim();
      final name = nameController.text.trim();

      // إنشاء المستخدم في Firebase Authentication
      UserCredential userCredential = await _auth
          .createUserWithEmailAndPassword(email: email, password: password);

      String uid = userCredential.user!.uid;

      // حفظ بيانات السائق
      await FirebaseFirestore.instance.collection('Drivers').doc(uid).set({
        'Name': name,
        'Phone': phoneController.text.trim(),
        'LicenseNumber': licenseController.text.trim(),
        'Address': addressController.text.trim(),
        'NationalID': nationalIdController.text.trim(),
        'Email': email,
        'createdAt': FieldValue.serverTimestamp(),
      });

      // حفظ بيانات المستخدم في مجموعة users مع الدور driver
      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'name': name,
        'email': email,
        'roles': 'driver',
        'related_id': uid,
        'createdAt': FieldValue.serverTimestamp(),
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✅ تم إنشاء حساب السائق وإضافة بياناته بنجاح'),
          backgroundColor: Colors.green,
        ),
      );

      // مسح الحقول
      nameController.clear();
      phoneController.clear();
      licenseController.clear();
      addressController.clear();
      nationalIdController.clear();
      emailController.clear();
      passwordController.clear();
    } on FirebaseAuthException catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ فشل: ${e.message}'),
          backgroundColor: Colors.red,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('❌ حدث خطأ: $e'), backgroundColor: Colors.red),
      );
    } finally {
      setState(() => isLoading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Center(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 600, minWidth: 220),
          child: Card(
            color: ScreenColorS.card,
            margin: EdgeInsets.all(10),
            child: Container(
              padding: EdgeInsets.all(10),
              child: Form(
                key: _formKey,
                child: ListView(
                  padding: EdgeInsets.all(16),
                  children: [
                    buildTextField(
                      nameController,
                      'اسم السائق',
                      validator: (v) {
                        if (v == null || v.trim().isEmpty)
                          return 'يرجى إدخال اسم السائق';
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    buildTextField(
                      phoneController,
                      'رقم الهاتف',
                      keyboardType: TextInputType.phone,
                    ),
                    SizedBox(height: 10),
                    buildTextField(licenseController, 'رقم الرخصة'),
                    SizedBox(height: 10),
                    buildTextField(addressController, 'العنوان'),
                    SizedBox(height: 10),
                    buildTextField(nationalIdController, 'رقم الهوية'),
                    Divider(height: 32),
                    Text(
                      "إنشاء حساب للسائق",
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    SizedBox(height: 10),
                    buildTextField(
                      emailController,
                      'البريد الإلكتروني',
                      keyboardType: TextInputType.emailAddress,
                      validator: (v) {
                        if (v == null || v.trim().isEmpty)
                          return 'يرجى إدخال البريد الإلكتروني';
                        if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(v))
                          return 'يرجى إدخال بريد إلكتروني صحيح';
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    buildTextField(
                      passwordController,
                      'كلمة المرور',
                      obscureText: true,
                      validator: (v) {
                        if (v == null || v.length < 6)
                          return 'كلمة المرور يجب أن تكون 6 أحرف على الأقل';
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: ScreenColorS.focuseBorder,
                      ),
                      onPressed: isLoading ? null : createAccount,
                      child:
                          isLoading
                              ? CircularProgressIndicator(color: Colors.white)
                              : Text(
                                'إضافة السائق',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget buildTextField(
    TextEditingController controller,
    String label, {
    TextInputType keyboardType = TextInputType.text,
    bool obscureText = false,
    String? Function(String?)? validator,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      obscureText: obscureText,
      validator: validator,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(15),
          borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
        ),
      ),
    );
  }
}
