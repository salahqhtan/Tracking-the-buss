import 'package:darbk_new/screen/admin/DriverManagement/AddDriver.dart';
import 'package:darbk_new/screen/admin/DriverManagement/DeleteDriver.dart';
import 'package:darbk_new/screen/admin/DriverManagement/EditDriver.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';
import 'package:flutter/material.dart';

class DriverManagement extends StatelessWidget {
  static const routeName = 'drivers-management';

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        // 👈 لازم هنا
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: const Color.fromARGB(255, 150, 229, 240),
            title: const Text(
              'إدارة السائقين',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 25),
            ),
            bottom: const TabBar(
              tabs: [
                Tab(text: "إضافة", icon: Icon(Icons.add)),
                Tab(text: "تعديل", icon: Icon(Icons.edit)),
                Tab(text: "حذف", icon: Icon(Icons.delete)),
              ],
            ),
          ),
          body: TabBarView(
            children: [AddDriverTab(), EditDriverTab(), DeleteDriverTab()],
          ),
          bottomNavigationBar: CustomBottomNav(currentIndex: 8),
        ),
      ),
    );
  }
}
