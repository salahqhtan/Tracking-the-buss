import 'package:darbk_new/Color.dart';
import 'package:darbk_new/Widget/Messages.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:searchfield/searchfield.dart';



class DeleteDriverTab extends StatefulWidget {
  @override
  State<DeleteDriverTab> createState() => _DeleteDriverTabState();
}

class _DeleteDriverTabState extends State<DeleteDriverTab> {
  List<SearchFieldListItem<DocumentSnapshot>> driverSuggestions = [];
  DocumentSnapshot? selectedDriver;

  @override
  void initState() {
    super.initState();
    fetchDrivers();
  }

  Future<void> fetchDrivers() async {
    final snapshot = await FirebaseFirestore.instance.collection('Drivers').get();
    setState(() {
      driverSuggestions = snapshot.docs
          .map((doc) => SearchFieldListItem(doc['Name'], item: doc))
          .toList();
    });
  }

  void deleteDriver() async {
    if (selectedDriver != null) {
      await FirebaseFirestore.instance
          .collection('Drivers')
          .doc(selectedDriver!.id)
          .delete();
      setState(() => selectedDriver = null);
      msg(' تم حذف السائق بنجاح', Colors.blue);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ConstrainedBox(
         constraints: BoxConstraints(
                      maxWidth: 600 , minWidth: 220,
                    ),
        child: ListView(
          padding: EdgeInsets.all(16),
          children: [
            SearchField<DocumentSnapshot>(
               searchInputDecoration: SearchInputDecoration(
                  suffixIcon: Icon(Icons.search),
                                        border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.border,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.border,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.focuseBorder,
                        ),
                      ),
                ),
              suggestions: driverSuggestions,
              hint: 'ابحث عن السائق',
              onSuggestionTap: (item) {
                setState(() => selectedDriver = item.item);
              },
            ),
            SizedBox(height: 16),
            if (selectedDriver != null) ...[
              Card(
                elevation: 4,
                margin: EdgeInsets.symmetric(vertical: 12),
                child: ListTile(
                  title: Text(selectedDriver!['Name']),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('الهاتف: ${selectedDriver!['Phone'] ?? '-'}'),
                      Text('الرخصة: ${selectedDriver!['LicenseNumber'] ?? '-'}'),
                      Text('العنوان: ${selectedDriver!['Address'] ?? '-'}'),
                      Text('الهوية: ${selectedDriver!['NationalID'] ?? '-'}'),
                    ],
                  ),
                  trailing: IconButton(
                    icon: Icon(Icons.delete, color: Colors.red),
                    onPressed: deleteDriver,
                  ),
                ),
              )
            ],
          ],
        ),
      ),
    );
  }
}
