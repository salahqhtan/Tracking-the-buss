// استدعاء مكتبة Firestore للتعامل مع قاعدة البيانات السحابية (تخزين وجلب البيانات)
import 'package:cloud_firestore/cloud_firestore.dart';

// استدعاء ملف Data.dart الذي يحتوي بيانات المستخدم الحالي (مثل النوع: ولي أمر، سائق، طالب)
import 'package:darbk_new/Data.dart';

// استدعاء ويدجت مخصص لشريط العنوان (AppBar) في التطبيق
import 'package:darbk_new/screen/admin/widget/CustomAppBar.dart';

// استدعاء ويدجت شريط التنقل السفلي (BottomNavigationBar) المخصص
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';

// استدعاء مكتبة Firebase Authentication لمعرفة المستخدم الحالي
import 'package:firebase_auth/firebase_auth.dart';

// استدعاء مكتبة Flutter الأساسية لبناء واجهات المستخدم
import 'package:flutter/material.dart';

// صفحة الملاحظات الرئيسية
class NotesPage extends StatefulWidget {
  const NotesPage({super.key});

  @override
  State<NotesPage> createState() => _NotesPageState();
}

// الحالة (State) الخاصة بالصفحة NotesPage
class _NotesPageState extends State<NotesPage> {
  // متحكم لحقل إدخال النصوص
  final TextEditingController _controller = TextEditingController();

  // متغير للوصول إلى قاعدة البيانات Firestore
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  // متغير للوصول إلى معلومات تسجيل الدخول من FirebaseAuth
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // تخزين معرف (ID) المستخدم الحالي
  late String currentParentId;

  @override
  void initState() {
    super.initState();
    // عند بداية الصفحة يتم الحصول على uid (المعرف الفريد للمستخدم الحالي)
    currentParentId = _auth.currentUser!.uid;
  }

  // التحقق من نوع المستخدم من بيانات DataUser
  bool isParent = DataUser.get('type') == 'ولي أمر';
  bool isDriver = DataUser.get('type') == 'سائق';
  bool isStudent = DataUser.get('type') == 'طالب';

  // دالة مساعدة لإرجاع اسم المرسل باستخدام معرفه من مجموعة Parent
  Future<String> getSenderName(String senderId) async {
    try {
      final doc = await _firestore.collection('Parent').doc(senderId).get();
      if (doc.exists && doc.data() != null) {
        return doc.get('Name') ?? 'غير معروف'; // إرجاع الاسم إذا موجود
      }
    } catch (e) {
      return 'غير معروف'; // إرجاع "غير معروف" في حال حدوث خطأ
    }
    return 'غير معروف';
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl, // جعل اتجاه النص من اليمين لليسار
      child: ScaffoldWithCustomAppBar(
        title: 'الملاحظات', // عنوان الصفحة في شريط العنوان

        body: Column(
          children: [
            // الجزء العلوي: عرض الرسائل
            Expanded(
              child: StreamBuilder<QuerySnapshot>(
                // الاستماع لتغيرات البيانات في مجموعة Notes من Firestore
                stream:
                    _firestore
                        .collection('Notes')
                        .orderBy('Date', descending: false) // ترتيب حسب التاريخ
                        .snapshots(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    // أثناء التحميل إظهار دائرة انتظار
                    return const Center(child: CircularProgressIndicator());
                  }

                  final notes = snapshot.data!.docs; // جلب الرسائل

                  // بناء قائمة الرسائل
                  return ListView.builder(
                    padding: const EdgeInsets.all(8),
                    itemCount: notes.length,
                    itemBuilder: (context, index) {
                      final note = notes[index];
                      final content = note.get('Content'); // محتوى الرسالة
                      final date =
                          (note.get('Date') as Timestamp).toDate(); // التاريخ
                      final senderId = note.get('Sender_ID'); // معرف المرسل

                      final isMe =
                          senderId ==
                          currentParentId; // هل المرسل هو المستخدم الحالي؟

                      // جلب اسم المرسل بشكل غير متزامن
                      return FutureBuilder<String>(
                        future: getSenderName(senderId),
                        builder: (context, nameSnapshot) {
                          if (!nameSnapshot.hasData) return const SizedBox();

                          final senderName = nameSnapshot.data!;

                          // عرض الرسالة داخل فقاعة (Bubble) مثل واتساب
                          return Align(
                            alignment:
                                isMe
                                    ? Alignment
                                        .centerRight // إذا أنا → يمين
                                    : Alignment.centerLeft, // إذا الآخر → يسار
                            child: Container(
                              margin: const EdgeInsets.symmetric(vertical: 6),
                              padding: const EdgeInsets.all(10),
                              decoration: BoxDecoration(
                                color:
                                    isMe
                                        ? Color.fromARGB(
                                          255,
                                          142,
                                          250,
                                          148,
                                        ) // لون أخضر للمرسل
                                        : Colors.grey[300], // رمادي للمستقبل
                                borderRadius: BorderRadius.only(
                                  topLeft: const Radius.circular(12),
                                  topRight: const Radius.circular(12),
                                  bottomLeft: Radius.circular(isMe ? 12 : 0),
                                  bottomRight: Radius.circular(isMe ? 0 : 12),
                                ),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // اسم المرسل
                                  Text(
                                    isMe ? "أنت" : senderName,
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 12,
                                      color: Colors.blue,
                                    ),
                                  ),
                                  const SizedBox(height: 5),
                                  // محتوى الرسالة
                                  Text(
                                    content,
                                    style: const TextStyle(fontSize: 16),
                                  ),
                                  const SizedBox(height: 5),
                                  // الوقت والتاريخ
                                  Text(
                                    "${date.hour}:${date.minute} __ ${date.year}/${date.month}/${date.day}",
                                    style: const TextStyle(
                                      fontSize: 10,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              ),
            ),

            // الجزء السفلي: مربع إدخال الرسالة
            Container(
              color: Colors.white,
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Row(
                  children: [
                    // حقل إدخال النص
                    Expanded(
                      child: TextFormField(
                        enabled:
                            isParent
                                ? true // مسموح للولي
                                : isStudent
                                ? false // الطالب لا يستطيع الإرسال
                                : true, // السائق مسموح
                        controller: _controller,
                        minLines: 1,
                        maxLines: 3,
                        decoration: const InputDecoration(
                          hintText: "أدخل ملاحظة...", // نص افتراضي
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.all(Radius.circular(20)),
                          ),
                        ),
                      ),
                    ),
                    // زر الإرسال
                    IconButton(
                      icon: const Icon(Icons.send, color: Colors.teal),
                      onPressed:
                          isStudent
                              ? null // إذا كان طالب لا يرسل
                              : () {
                                final message = _controller.text.trim();
                                if (message.isNotEmpty) {
                                  // حفظ الرسالة في Firestore
                                  _firestore.collection('Notes').add({
                                    'Content': message,
                                    'Date': Timestamp.now(),
                                    'Sender_ID': currentParentId,
                                  });
                                  _controller.clear(); // مسح الحقل بعد الإرسال
                                }
                              },
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        // شريط التنقل السفلي (الانتقال بين الصفحات) currentIndex = 2 يعني تحديد صفحة الملاحظات
        bottomNavigationBar: CustomBottomNav(currentIndex: 2),
      ),
    );
  }
}
