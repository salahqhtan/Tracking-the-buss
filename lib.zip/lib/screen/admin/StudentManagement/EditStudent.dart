import 'package:darbk_new/Color.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:searchfield/searchfield.dart';




class EditStudentTab extends StatefulWidget {
  @override
  State<EditStudentTab> createState() => _EditStudentTabState();
}

class _EditStudentTabState extends State<EditStudentTab> {
  Map<String, dynamic>? selectedStudent;
  final TextEditingController nameController = TextEditingController();
  final TextEditingController parentNameController = TextEditingController();
  String? selectedParentId;
  String? selectedClassId;
  List<Map<String, dynamic>> classes = [];
  List<SearchFieldListItem<String>> parentSuggestions = [];

  @override
  void initState() {
    super.initState();
    fetchClasses();
    fetchParents();
  }

  Future<void> fetchClasses() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('Classes').get();
    setState(() {
      classes =
          snapshot.docs
              .map((doc) => {'id': doc.id, 'name': doc['Name']})
              .toList();
    });
  }

  Future<void> fetchParents() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('Parent').get();
    setState(() {
      parentSuggestions =
          snapshot.docs
              .map((doc) => SearchFieldListItem(doc['Name'], item: doc.id))
              .toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          FutureBuilder(
            future: FirebaseFirestore.instance.collection('Student').get(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return CircularProgressIndicator();
              final students = snapshot.data!.docs;
              return Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: 600, minWidth: 220),
                  child: Column(
                    children: [
                      SearchField(
                        searchInputDecoration: SearchInputDecoration(
                          suffixIcon: Icon(Icons.search),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.focuseBorder,
                            ),
                          ),
                        ),
                        suggestions:
                            students
                                .map(
                                  (doc) => SearchFieldListItem(
                                    doc['Name'],
                                    item: doc,
                                  ),
                                )
                                .toList(),
                        onSuggestionTap: (item) async {
                          final doc = item.item!;
                          final parentDoc =
                              await FirebaseFirestore.instance
                                  .collection('Parent')
                                  .doc(doc['Parent_ID'])
                                  .get();
                          setState(() {
                            selectedStudent = {
                              'id': doc.id,
                              'Name': doc['Name'],
                              'Class_id': doc['Class_id'],
                              'Parent_ID': doc['Parent_ID'],
                            };
                            nameController.text = doc['Name'];
                            selectedClassId = doc['Class_id'];
                            selectedParentId = doc['Parent_ID'];
                            parentNameController.text = parentDoc['Name'];
                          });
                        },
                      ),
                      const SizedBox(height: 16),
                      if (selectedStudent != null)
                        Column(
                          children: [
                            TextField(
                              controller: nameController,
                              decoration: const InputDecoration(
                                labelText: 'اسم الطالب',
                              ),
                            ),
                            const SizedBox(height: 12),
                            SearchField<String>(
                              controller: parentNameController,
                              suggestions: parentSuggestions,
                              hint: 'اختر أو ابحث عن ولي الأمر',
                              onSuggestionTap:
                                  (item) => setState(() {
                                    selectedParentId = item.item;
                                    parentNameController.text = item.searchKey;
                                  }),
                            ),
                            const SizedBox(height: 12),
                            DropdownButtonFormField<dynamic>(
                              value: selectedClassId,
                              items:
                                  classes
                                      .map(
                                        (cls) => DropdownMenuItem(
                                          value: cls['id'],
                                          child: Text(cls['name']),
                                        ),
                                      )
                                      .toList(),
                              onChanged:
                                  (val) =>
                                      setState(() => selectedClassId = val),
                              decoration: const InputDecoration(
                                labelText: 'اختر الصف',
                              ),
                            ),
                            const SizedBox(height: 20),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: ScreenColorS.border,
                              ),
                              onPressed: () async {
                                await FirebaseFirestore.instance
                                    .collection('Student')
                                    .doc(selectedStudent!['id'])
                                    .update({
                                      'Name': nameController.text,
                                      'Class_id': selectedClassId,
                                      'Parent_ID': selectedParentId,
                                    });
                                setState(() => selectedStudent = null);
                              },
                              child: const Text(
                                'تحديث البيانات',
                                style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ],
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}