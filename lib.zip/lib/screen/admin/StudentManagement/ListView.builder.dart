import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:darbk_new/Color.dart';
import 'package:flutter/material.dart';

/// صفحة تفاصيل الطالب مع المواد والدرجات وبيانات ولي الأمر
class StudentDetailsPage extends StatefulWidget {
  final String studentId;
  final Map<String, dynamic> studentData;

  const StudentDetailsPage({
    super.key,
    required this.studentId,
    required this.studentData,
  });

  @override
  State<StudentDetailsPage> createState() => _StudentDetailsPageState();
}

class _StudentDetailsPageState extends State<StudentDetailsPage> {
  List<Map<String, dynamic>> subjects = [];
  Map<String, dynamic>? parentData;

  @override
  void initState() {
    super.initState();
    fetchSubjects();
    fetchParent();
  }

  Future<void> fetchSubjects() async {
    final classId = widget.studentData['Class_id'] ?? '';
    if (classId.isEmpty) return;

    final snapshot =
        await FirebaseFirestore.instance
            .collection('Subjects')
            .where('Class_id', isEqualTo: classId)
            .get();

    setState(() {
      subjects =
          snapshot.docs
              .map((doc) => {'id': doc.id, 'name': doc['Name'] ?? ''})
              .toList();
    });
  }

  Future<void> fetchParent() async {
    final parentId = widget.studentData['Parent_ID'] ?? '';
    if (parentId.isEmpty) return;

    final doc =
        await FirebaseFirestore.instance
            .collection('Parent')
            .doc(parentId)
            .get();

    if (doc.exists) {
      setState(() {
        parentData = doc.data();
      });
    }
  }

  Stream<QuerySnapshot> getGradesStream() {
    return FirebaseFirestore.instance
        .collection('Grades')
        .where('Student_id', isEqualTo: widget.studentId)
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    final student = widget.studentData;

    return Directionality(
      textDirection: TextDirection.rtl, // التأكد من اتجاه النص من اليمين لليسار
      child: Scaffold(
        appBar: AppBar(
          actions: [
            IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pop(context);
              },
            ),
          ],
          title: Text('بيانات الطالب'),
        ),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: ListView(
            children: [
              const SizedBox(height: 8),
              Text(
                'بيانات الطالب',
                style: Theme.of(
                  context,
                ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
              ),
              ListTile(
                title: const Text('الاسم'),
                subtitle: Text(student['Name'] ?? '-'),
              ),
              ListTile(
                title: const Text('الحالة'),
                subtitle: Text(student['Status'] ?? '-'),
              ),
              ListTile(
                title: const Text('الصف'),
                subtitle: Text(student['Class_id'] ?? '-'),
              ),
              const Divider(thickness: 1, height: 32),

              if (parentData != null) ...[
                Text(
                  'بيانات ولي الأمر',
                  style: Theme.of(
                    context,
                  ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
                ),
                ListTile(
                  title: const Text('الاسم'),
                  subtitle: Text(parentData?['Name'] ?? '-'),
                ),
                ListTile(
                  title: const Text('البريد الإلكتروني'),
                  subtitle: Text(parentData?['Email'] ?? '-'),
                ),
                ListTile(
                  title: const Text('رقم الهاتف'),
                  subtitle: Text(parentData?['Phone'] ?? '-'),
                ),
                const Divider(thickness: 1, height: 32),
              ],

              Text(
                'المواد ودرجات الطالب',
                style: Theme.of(
                  context,
                ).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold),
              ),

              StreamBuilder<QuerySnapshot>(
                stream: getGradesStream(),
                builder: (context, snapshot) {
                  if (!snapshot.hasData) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  final gradesDocs = snapshot.data!.docs;

                  if (gradesDocs.isEmpty) {
                    return const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Text('لا توجد درجات مسجلة لهذا الطالب.'),
                    );
                  }

                  return ListView.builder(
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemCount: subjects.length,
                    itemBuilder: (context, index) {
                      final subject = subjects[index];
                      QueryDocumentSnapshot<Map<String, dynamic>>? gradeDoc;

                      for (var g
                          in gradesDocs
                              .cast<
                                QueryDocumentSnapshot<Map<String, dynamic>>
                              >()) {
                        if (g['Subject_id'] == subject['id']) {
                          gradeDoc = g;
                          break;
                        }
                      }

                      final term1 =
                          gradeDoc != null
                              ? gradeDoc['Term1_scor']?.toString() ?? '-'
                              : '-';
                      final term2 =
                          gradeDoc != null
                              ? gradeDoc['Term2_scor']?.toString() ?? '-'
                              : '-';
                      final total =
                          gradeDoc != null
                              ? gradeDoc['Total_scor']?.toString() ?? '-'
                              : '-';

                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 6),
                        elevation: 2,
                        child: ListTile(
                          title: Text(subject['name']),
                          subtitle: Text(
                            'الجزء الأول: $term1, الجزء الثاني: $term2, المجموع: $total',
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
