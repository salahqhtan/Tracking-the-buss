import 'package:darbk_new/Color.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:searchfield/searchfield.dart';




class DeleteStudentTab extends StatefulWidget {
  @override
  State<DeleteStudentTab> createState() => _DeleteStudentTabState();
}

class _DeleteStudentTabState extends State<DeleteStudentTab> {
  Map<String, dynamic>? selectedStudent;
  String? className;
  String? parentName;

  Future<void> fetchRelatedInfo(String classId, String parentId) async {
    final classDoc =
        await FirebaseFirestore.instance
            .collection('Classes')
            .doc(classId)
            .get();
    final parentDoc =
        await FirebaseFirestore.instance
            .collection('Parent')
            .doc(parentId)
            .get();

    setState(() {
      className = classDoc.exists ? classDoc['Name'] : 'غير معروف';
      parentName = parentDoc.exists ? parentDoc['Name'] : 'غير معروف';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        children: [
          FutureBuilder(
            future: FirebaseFirestore.instance.collection('Student').get(),
            builder: (context, snapshot) {
              if (!snapshot.hasData) return CircularProgressIndicator();
              final students = snapshot.data!.docs;
              return Center(
                child: ConstrainedBox(
                  constraints: BoxConstraints(maxWidth: 600, minWidth: 220),
                  child: Column(
                    children: [
                      SearchField(
                        searchInputDecoration: SearchInputDecoration(
                          suffixIcon: Icon(Icons.search),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.border,
                            ),
                          ),
                          focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(15),
                            borderSide: BorderSide(
                              width: 1,
                              color: ScreenColorS.focuseBorder,
                            ),
                          ),
                        ),
                        suggestions:
                            students
                                .map(
                                  (doc) => SearchFieldListItem(
                                    doc['Name'],
                                    item: doc,
                                  ),
                                )
                                .toList(),
                        onSuggestionTap: (item) async {
                          final doc = item.item!;
                          final studentData = doc.data();
                          studentData['id'] = doc.id;
                          setState(() {
                            selectedStudent = studentData;
                          });
                          await fetchRelatedInfo(
                            studentData['Class_id'],
                            studentData['Parent_ID'],
                          );
                        },
                      ),
                      if (selectedStudent != null)
                        Card(
                          margin: const EdgeInsets.only(top: 20),
                          child: ListTile(
                            title: Text(
                              'اسم الطالب: ${selectedStudent!['Name']}',
                            ),
                            subtitle: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('الصف: ${className ?? '...'}'),
                                Text('اسم ولي الأمر: ${parentName ?? '...'}'),
                              ],
                            ),
                            trailing: IconButton(
                              icon: Icon(Icons.delete, color: Colors.red),
                              onPressed: () async {
                                await FirebaseFirestore.instance
                                    .collection('Student')
                                    .doc(selectedStudent!['id'])
                                    .delete();
                                setState(() {
                                  selectedStudent = null;
                                  className = null;
                                  parentName = null;
                                });
                              },
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}


