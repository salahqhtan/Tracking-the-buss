import 'package:darbk_new/screen/admin/StudentManagement/AddStudent.dart';
import 'package:darbk_new/screen/admin/StudentManagement/DeleteStudent.dart';
import 'package:darbk_new/screen/admin/StudentManagement/EditStudent.dart';
import 'package:darbk_new/screen/admin/StudentManagement/ViewStudent.dart';
import 'package:darbk_new/screen/admin/widget/CustomAppBar.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';
import 'package:flutter/material.dart';

class StudentManagementPage extends StatefulWidget {
  @override
  _StudentManagementPageState createState() => _StudentManagementPageState();
}

class _StudentManagementPageState extends State<StudentManagementPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  String selectedClass = '';
  String selectedTerm = 'الجزء الأول';

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl, // الاتجاه من اليمين لليسار
      child: ScaffoldWithCustomAppBar(
        title: "إدارة الطلاب",

        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.add), text: 'إضافة'),
            Tab(icon: Icon(Icons.visibility), text: 'عرض'),
            Tab(icon: Icon(Icons.edit), text: 'تعديل'),
            Tab(icon: Icon(Icons.delete), text: 'حذف'),
          ],
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            AddStudentTab(),
            ViewStudentTab(),
            EditStudentTab(),
            DeleteStudentTab(),
          ],
        ),
        bottomNavigationBar: const CustomBottomNav(currentIndex: 6),
      ),
    );
  }
}
