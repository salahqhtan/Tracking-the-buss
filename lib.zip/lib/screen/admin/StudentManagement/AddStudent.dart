import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:darbk_new/Color.dart';
import 'package:darbk_new/Widget/Messages.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:searchfield/searchfield.dart';

class AddStudentTab extends StatefulWidget {
  @override
  State<AddStudentTab> createState() => _AddStudentTabState();
}

class _AddStudentTabState extends State<AddStudentTab> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController parentNameController = TextEditingController();
  String? selectedParentId;
  String? selectedClassId;

  List<SearchFieldListItem<String>> parentSuggestions = [];
  List<Map<String, dynamic>> classes = [];

  @override
  void initState() {
    super.initState();
    fetchParents();
    fetchClasses();
  }

  Future<void> promoteStudents() async {
    final classesSnapshot =
        await FirebaseFirestore.instance.collection('Classes').get();

    Map<int, String> classNumberMap = {};
    for (var doc in classesSnapshot.docs) {
      int number = doc['Number'] ?? 0;
      classNumberMap[number] = doc.id;
    }

    int maxClassNumber = classNumberMap.keys.reduce((a, b) => a > b ? a : b);
    final studentsSnapshot =
        await FirebaseFirestore.instance.collection('Student').get();

    int promotedCount = 0;

    for (var studentDoc in studentsSnapshot.docs) {
      String studentId = studentDoc.id;
      String currentClassId = studentDoc['Class_id'];

      int currentClassNumber = 0;
      classNumberMap.forEach((num, id) {
        if (id == currentClassId) currentClassNumber = num;
      });     
      final subjectsSnapshot =
          await FirebaseFirestore.instance
              .collection('Subjects')
              .where('Class_id', isEqualTo: currentClassId)
              .get();
      final subjectIds = subjectsSnapshot.docs.map((doc) => doc.id).toList();
      final gradesSnapshot =
          await FirebaseFirestore.instance
              .collection('Grades')
              .where('Student_id', isEqualTo: studentId)
              .where('Class_ID', isEqualTo: currentClassId)
              .get();
      if (gradesSnapshot.docs.length < subjectIds.length) {
       
      }
      bool hasFail = false;
      for (var subjectId in subjectIds) {
        final gradeDoc = gradesSnapshot.docs.firstWhere(
          (doc) => doc['Subject_id'] == subjectId,
          orElse: () => null!,
        );

        if (gradeDoc == null || !gradeDoc.data().containsKey('Total_scor')) {
          
          hasFail = true;
          break;
        }

        int total = gradeDoc['Total_scor'] ?? 0;
        if (total < 50) {
   
          hasFail = true;
          break;
        }
      }

      if (!hasFail) {
        int nextClassNumber = currentClassNumber + 1;
        String? nextClassId = classNumberMap[nextClassNumber];

        if (nextClassId != null) {
          await FirebaseFirestore.instance
              .collection('Student')
              .doc(studentId)
              .update({'Class_id': nextClassId});
          promotedCount++;
          msg(' تمت ترقية الطالب $studentId إلى الصف رقم $nextClassNumber', Colors.green);
        } else {
          msg(' لم يتم العثور على الصف التالي', Colors.red);
        }
      }
    }

    if (promotedCount > 0) {
      Fluttertoast.showToast(
        msg: 'تم ترقية $promotedCount طالب(ة) بنجاح',
        backgroundColor: Colors.green,
        textColor: Colors.white,
      );
    } else {
      msg(' لم يتم ترقية أي طالب.', Colors.blue);
    }
  }

  Future<void> fetchParents() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('Parent').get();
    setState(() {
      parentSuggestions =
          snapshot.docs
              .map((doc) => SearchFieldListItem(doc['Name'], item: doc.id))
              .toList();
    });
  }

  Future<void> fetchClasses() async {
    final snapshot =
        await FirebaseFirestore.instance.collection('Classes').get();
    setState(() {
      classes =
          snapshot.docs
              .map((doc) => {'id': doc.id, 'name': doc['Name']})
              .toList();
    });
  }

  void addStudent() async {
    await FirebaseFirestore.instance.collection('Student').add({
      'Name': nameController.text,
      'Class_id': selectedClassId ?? '',
      'Parent_ID': selectedParentId ?? '',
    });

    nameController.clear();
    parentNameController.clear();
    setState(() {
      selectedParentId = null;
      selectedClassId = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Center(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 600, minWidth: 220),
          child: Card(
            color: ScreenColorS.card,
            margin: EdgeInsets.all(10),
            child: Container(
              padding: EdgeInsets.all(10),
              child: ListView(
                children: [
                  TextField(
                    controller: nameController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.border,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.border,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.focuseBorder,
                        ),
                      ),
                      labelText: 'اسم الطالب',
                    ),
                  ),
                  const SizedBox(height: 10),
                  SearchField<String>(
                    searchInputDecoration: SearchInputDecoration(
                      suffixIcon: Icon(Icons.search),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.border,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.border,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.focuseBorder,
                        ),
                      ),
                    ),
                    controller: parentNameController,
                    suggestions: parentSuggestions,
                    hint: 'ابحث عن ولي الأمر',
                    onSuggestionTap:
                        (item) => setState(() {
                          selectedParentId = item.item;
                          parentNameController.text = item.searchKey;
                        }),
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<dynamic>(
                    value: selectedClassId,
                    items:
                        classes
                            .map(
                              (cls) => DropdownMenuItem(
                                value: cls['id'],
                                child: Text(cls['name']),
                              ),
                            )
                            .toList(),
                    onChanged: (val) => setState(() => selectedClassId = val),
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.border,
                        ),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.border,
                        ),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(15),
                        borderSide: BorderSide(
                          width: 1,
                          color: ScreenColorS.focuseBorder,
                        ),
                      ),
                      labelText: 'اختر الصف',
                    ),
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ScreenColorS.focuseBorder,
                    ),
                    onPressed: addStudent,
                    child: const Text(
                      'إضافة الطالب',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                  const SizedBox(height: 40),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromARGB(255, 118, 181, 252),
                    ),
                    onPressed: () {
                      AwesomeDialog(
                        context: context,
                        dialogType: DialogType.noHeader,
                        animType: AnimType.rightSlide,
                        title: ' هل تريد  ترقية الطلاب',
                        btnOkText: 'ترقية',
                        btnCancelText: 'إلغاء',
                        btnOkOnPress: () async {
                          await promoteStudents();
                        },
                        btnCancelOnPress: () async {
                          Navigator.pop(context);
                        },
                      ).show();
                    },
                    child: const Text(
                      'ترقية جميع الطلاب',
                      style: TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
