import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/Color.dart';
// import 'package:darbk_new/ScreenUsers/screen/screenParent/StudentDetails.dart';
import 'package:darbk_new/screen/admin/StudentManagement/ListView.builder.dart';
import 'package:flutter/material.dart';

class ViewStudentTab extends StatefulWidget {
  const ViewStudentTab({super.key});

  @override
  _ViewStudentTabState createState() => _ViewStudentTabState();
}

class _ViewStudentTabState extends State<ViewStudentTab> {
  String? selectedClassId;
  List<Map<String, dynamic>> classes = [];

  @override
  void initState() {
    super.initState();
    fetchClasses();
  }

  Future<void> fetchClasses() async {
    final snapshot =
        await FirebaseFirestore.instance
            .collection('Classes')
            .orderBy('Number')
            .get();

    setState(() {
      classes =
          snapshot.docs.map((doc) {
            return {
              'id': doc.id,
              'name': doc['Name'] ?? '',
              'stage': doc['Stage'] ?? '',
            };
          }).toList();
    });
  }

  Stream<QuerySnapshot> getStudentsStream() {
    if (selectedClassId == null) {
      return const Stream.empty();
    }
    return FirebaseFirestore.instance
        .collection('Student')
        .where('Class_id', isEqualTo: selectedClassId)
        .snapshots();
  }

  void openStudentDetails(String studentId, Map<String, dynamic> studentData) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (context) => StudentDetailsPage(
              studentId: studentId,
              studentData: studentData,
            ),
      ),
    );
  }

  String getClassNameById(String classId) {
    final cls = classes.firstWhere(
      (element) => element['id'] == classId,
      orElse: () => {'stage': '-', 'name': '-'},
    );
    return "${cls['stage']} - ${cls['name']}";
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
            child: Column(
              children: [
                // صف يحتوي Dropdown وزر التحديث بجانب بعض
                Row(
                  children: [
                    Expanded(
                      child: Material(
                        elevation: 2,
                        borderRadius: BorderRadius.circular(15),
                        child: DropdownButtonFormField<String>(
                          value: selectedClassId,
                          decoration: InputDecoration(
                            labelText: 'اختر الصف',
                            prefixIcon: const Icon(Icons.class_),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 10,
                            ),
                          ),
                          items:
                              classes.map((cls) {
                                return DropdownMenuItem<String>(
                                  value: cls['id'],
                                  child: Text(
                                    "${cls['stage']} - ${cls['name']}",
                                  ),
                                );
                              }).toList(),
                          onChanged: (val) {
                            setState(() {
                              selectedClassId = val;
                            });
                          },
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Material(
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(15),
                      ),
                      color: ScreenColorS.focuseBorder,
                      child: IconButton(
                        icon: const Icon(Icons.refresh, color: Colors.white),
                        tooltip: 'تحديث',
                        onPressed: () {
                          fetchClasses();
                          setState(() {
                            selectedClassId = null;
                          });
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),

                Expanded(
                  child: StreamBuilder<QuerySnapshot>(
                    stream: getStudentsStream(),
                    builder: (context, snapshot) {
                      if (selectedClassId == null) {
                        return const Center(
                          child: Text(
                            "يرجى اختيار الصف لعرض الطلاب",
                            style: TextStyle(fontSize: 18, color: Colors.grey),
                          ),
                        );
                      }

                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return const Center(child: CircularProgressIndicator());
                      }

                      if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
                        return const Center(
                          child: Text(
                            "لا يوجد طلاب في هذا الصف",
                            style: TextStyle(fontSize: 18, color: Colors.grey),
                          ),
                        );
                      }

                      final docs = snapshot.data!.docs;

                      return ListView.builder(
                        itemCount: docs.length,
                        itemBuilder: (context, index) {
                          final data =
                              docs[index].data()! as Map<String, dynamic>;
                          final grade = data['Grade']?.toString() ?? '-';
                          final status = data['Status']?.toString() ?? '-';
                          final className = getClassNameById(
                            data['Class_id'] ?? '',
                          );

                          return Card(
                            elevation: 4,
                            margin: const EdgeInsets.symmetric(vertical: 8),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(15),
                            ),
                            child: ListTile(
                              contentPadding: const EdgeInsets.symmetric(
                                horizontal: 20,
                                vertical: 12,
                              ),
                              leading: CircleAvatar(
                                radius: 28,
                                backgroundColor: ScreenColorS.focuseBorder,
                                child: Text(
                                  '${index + 1}',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 18,
                                  ),
                                ),
                              ),
                              title: Text(
                                data['Name'] ?? 'بدون اسم',
                                style: const TextStyle(
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18,
                                ),
                              ),
                              subtitle: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'الصف: $className',
                                    style: TextStyle(
                                      fontSize: 14,
                                      color: Colors.grey.shade700,
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Row(
                                    children: [
                                      Chip(
                                        label: Text('الدرجة: $grade'),
                                        backgroundColor: Colors.blue.shade50
                                            .withOpacity(0.7),
                                        avatar: const Icon(
                                          Icons.score,
                                          size: 18,
                                        ),
                                      ),
                                      const SizedBox(width: 12),
                                      Chip(
                                        label: Text('الحالة: $status'),
                                        backgroundColor: Colors.green.shade50
                                            .withOpacity(0.7),
                                        avatar: const Icon(
                                          Icons.info_outline,
                                          size: 18,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                              trailing: Icon(
                                Icons.arrow_forward_ios,
                                color: ScreenColorS.focuseBorder,
                              ),
                              onTap:
                                  () =>
                                      openStudentDetails(docs[index].id, data),
                            ),
                          );
                        },
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
