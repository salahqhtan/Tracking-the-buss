import 'package:flutter/material.dart';
import 'package:darbk_new/screen/admin/widget/drawer.dart';

class CustomAppBarWithDrawer extends StatelessWidget
    implements PreferredSizeWidget {
  final String title;
  final PreferredSizeWidget? bottom; // هذه الخاصية للـ TabBar أو غيره

  const CustomAppBarWithDrawer({super.key, required this.title, this.bottom});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: const Color.fromARGB(255, 150, 229, 240),
      title: Text(
        title,
        style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w800),
      ),
      bottom: bottom, // هنا نضيف خاصية bottom
    );
  }

  @override
  Size get preferredSize => Size(
    double.infinity,
    kToolbarHeight + (bottom?.preferredSize.height ?? 0),
  );
}

class ScaffoldWithCustomAppBar extends StatelessWidget {
  final String title;
  final Widget body;
  final Widget? bottomNavigationBar;
  final PreferredSizeWidget? bottom; // لإرسال الـ TabBar

  const ScaffoldWithCustomAppBar({
    super.key,
    required this.title,
    required this.body,
    this.bottomNavigationBar,
    this.bottom,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const DrawerWidget(),
      appBar: CustomAppBarWithDrawer(title: title, bottom: bottom),
      body: body,
      bottomNavigationBar: bottomNavigationBar,
    );
  }
}
