import 'package:darbk_new/screen/admin/Notifications.dart';

import 'package:darbk_new/screen/admin/SubjectiveAdmin.dart';
import 'package:darbk_new/screen/admin/homeScreenAddmin.dart';
import 'package:darbk_new/screen/admin/chats/notes.dart';
// import 'package:darbk_new/screen/admin/chat/DashBoard.dart';
import 'package:flutter/material.dart';

class CustomBottomNav extends StatefulWidget {
  final int currentIndex;

  const CustomBottomNav({super.key, required this.currentIndex});

  @override
  State<CustomBottomNav> createState() => _CustomBottomNavState();
}

class _CustomBottomNavState extends State<CustomBottomNav> {
  late int currentIndex;

  @override
  void initState() {
    super.initState();
    currentIndex = widget.currentIndex;
  }

  void _navigateToPage(int index) {
    if (index == currentIndex) return;

    setState(() => currentIndex = index);

    Widget page;

    switch (index) {
      case 0:
        page = HomeAdmin();
        break;
      case 1:
        page = NotificationsAdmin();
        break;
      case 2:
        page = NotesPage();
        break;
      case 3:
        page = SubjectiveAdmin();
        break;
      default:
        page = HomeAdmin();
    }

    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 90, // زدت الارتفاع ليناسب الحجم الأكبر
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 16.0),
        child: Container(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFF0F2027), Color(0xFF203A43), Color(0xFF2C5364)],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(30.0),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.25),
                blurRadius: 20,
                offset: const Offset(0, 6),
              ),
            ],
          ),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(30.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _navItem(
                  icon: Icons.home,
                  label: 'الرئيسية',
                  index: 0,
                ), // أيقونة منزل - الصفحة الرئيسية
                _navItem(
                  icon: Icons.notifications_active,
                  label: 'الإشعارات',
                  index: 1,
                ), // أيقونة تنبيه نشطة
                _navItem(
                  icon: Icons.message, // أيقونة رسائل
                  label: 'الدردشة',
                  index: 2,
                ),

                // أيقونة ملاحظات/تعليقات
                _navItem(
                  icon: Icons.account_circle,
                  label: 'حسابي',
                  index: 3,
                ), // أيقونة حساب شخصي
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _navItem({
    required IconData icon,
    required String label,
    required int index,
  }) {
    final isSelected = index == currentIndex;

    return GestureDetector(
      onTap: () => _navigateToPage(index),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 10,
        ), // زيادة الحشو
        decoration: BoxDecoration(
          color:
              isSelected
                  ? const Color.fromARGB(255, 193, 211, 209).withOpacity(0.20)
                  : Colors.transparent,
          borderRadius: BorderRadius.circular(12),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              size: 20, // حجم أكبر للأيقونة
              color:
                  isSelected
                      ? const Color.fromARGB(255, 23, 195, 92)
                      : const Color.fromARGB(220, 236, 227, 227),
            ),
            const SizedBox(height: 2), // زيادة المسافة بين الأيقونة والنص
            Text(
              label,
              style: TextStyle(
                fontSize: 13, // حجم خط أكبر
                color: isSelected ? Colors.amberAccent : Colors.white70,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
