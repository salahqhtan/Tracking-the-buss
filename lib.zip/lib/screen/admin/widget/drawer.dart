import 'dart:io';

import 'package:awesome_dialog/awesome_dialog.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/Data.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../../auth/login.dart';
// import '../../ScreenUsers/screen/screenParent/subjective.dart';

class DrawerWidget extends StatefulWidget {
  const DrawerWidget({super.key});

  @override
  State<DrawerWidget> createState() => _DrawerWidgetState();
}

class _DrawerWidgetState extends State<DrawerWidget> {
  File? _userImageFile;
  final String _defaultImagePath = "assets/images/icons8-admin-80.png";
  final ImagePicker _picker = ImagePicker();

  String? userEmail;
  String? userRole;
  String? userName;

  @override
  void initState() {
    super.initState();
    _loadUserImage();
    _loadUserDataFromFirestore();
  }

  /// جلب بيانات المستخدم من Firestore بناءً على uid الحالي
  Future<void> _loadUserDataFromFirestore() async {
    try {
      final currentUser = FirebaseAuth.instance.currentUser;
      if (currentUser == null) {
        setState(() {
          userEmail = "غير مسجل الدخول";
          userRole = "غير معروف";
          userName = "";
        });
        return;
      }

      final uid = currentUser.uid;

      final userDoc =
          await FirebaseFirestore.instance.collection('users').doc(uid).get();

      if (userDoc.exists) {
        final data = userDoc.data()! as Map<String, dynamic>;
        setState(() {
          userEmail = data['email'] ?? "غير معروف";
          userRole = data['role'] ?? "غير محدد";
          userName = data['name'] ?? "";
        });
      } else {
        setState(() {
          userEmail = currentUser.email ?? "غير معروف";
          userRole = "غير محدد";
          userName = "";
        });
      }
    } catch (e) {
      setState(() {
        userEmail = "خطأ في تحميل البيانات";
        userRole = "";
        userName = "";
      });
      Fluttertoast.showToast(msg: "خطأ في جلب بيانات المستخدم");
    }
  }

  /// تحميل الصورة المخزنة محلياً
  Future<void> _loadUserImage() async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/user_image.png';
    final file = File(path);
    if (await file.exists()) {
      setState(() {
        _userImageFile = file;
      });
    }
  }

  /// حفظ الصورة المختارة محلياً لتبقى ثابتة
  Future<void> _saveUserImage(XFile pickedFile) async {
    final dir = await getApplicationDocumentsDirectory();
    final path = '${dir.path}/user_image.png';
    final file = File(path);
    final savedImage = await file.writeAsBytes(await pickedFile.readAsBytes());
    setState(() {
      _userImageFile = savedImage;
    });
  }

  /// حذف الصورة المختارة (التي ليست الافتراضية)
  Future<void> _deleteUserImage() async {
    if (_userImageFile != null) {
      final file = _userImageFile!;
      if (await file.exists()) {
        await file.delete();
      }
      setState(() {
        _userImageFile = null; // ترجع الصورة الافتراضية
      });
      Fluttertoast.showToast(msg: "تم حذف الصورة، عادت الصورة الافتراضية");
    }
  }

  /// عرض Dialog للاختيار بين الكاميرا والمعرض
  void _showImageSourceDialog() {
    AwesomeDialog(
      context: context,
      dialogType: DialogType.noHeader,
      headerAnimationLoop: false,
      title: "اختر صورة",
      desc: "هل تريد اختيار صورة من المعرض أم التقاط صورة بالكاميرا؟",
      btnCancelText: "معرض",
      btnCancelOnPress: () => _pickImage(ImageSource.gallery),
      btnOkText: "كاميرا",
      btnOkOnPress: () => _pickImage(ImageSource.camera),
    ).show();
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final pickedFile = await _picker.pickImage(
        source: source,
        imageQuality: 80,
      );
      if (pickedFile != null) {
        await _saveUserImage(pickedFile);
      }
    } catch (e) {
      Fluttertoast.showToast(msg: "حدث خطأ أثناء اختيار الصورة");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: const Color(0xFFEEEEED),
      shadowColor: Colors.blue,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: 1, horizontal: 15),
        child: SingleChildScrollView(
          child: Column(
            children: [
              const SizedBox(height: 60),

              // بطاقة بيانات المستخدم
              Card(
                elevation: 5,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(15),
                  child: Column(
                    children: [
                      Stack(
                        alignment: Alignment.topRight,
                        children: [
                          GestureDetector(
                            onTap: _showImageSourceDialog,
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(17),
                              child:
                                  _userImageFile != null
                                      ? Image.file(
                                        _userImageFile!,
                                        height: 180,
                                        width: 200,
                                        fit: BoxFit.cover,
                                      )
                                      : Image.asset(
                                        _defaultImagePath,
                                        height: 180,
                                        width: 200,
                                        fit: BoxFit.cover,
                                      ),
                            ),
                          ),
                          if (_userImageFile != null)
                            IconButton(
                              icon: const Icon(Icons.delete, color: Colors.red),
                              onPressed: _deleteUserImage,
                              tooltip: "حذف الصورة المخصصة",
                            ),
                        ],
                      ),
                      const SizedBox(height: 20),

                      if (userName != null && userName!.isNotEmpty)
                        Text(
                          userName!,
                          style: const TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                          textAlign: TextAlign.center,
                        ),

                      if (userEmail != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 6),
                          child: Text(
                            'البريد الإلكتروني: $userEmail',
                            style: const TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w600,
                              color: Colors.black87,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),

                      if (userRole != null)
                        Padding(
                          padding: const EdgeInsets.only(top: 4),
                          child: Text(
                            'الصلاحية: $userRole',
                            style: const TextStyle(
                              fontSize: 15,
                              color: Colors.black54,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              const Divider(
                height: 10,
                indent: 10,
                thickness: 2,
                color: Colors.black26,
              ),

              const SizedBox(height: 10),

              // زر تسجيل الخروج
              ListTile(
                leading: const Icon(
                  Icons.arrow_circle_right,
                  size: 25,
                  color: Color(0xFF204F8B),
                ),
                title: const Text(
                  "تسجيل الخروج",
                  style: TextStyle(fontSize: 17),
                ),
                onTap: () async {
                  await FirebaseAuth.instance.signOut();
                  await DataUser.remove('role');
                  Fluttertoast.showToast(
                    msg: "تم تسجيل الخروج بنجاح",
                    toastLength: Toast.LENGTH_SHORT,
                    gravity: ToastGravity.BOTTOM,
                    backgroundColor: Colors.green,
                    textColor: Colors.white,
                  );
                  Navigator.of(context, rootNavigator: true).pushAndRemoveUntil(
                    MaterialPageRoute(
                      builder: (context) => const LoginScreen(),
                    ),
                    (route) => false,
                  );
                },
              ),

              // زر صفحة "عنا"
              ListTile(
                leading: const Icon(
                  Icons.history,
                  size: 30,
                  color: Color(0xFF204F8B),
                ),
                title: const Text("عنا", style: TextStyle(fontSize: 17)),
                onTap: () {
                  // Navigator.of(context).pushNamed(Subjective.routeScreen);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
