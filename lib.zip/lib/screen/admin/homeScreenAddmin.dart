import 'package:darbk_new/screen/admin/AllMaps.dart';
import 'package:darbk_new/screen/admin/BusManagement/BusManagement.dart';
// import 'package:darbk_new/admin/screen/BusManagement/BusManagement.dart';
import 'package:darbk_new/screen/admin/ClassManagement/ClassManagement.dart';
import 'package:darbk_new/screen/admin/DriverManagement/DriverManagement.dart';
import 'package:darbk_new/screen/admin/GradesManagement/GradesManagement.dart';
// import 'package:darbk_new/admin/screen/GradesManagement/AddGrades.dart';
import 'package:darbk_new/screen/admin/ParentManagement/ParentManagement.dart';
import 'package:darbk_new/screen/admin/StudentManagement/StudentManagement.dart';
import 'package:darbk_new/screen/admin/SubjectManagement/SubjectManagement.dart';
import 'package:darbk_new/screen/admin/TripsMangement/TripsManagement.dart';
import 'package:darbk_new/screen/admin/widget/CustomAppBar.dart';

// استيراد ال Bottom Nav Bar
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';

import 'package:flutter/material.dart';
import 'package:persistent_bottom_nav_bar/persistent_bottom_nav_bar.dart';

// Firebase imports
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class HomeAdmin extends StatefulWidget {
  const HomeAdmin({super.key});

  @override
  State<HomeAdmin> createState() => _HomeAdminState();
}

class _HomeAdminState extends State<HomeAdmin> {
  String userRole = ""; // دور المستخدم يبدأ فارغًا

  // بيانات البطاقات، مع تحديد الأدوار المسموح لها لكل بطاقة
  final List<Map<String, dynamic>> _cardsData = [
    {
      'title': 'جميع الخرائط',
      'icon': Icons.maps_home_work_sharp,
      'screen': const AllMaps(),
      'rolesAllowed': ['admin', 'manager'],
    },
    {
      'title': 'أولياء الأمور',
      'icon': Icons.person_add,
      'screen': ParentManagement(),
      'rolesAllowed': ['admin', 'teacher'],
    },
    {
      'title': 'الطلاب',
      'icon': Icons.boy_rounded,
      'screen': StudentManagementPage(),
      'rolesAllowed': ['admin', 'employee'],
    },
    {
      'title': 'الدرجات',
      'icon': Icons.gradient_outlined,
      'screen': GradesManagement(),
      'rolesAllowed': ['admin', 'employee'],
    },
    {
      'title': 'الفصول',
      'icon': Icons.class_sharp,
      'screen': const ClassManagementScreen(),
      'rolesAllowed': ['admin'],
    },
    {
      'title': 'المواد',
      'icon': Icons.book,
      'screen': const SubjectListPage(),
      'rolesAllowed': ['admin', 'teacher'],
    },
    {
      'title': 'الحافلات',
      'icon': Icons.directions_bus,

      'screen': BusManagement(),
      'rolesAllowed': ['admin'],
    },
    {
      'title': 'السائقين',
      'icon': Icons.drive_eta_rounded,
      'screen': DriverManagement(),
      'rolesAllowed': ['admin', 'driver_manager'],
    },
    {
      'title': 'الرحلات',
      'icon': Icons.map,
      'screen': TripsManagement(),
      'rolesAllowed': ['admin', 'driver_manager'],
    },
  ];

  final PersistentTabController _controller = PersistentTabController(
    initialIndex: 0,
  );

  @override
  void initState() {
    super.initState();
    _loadUserRole();
  }

  // تحميل دور المستخدم من Firestore بناءً على المستخدم الحالي
  Future<void> _loadUserRole() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      DocumentSnapshot<Map<String, dynamic>> doc =
          await FirebaseFirestore.instance
              .collection('users')
              .doc(user.uid)
              .get();

      if (doc.exists &&
          doc.data() != null &&
          doc.data()!.containsKey('roles')) {
        setState(() {
          userRole = doc.data()!['roles'] as String;
        });
      } else {
        // إذا لم يُعثر على الدور، يمكن تعيين دور افتراضي أو إظهار رسالة
        setState(() {
          userRole = 'guest';
        });
      }
    }
  }

  Widget _buildCardsGrid() {
    if (userRole.isEmpty) {
      // عرض مؤشر تحميل أثناء انتظار جلب الدور
      return const Center(child: CircularProgressIndicator());
    }

    final allowedCards =
        _cardsData
            .where((card) => card['rolesAllowed'].contains(userRole))
            .toList();

    if (allowedCards.isEmpty) {
      return const Center(child: Text('لا توجد صلاحيات لعرض أي محتوى.'));
    }

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 30),
      child: Center(
        child: GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 15,
            mainAxisSpacing: 30,
            childAspectRatio: 2.1,
          ),
          itemCount: allowedCards.length,
          itemBuilder: (context, index) {
            final card = allowedCards[index];
            return InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => card['screen']),
                );
              },
              borderRadius: BorderRadius.circular(20),
              splashColor: Colors.indigo.withOpacity(0.24),
              highlightColor: Colors.transparent,
              child: Card(
                elevation: 10,
                shadowColor: Colors.indigo.withOpacity(0.3),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    gradient: const LinearGradient(
                      colors: [Color(0xFF076678), Color(0xFFBDAF37)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: const Color.fromARGB(
                          255,
                          193,
                          96,
                          51,
                        ).withOpacity(0.6),
                        blurRadius: 15,
                        offset: const Offset(4, 4),
                      ),
                    ],
                  ),
                  padding: const EdgeInsets.symmetric(horizontal: 15),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          color: const Color.fromARGB(255, 9, 133, 133),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: const EdgeInsets.all(10),
                        child: Icon(
                          card['icon'],
                          size: 16,
                          color: Colors.white,
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          card['title'],
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Color.fromARGB(255, 244, 247, 249),
                            letterSpacing: 0.9,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _getCurrentScreen() {
    switch (_controller.index) {
      case 0:
        return _buildCardsGrid();
      default:
        return Center(
          child: Text(
            'تبويب رقم ${_controller.index + 1}',
            style: const TextStyle(fontSize: 24),
          ),
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: ScaffoldWithCustomAppBar(
        title: "الصفحة الرئيسية",
        body: _getCurrentScreen(),
        bottomNavigationBar: CustomBottomNav(currentIndex: _controller.index),
      ),
    );
  }
}
