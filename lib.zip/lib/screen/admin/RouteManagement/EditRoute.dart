import 'package:darbk_new/Color.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:searchfield/searchfield.dart';


class EditRouteTab extends StatefulWidget {
  @override
  _EditRouteTabState createState() => _EditRouteTabState();
}

class _EditRouteTabState extends State<EditRouteTab> {
  Map<String, dynamic>? selectedRoute;
  final nameController = TextEditingController();
  final startController = TextEditingController();
  final endController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: FirebaseFirestore.instance.collection('Routes').get(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
        final routes = snapshot.data!.docs;

        return Padding(
          padding: EdgeInsets.all(16),
          child: Center(
            child: ConstrainedBox(
               constraints: BoxConstraints(
                      maxWidth: 600 , minWidth: 220,
                    ),
              child: Card(
                  color: ScreenColorS.card,
                margin: EdgeInsets.all(10),
                child: Container(
                  padding: EdgeInsets.all(10),
                  child: ListView(
                    
                    children: [
                      SearchField(
                        suggestions: routes.map((doc) => SearchFieldListItem(doc['Name'], item: doc)).toList(),
                        hint: 'ابحث عن مسار',
                        searchInputDecoration: SearchInputDecoration(
                           border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
              ),
                        ),
                        onSuggestionTap: (item) {
                          final doc = item.item!;
                          setState(() {
                            selectedRoute = {'id': doc.id, ...doc.data() as Map<String, dynamic>};
                            nameController.text = doc['Name'];
                            startController.text = doc['Start_location'];
                            endController.text = doc['End_location'];
                          });
                        },
                      ),
                      if (selectedRoute != null) ...[
                        SizedBox(height: 20),
                        TextField(controller: nameController, decoration: InputDecoration( border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
              ),labelText: 'اسم المسار')),
                        SizedBox(height: 10),
                        TextField(controller: startController, decoration: InputDecoration( border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
              ),labelText: 'نقطة البداية')),
                        SizedBox(height: 10),
                        TextField(controller: endController, decoration: InputDecoration( border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
              ),labelText: 'نقطة النهاية')),
                        SizedBox(height: 20),
                        ElevatedButton(
                          onPressed: () async {
                            await FirebaseFirestore.instance.collection('Routes').doc(selectedRoute!['id']).update({
                              'Name': nameController.text,
                              'Start_location': startController.text,
                              'End_location': endController.text,
                            });
                            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("تم التعديل")));
                          },
                          child: Text("تحديث البيانات" , style: TextStyle(color: Colors.white, fontSize: 17 , fontWeight: FontWeight.bold),),
                                style: ElevatedButton.styleFrom(
                                backgroundColor: ScreenColorS.border,
                              ),
                        )
                      ]
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
