import 'package:darbk_new/screen/admin/RouteManagement/AddRoute.dart';
import 'package:darbk_new/screen/admin/RouteManagement/DeleteRoute.dart';
import 'package:darbk_new/screen/admin/RouteManagement/EditRoute.dart';
// import 'package:darbk_new/admin/screen/TripsMangement/TripsManagement.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';
// import 'package:darbk_new/admin/widget/drawer.dart';
import 'package:flutter/material.dart';

class RouteManagementPage extends StatefulWidget {
  @override
  _RouteManagementPageState createState() => _RouteManagementPageState();
}

class _RouteManagementPageState extends State<RouteManagementPage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        // 👈 لازم هنا
        length: 3,
        child: Scaffold(
          appBar: AppBar(
            backgroundColor: const Color.fromARGB(255, 150, 229, 240),
            title: const Text(
              'إدارة السائقين',
              style: TextStyle(fontWeight: FontWeight.w800, fontSize: 25),
            ),
            bottom: TabBar(
              controller: _tabController,
              tabs: [
                Tab(text: "إضافة", icon: Icon(Icons.add)),
                Tab(text: "تعديل", icon: Icon(Icons.edit)),
                Tab(text: "حذف", icon: Icon(Icons.delete)),
              ],
            ),
          ),
          body: TabBarView(
            controller: _tabController,
            children: [AddRouteTab(), EditRouteTab(), DeleteRouteTab()],
          ),
          bottomNavigationBar: CustomBottomNav(currentIndex: 11),
        ),
      ),
    );
  }
}
