import 'package:darbk_new/Color.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';





class AddRouteTab extends StatefulWidget {
  @override
  _AddRouteTabState createState() => _AddRouteTabState();
}

class _AddRouteTabState extends State<AddRouteTab> {
  final nameController = TextEditingController();
  final startController = TextEditingController();
  final endController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(16),
      child: Center(
        child: ConstrainedBox(
           constraints: BoxConstraints(
                      maxWidth: 600 , minWidth: 220,
                    ),
          child: Card(
            color: ScreenColorS.card,
            margin: EdgeInsets.all(10),
            child: Container(
              padding: EdgeInsets.all(10),
              child: ListView(
                
                children: [

                  TextField(controller: nameController, decoration: InputDecoration( border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
              ), labelText: 'اسم المسار')),
                  SizedBox(height: 10),
                  TextField(controller: startController, decoration: InputDecoration(border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
              ),labelText: 'نقطة البداية')),
                  SizedBox(height: 10),
                  TextField(controller: endController, decoration: InputDecoration(border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
              ),labelText: 'نقطة النهاية')),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      await FirebaseFirestore.instance.collection('Routes').add({
                        'Name': nameController.text,
                        'Start_location': startController.text,
                        'End_location': endController.text,
                      });
                      nameController.clear();
                      startController.clear();
                      endController.clear();
                      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("تمت الإضافة بنجاح")));
                    },
                    child: Text("إضافة"),
                     style: ElevatedButton.styleFrom(
                          backgroundColor: ScreenColorS.focuseBorder,
                        ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
