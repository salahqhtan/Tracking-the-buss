import 'package:darbk_new/Color.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:searchfield/searchfield.dart';


class DeleteRouteTab extends StatefulWidget {
  @override
  _DeleteRouteTabState createState() => _DeleteRouteTabState();
}

class _DeleteRouteTabState extends State<DeleteRouteTab> {
  Map<String, dynamic>? selectedRoute;

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: FirebaseFirestore.instance.collection('Routes').get(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
        final routes = snapshot.data!.docs;

        return Padding(
          padding: EdgeInsets.all(16),
          child: Center(
            child: ConstrainedBox(
               constraints: BoxConstraints(
                      maxWidth: 600 , minWidth: 220,
                    ),
              child: Column(
                children: [
                  SearchField(
                    suggestions: routes.map((doc) => SearchFieldListItem(doc['Name'], item: doc)).toList(),
                    hint: 'ابحث عن مسار',
                    searchInputDecoration: SearchInputDecoration(
                      border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.border),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide(width: 1, color: ScreenColorS.focuseBorder),
              )
                    ),
                    onSuggestionTap: (item) {
                      final doc = item.item!;
                      setState(() {
                        selectedRoute = {'id': doc.id, ...doc.data() as Map<String, dynamic>};
                      });
                    },
                  ),
                  if (selectedRoute != null) ...[
                    SizedBox(height: 20),
                    ListTile(
                      title: Text('اسم المسار: ${selectedRoute!['Name']}'),
                      subtitle: Text('من: ${selectedRoute!['Start_location']} إلى ${selectedRoute!['End_location']}'),
                      trailing: IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () async {
                          await FirebaseFirestore.instance.collection('Routes').doc(selectedRoute!['id']).delete();
                          setState(() => selectedRoute = null);
                          ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("تم الحذف")));
                        },
                      ),
                    )
                  ]
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}