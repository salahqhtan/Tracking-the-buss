import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

import 'package:darbk_new/Widget/Messages.dart';
import 'package:darbk_new/screen/admin/ParentManagement/editParent.dart';

class ParentsListScreen extends StatefulWidget {
  @override
  State<ParentsListScreen> createState() => _ParentsListScreenState();
}

class _ParentsListScreenState extends State<ParentsListScreen> {
  List<DocumentSnapshot> parents = [];
  List<DocumentSnapshot> filteredParents = [];
  TextEditingController searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchParents();
  }

  Future<void> fetchParents() async {
    try {
      final snapshot =
          await FirebaseFirestore.instance.collection('Parent').get();
      setState(() {
        parents = snapshot.docs;
        filteredParents = parents;
      });
    } catch (e) {
      print('Error fetching parents: $e');
      msg('حدث خطأ أثناء جلب البيانات', Colors.red);
    }
  }

  void filterParents(String query) {
    final filtered =
        parents.where((doc) {
          final name = doc['Name'].toString().toLowerCase();
          final email = doc['Email'].toString().toLowerCase();
          final phone = doc['Phone'].toString();
          return name.contains(query.toLowerCase()) ||
              email.contains(query.toLowerCase()) ||
              phone.contains(query);
        }).toList();

    setState(() {
      filteredParents = filtered;
    });
  }

  void deleteParent(String parentId) async {
    try {
      await FirebaseFirestore.instance
          .collection('Parent')
          .doc(parentId)
          .delete();
      await FirebaseFirestore.instance
          .collection('users')
          .doc(parentId)
          .delete();
      msg('تم حذف ولي الأمر بنجاح', Colors.green);
      fetchParents();
    } catch (e) {
      msg('فشل حذف ولي الأمر: $e', Colors.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.teal.shade50, Colors.teal.shade100],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: Column(
          children: [
            Padding(
              padding: EdgeInsets.all(16),
              child: TextField(
                controller: searchController,
                onChanged: filterParents,
                decoration: InputDecoration(
                  hintText: 'ابحث عن ولي الأمر',
                  prefixIcon: Icon(Icons.search, color: Colors.teal),
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(30),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: filteredParents.length,
                itemBuilder: (context, index) {
                  final parent = filteredParents[index];
                  return _buildParentCard(parent);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildParentCard(DocumentSnapshot parent) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(25),
          boxShadow: [
            BoxShadow(
              color: Colors.teal.shade100.withOpacity(0.5),
              blurRadius: 8,
              offset: Offset(0, 5),
            ),
          ],
        ),
        child: ListTile(
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          leading: CircleAvatar(
            backgroundColor: Colors.teal.shade300,
            child: Text(
              parent['Name'][0],
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          title: Text(
            parent['Name'],
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
          ),
          subtitle: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('الهاتف: ${parent['Phone']}'),
              Text('البريد: ${parent['Email']}'),
              Text('رقم الحافلة: ${parent['Bus_ID']}'),
            ],
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              // زر تعديل ولي الأمر
              IconButton(
                icon: Icon(Icons.edit, color: Colors.orange),
                tooltip: 'تعديل',
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder:
                          (_) => EditParentPage(
                            parent: parent, // تمرير المستند مباشرة
                            onUpdate: fetchParents, // تحديث القائمة بعد التعديل
                          ),
                    ),
                  );
                },
              ),

              // زر حذف ولي الأمر
              IconButton(
                icon: Icon(Icons.delete, color: Colors.red),
                tooltip: 'حذف',
                onPressed: () {
                  showDialog(
                    context: context,
                    builder:
                        (_) => AlertDialog(
                          title: Text('تأكيد الحذف'),
                          content: Text('هل أنت متأكد من حذف ولي الأمر؟'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: Text('إلغاء'),
                            ),
                            TextButton(
                              onPressed: () {
                                deleteParent(parent.id);
                                Navigator.pop(context);
                              },
                              child: Text(
                                'حذف',
                                style: TextStyle(color: Colors.red),
                              ),
                            ),
                          ],
                        ),
                  );
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
