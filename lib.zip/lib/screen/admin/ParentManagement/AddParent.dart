import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:darbk_new/Color.dart';
import 'package:darbk_new/Widget/Messages.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AddParentTab extends StatefulWidget {
  final VoidCallback onSave;
  AddParentTab({required this.onSave});

  @override
  State<AddParentTab> createState() => _AddParentTabState();
}

class _AddParentTabState extends State<AddParentTab> {
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final emailController = TextEditingController();
  final passwordController = TextEditingController();

  String? selectedBusNumber;
  List<String> busNumbers = [];

  final FirebaseAuth _auth = FirebaseAuth.instance;

  @override
  void initState() {
    super.initState();
    fetchBuses();
  }

  Future<void> fetchBuses() async {
    try {
      final snapshot = await FirebaseFirestore.instance.collection('Bus').get();
      setState(() {
        busNumbers =
            snapshot.docs.map((doc) => doc['Bus_number'].toString()).toList();
      });
    } catch (e) {
      msg('حدث خطأ أثناء جلب أرقام الحافلات: $e', Colors.red);
    }
  }

  Future<void> addParent() async {
    if (selectedBusNumber == null ||
        nameController.text.trim().isEmpty ||
        phoneController.text.trim().isEmpty ||
        emailController.text.trim().isEmpty ||
        passwordController.text.trim().isEmpty) {
      msg('يرجى تعبئة جميع الحقول', Colors.red);
      return;
    }

    try {
      final email = emailController.text.trim();
      final password = passwordController.text.trim();
      final name = nameController.text.trim();

      UserCredential userCred = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      String uid = userCred.user!.uid;

      await FirebaseFirestore.instance.collection('Parent').doc(uid).set({
        'Name': name,
        'Phone': phoneController.text.trim(),
        'Email': email,
        'Bus_ID': selectedBusNumber,
      });

      await FirebaseFirestore.instance.collection('users').doc(uid).set({
        'name': name,
        'email': email,
        'password': password,
        'roles': 'parent',
        'related_id': uid,
      });

      nameController.clear();
      phoneController.clear();
      emailController.clear();
      passwordController.clear();
      setState(() => selectedBusNumber = null);

      widget.onSave();
      msg('تم إضافة ولي الأمر بنجاح', Colors.green);
    } on FirebaseAuthException catch (e) {
      if (e.code == 'email-already-in-use') {
        msg('هذا البريد الإلكتروني مستخدم مسبقًا', Colors.red);
        return;
      }
      msg('حدث خطأ: ${e.message}', Colors.red);
    } catch (e) {
      msg('حدث خطأ غير متوقع: $e', Colors.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.teal.shade50, Colors.teal.shade100],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: ListView(
          children: [
            SizedBox(height: 20),
            _buildTextField(nameController, 'اسم ولي الأمر', Icons.person),
            SizedBox(height: 15),
            _buildTextField(
              phoneController,
              'رقم الهاتف',
              Icons.phone,
              keyboardType: TextInputType.phone,
            ),
            SizedBox(height: 15),
            _buildTextField(
              emailController,
              'البريد الإلكتروني',
              Icons.email,
              keyboardType: TextInputType.emailAddress,
            ),
            SizedBox(height: 15),
            _buildTextField(
              passwordController,
              'كلمة المرور',
              Icons.lock,
              obscureText: true,
            ),
            SizedBox(height: 15),
            DropdownButtonFormField<String>(
              value: selectedBusNumber,
              decoration: InputDecoration(
                filled: true,
                fillColor: Colors.teal.shade50,
                labelText: 'رقم الحافلة',
                prefixIcon: Icon(Icons.directions_bus, color: Colors.teal),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
              ),
              items:
                  busNumbers
                      .map(
                        (bus) => DropdownMenuItem(
                          value: bus,
                          child: Text('الحافلة رقم $bus'),
                        ),
                      )
                      .toList(),
              onChanged: (val) => setState(() => selectedBusNumber = val),
            ),
            SizedBox(height: 30),
            ElevatedButton(
              onPressed: addParent,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal.shade700,
                padding: EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                elevation: 5,
              ),
              child: Text(
                'إضافة ولي الأمر',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField(
    TextEditingController controller,
    String label,
    IconData icon, {
    bool obscureText = false,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.teal),
        filled: true,
        fillColor: Colors.teal.shade50,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(30),
          borderSide: BorderSide(color: Colors.teal.shade300, width: 2),
        ),
      ),
    );
  }
}
