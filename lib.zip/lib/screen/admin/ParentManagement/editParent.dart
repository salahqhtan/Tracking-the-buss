import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/Color.dart';
import 'package:darbk_new/Widget/Messages.dart';
import 'package:flutter/material.dart';

class EditParentPage extends StatefulWidget {
  final DocumentSnapshot parent;
  final VoidCallback onUpdate;

  EditParentPage({required this.parent, required this.onUpdate});

  @override
  State<EditParentPage> createState() => _EditParentPageState();
}

class _EditParentPageState extends State<EditParentPage> {
  late TextEditingController nameController;
  late TextEditingController phoneController;
  late TextEditingController emailController;
  late TextEditingController busController;

  @override
  void initState() {
    super.initState();
    nameController = TextEditingController(text: widget.parent['Name']);
    phoneController = TextEditingController(text: widget.parent['Phone']);
    emailController = TextEditingController(text: widget.parent['Email']);
    busController = TextEditingController(text: widget.parent['Bus_ID']);
  }

  void updateParent() async {
    try {
      await FirebaseFirestore.instance
          .collection('Parent')
          .doc(widget.parent.id)
          .update({
            'Name': nameController.text.trim(),
            'Phone': phoneController.text.trim(),
            'Email': emailController.text.trim(),
            'Bus_ID': busController.text.trim(),
          });
      widget.onUpdate();
      msg('تم تعديل بيانات ولي الأمر بنجاح', Colors.green);
      Navigator.pop(context);
    } catch (e) {
      msg('حدث خطأ أثناء التعديل: $e', Colors.red);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.teal.shade50,
      appBar: AppBar(
        title: Text(
          'تعديل ولي الأمر',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        backgroundColor: ScreenColorS.focuseBorder,
        elevation: 5,
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: ListView(
          children: [
            // اسم ولي الأمر
            _buildCardTextField(
              controller: nameController,
              label: 'الاسم',
              icon: Icons.person,
            ),
            SizedBox(height: 15),
            // الهاتف
            _buildCardTextField(
              controller: phoneController,
              label: 'الهاتف',
              icon: Icons.phone,
              keyboard: TextInputType.phone,
            ),
            SizedBox(height: 15),
            // البريد الإلكتروني
            _buildCardTextField(
              controller: emailController,
              label: 'البريد الإلكتروني',
              icon: Icons.email,
              keyboard: TextInputType.emailAddress,
            ),
            SizedBox(height: 15),
            // رقم الحافلة
            _buildCardTextField(
              controller: busController,
              label: 'رقم الحافلة',
              icon: Icons.directions_bus,
              keyboard: TextInputType.number,
            ),
            SizedBox(height: 30),
            // زر التحديث
            ElevatedButton(
              onPressed: updateParent,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.teal.shade700,
                padding: EdgeInsets.symmetric(vertical: 18),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(30),
                ),
                elevation: 6,
              ),
              child: Text(
                'تحديث البيانات',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // تصميم مودرن لكل TextField داخل Card
  Widget _buildCardTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType keyboard = TextInputType.text,
  }) {
    return Card(
      elevation: 4,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
      shadowColor: Colors.teal.shade100,
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
        child: TextField(
          controller: controller,
          keyboardType: keyboard,
          decoration: InputDecoration(
            labelText: label,
            prefixIcon: Icon(icon, color: Colors.teal),
            border: InputBorder.none,
            labelStyle: TextStyle(fontWeight: FontWeight.bold),
          ),
        ),
      ),
    );
  }
}
