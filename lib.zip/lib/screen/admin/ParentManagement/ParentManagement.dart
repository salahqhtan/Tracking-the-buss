import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/screen/admin/ParentManagement/AddParent.dart';
import 'package:darbk_new/screen/admin/ParentManagement/DeleteParent.dart';
import 'package:darbk_new/screen/admin/ParentManagement/ParentsList.dart';
import 'package:darbk_new/screen/admin/widget/bottom_navbar.dart';
import 'package:flutter/material.dart';
import 'package:searchfield/searchfield.dart';

class ParentManagement extends StatefulWidget {
  @override
  State<ParentManagement> createState() => _ParentManagementState();
}

class _ParentManagementState extends State<ParentManagement>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  List<SearchFieldListItem<DocumentSnapshot>> parentSuggestions = [];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    fetchParents();
  }

  Future<void> fetchParents() async {
    try {
      final snapshot =
          await FirebaseFirestore.instance.collection('Parent').get();
      setState(() {
        parentSuggestions =
            snapshot.docs
                .map((doc) => SearchFieldListItem(doc['Name'], item: doc))
                .toList();
      });
    } catch (e) {
      print('Error fetching parents: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: Colors.grey.shade100,
        appBar: AppBar(
          backgroundColor: const Color.fromARGB(255, 79, 235, 222),
          elevation: 5,
          centerTitle: true,
          title: Text(
            'إدارة أولياء الأمور',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 26,
              color: Colors.white,
            ),
          ),

          bottom: TabBar(
            controller: _tabController,
            indicatorColor: Colors.amber,
            indicatorWeight: 4,
            labelStyle: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            tabs: [
              Tab(text: "إضافة", icon: Icon(Icons.add_circle_outline)),
              Tab(text: "عرض", icon: Icon(Icons.list_alt)),
              Tab(text: "حذف", icon: Icon(Icons.delete_forever)),
            ],
          ),
        ),
        body: TabBarView(
          controller: _tabController,
          children: [
            // تبويب الإضافة
            Container(
              padding: EdgeInsets.all(16),
              child: AddParentTab(onSave: fetchParents),
            ),
            // تبويب العرض
            Container(padding: EdgeInsets.all(16), child: ParentsListScreen()),
            // تبويب الحذف
            Container(
              padding: EdgeInsets.all(16),
              child: DeleteParentTab(
                suggestions: parentSuggestions,
                onDelete: fetchParents,
              ),
            ),
          ],
        ),
        bottomNavigationBar: CustomBottomNav(currentIndex: 6),
      ),
    );
  }
}
