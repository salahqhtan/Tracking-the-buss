import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:darbk_new/Color.dart';
import 'package:darbk_new/Widget/Messages.dart';
import 'package:flutter/material.dart';
import 'package:searchfield/searchfield.dart';
import 'package:firebase_auth/firebase_auth.dart';




class DeleteParentTab extends StatefulWidget {
  final List<SearchFieldListItem<DocumentSnapshot>> suggestions;
  final VoidCallback onDelete;

  const DeleteParentTab({required this.suggestions, required this.onDelete, Key? key}) : super(key: key);

  @override
  _DeleteParentTabState createState() => _DeleteParentTabState();
}

class _DeleteParentTabState extends State<DeleteParentTab> {
  DocumentSnapshot? selectedParent;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Center(
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: 600, minWidth: 220),
          child: Column(
            children: [
              SearchField<DocumentSnapshot>(
                searchInputDecoration: SearchInputDecoration(
                  suffixIcon: Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(
                      width: 1,
                      color: ScreenColorS.border,
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(
                      width: 1,
                      color: ScreenColorS.border,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(15),
                    borderSide: BorderSide(
                      width: 1,
                      color: ScreenColorS.focuseBorder,
                    ),
                  ),
                ),
                suggestions: widget.suggestions,
                hint: 'ابحث عن ولي الأمر',
                onSuggestionTap: (item) {
                  setState(() {
                    selectedParent = item.item;  
                  });
                },
              ),
              SizedBox(height: 20),
              if (selectedParent != null)
                Card(
                  elevation: 4,
                  child: ListTile(
                    title: Text(selectedParent!['Name']),
                    subtitle: Text(
                      'هاتف: ${selectedParent!['Phone']}\nبريد: ${selectedParent!['Email']}',
                    ),
                    trailing: IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () async {
                        await FirebaseFirestore.instance
                            .collection('Parent')
                            .doc(selectedParent!.id)
                            .delete();

                        widget.onDelete();

                        setState(() {
                          selectedParent = null;
                        });

                        msg('تم الحذف', Colors.blue);
                      },
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
