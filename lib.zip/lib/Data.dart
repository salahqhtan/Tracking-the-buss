// Data.dart

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';



class DataUser {
  static SharedPreferences? _prefs;

  static Future<void> init() async {
    _prefs = await SharedPreferences.getInstance();
  }


  static Future<void> save(String key, dynamic value) async {
    if (_prefs == null) return;

    if (value is String) {
      await _prefs!.setString(key, value);
    } else if (value is int) {
      await _prefs!.setInt(key, value);
    } else if (value is bool) {
      await _prefs!.setBool(key, value);
    } else if (value is double) {
      await _prefs!.setDouble(key, value);
    } else {
      throw Exception("Unsupported type");
    }
  }


  static dynamic get(String key) {
    if (_prefs == null) return null;
    return _prefs!.get(key);
  }


  static Future<void> remove(String key) async {
    if (_prefs == null) return;
    await _prefs!.remove(key);
  }

  static Future<void> clearAll() async {
    if (_prefs == null) return;
    await _prefs!.clear();
  }
}



class Variable {
  final String name;
  final String id;
  final IconData icon;
  final Color color;

  const Variable(
      {required this.name,
      required this.id,
      required this.icon,
      required this.color});
}

const ItemData = const [
  Variable(
      color: Colors.white,
      icon: Icons.settings,
      id: 'I1',
      name: "Item1"),
  Variable(
      color: Colors.white,
      icon: Icons.holiday_village_sharp,
      id: 'I2',
      name: "Item2"),
  Variable(
      color: Colors.white,
      icon: Icons.phone_bluetooth_speaker_outlined,
      id: 'I3',
      name: "Item3"),
  Variable(
      color: Colors.white,
      icon: Icons.point_of_sale,
      id: 'I4',
      name: "Item4"),
  Variable(
      color: Colors.white,
      icon: Icons.face_4_outlined,
      id: 'I5',
      name: "Item5"),
  Variable(
      color: Colors.white,
      icon: Icons.key,
      id: 'I6',
      name: "Item6"),
  Variable(
      color: Colors.white,
      icon: Icons.question_mark,
      id: 'I7',
      name: "Item7"),
];

